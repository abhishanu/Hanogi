# BatchController
Batch Controller with cache and scheduler implementation
