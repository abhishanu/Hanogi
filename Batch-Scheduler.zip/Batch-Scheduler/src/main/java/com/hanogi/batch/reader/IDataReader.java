package com.hanogi.batch.reader;

import java.util.List;

import com.hanogi.batch.dto.BatchRunDetails;
import com.hanogi.batch.dto.Email;

public interface IDataReader {

	public void readData(List<Email> EmailList, BatchRunDetails batchRunDetails) throws Exception;
}
