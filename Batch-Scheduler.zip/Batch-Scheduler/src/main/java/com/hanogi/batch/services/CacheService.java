package com.hanogi.batch.services;

import com.hanogi.batch.constants.ExecutionStatus;

public interface CacheService {

	boolean checkAddUpdateCache(String messageId, ExecutionStatus inprogress);

	void cleanConcurrentCache();
	
	ExecutionStatus getStatusOfMessage(String messageId);

}
