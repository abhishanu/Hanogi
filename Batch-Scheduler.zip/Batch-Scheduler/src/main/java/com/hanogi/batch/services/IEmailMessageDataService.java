package com.hanogi.batch.services;

import com.hanogi.batch.utils.bo.EmailMessageData;

public interface IEmailMessageDataService {

	public Boolean insertMessageToDB(EmailMessageData emailMessageData);

}
