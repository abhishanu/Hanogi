package com.hanogi.batch.services.impl;

import java.io.Serializable;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hanogi.batch.constants.ExecutionStatus;
import com.hanogi.batch.services.CacheService;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * @author abhishek.gupta02
 *
 */

@Component
public class CacheServiceImpl implements CacheService, Serializable {

	int noOfElementsInCache = 0;

	private final Logger logger = LoggerFactory.getLogger(getClass());

	static CacheManager cacheManager = null;

	@PostConstruct
	public void getCacheManagerInstance() {
		cacheManager = CacheManager.newInstance();
		logger.info("Cache bean created....");
	}

	/*
	 * validate is messageId exists in cache or not. If exists then update its
	 * status in cache. Else add new messageId in Cache
	 */

	@Override
	public boolean checkAddUpdateCache(String messageId, ExecutionStatus executionStatus) {

		logger.info("Caching in progress  for messageId:" + messageId + "...");
		try {
			Cache concurrentCache = cacheManager.getCache("concurrentBatchScheduleCache");

			if (concurrentCache != null) {
				synchronized (this) {
					if (concurrentCache.isElementInMemory(messageId)) {
						logger.info("MesaageId:" + messageId + "exists in cache.Updating its status.");
						concurrentCache.put(new Element(messageId, executionStatus));
						noOfElementsInCache = concurrentCache.getSize();
						return true;
					} else {
						logger.info("Updation in cache with adding new element messageId:" + messageId);
						Element element = new Element(messageId, executionStatus);
						concurrentCache.put(element);
						return false;
					}
				}
			} else {
				logger.error("cache is missing with name 'concurrentBatchScheduleCache'");
				return false;
			}

		} catch (Exception e) {
			logger.error("Error while updating the message in cache with Error:" + e.getMessage());
			return false;
		}
	}

	@Override
	public void cleanConcurrentCache() {
		Cache concurrentCache = cacheManager.getCache("concurrentBatchScheduleCache");

		concurrentCache.removeAll();

		noOfElementsInCache = 0;
	}

	@Override
	public ExecutionStatus getStatusOfMessage(String messageId) {
		Cache concurrentCache = cacheManager.getCache("concurrentBatchScheduleCache");

		if (concurrentCache.isKeyInCache(messageId)) {
			Element element = concurrentCache.get(messageId);

			ExecutionStatus status = (ExecutionStatus) element.getObjectValue();

			return status;
		} else {
			return null;
		}

	}

}
