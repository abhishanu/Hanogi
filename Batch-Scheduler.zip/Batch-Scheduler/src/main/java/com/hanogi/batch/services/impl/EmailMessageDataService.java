package com.hanogi.batch.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanogi.batch.repositories.EmailMessageDataRepositry;
import com.hanogi.batch.services.IEmailMessageDataService;
import com.hanogi.batch.utils.bo.EmailMessageData;

/**
 * @author abhishek.gupta02
 *
 */

@Service
public class EmailMessageDataService implements IEmailMessageDataService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private EmailMessageDataRepositry emailMessageDataRepo;

	@Override
	public Boolean insertMessageToDB(EmailMessageData emailMessageData) {
		try {
			return (emailMessageDataRepo.save(emailMessageData) != null);
		} catch (Exception e) {
			logger.error("Error while inserting mesaage data infomation in DB with error message:" + e.getMessage());
			return false;
		}
	}
}
