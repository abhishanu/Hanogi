package com.hanogi.batch.utils.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.hanogi.batch.dto.EmailMetadata;

@Entity
@Table(name = "email_message_data")
public class EmailMessageData {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "message_data_id")
	private Integer messageDataId;

	@Column(name = "email", nullable = false)
	private String emailBody;

	@Column(name = "unique_mail_body", columnDefinition = "TEXT")
	private String uniqueEmailBody;

	@OneToOne
	@JoinColumn(name = "email_metaData_id", nullable = false)
	private EmailMetadata emailMetaData;

	public String getEmailBody() {
		return emailBody;
	}

	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

	public String getUniqueEmailBody() {
		return uniqueEmailBody;
	}

	public void setUniqueEmailBody(String uniqueEmailBody) {
		this.uniqueEmailBody = uniqueEmailBody;
	}

	public EmailMetadata getEmailMetaData() {
		return emailMetaData;
	}

	public void setEmailMetaData(EmailMetadata emailMetaData) {
		this.emailMetaData = emailMetaData;
	}

	@Override
	public String toString() {
		return "EmailMessage [emailBody=" + emailBody + ", uniqueEmailBody=" + uniqueEmailBody + ", emailMetaData="
				+ emailMetaData + "]";
	}

	public Integer getMessageDataId() {
		return messageDataId;
	}

	public void setMessageDataId(Integer messageDataId) {
		this.messageDataId = messageDataId;
	}

}
