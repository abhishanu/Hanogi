--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 10.6

-- Started on 2019-01-18 18:39:11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3383 (class 0 OID 0)
-- Dependencies: 3382
-- Name: DATABASE "Batch_Process"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "Batch_Process" IS 'Process batch jobs ';


--
-- TOC entry 1 (class 3079 OID 12924)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 3385 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 196 (class 1259 OID 17248)
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    account_id integer NOT NULL,
    account_name character varying(30) NOT NULL,
    account_code character varying(15) NOT NULL,
    account_desc character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.account OWNER TO postgres;

--
-- TOC entry 3386 (class 0 OID 0)
-- Dependencies: 196
-- Name: TABLE account; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.account IS 'Master table for all the Accounts inside a division';


--
-- TOC entry 3387 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.account_id IS 'It represents the Account Id within a division';


--
-- TOC entry 3388 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.account_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.account_name IS 'The  Acoount name';


--
-- TOC entry 3389 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.account_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.account_code IS 'The shortcode for the account';


--
-- TOC entry 3390 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.account_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.account_desc IS 'The description of the account';


--
-- TOC entry 3391 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3392 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3393 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3394 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3395 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3396 (class 0 OID 0)
-- Dependencies: 196
-- Name: COLUMN account.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 197 (class 1259 OID 17258)
-- Name: account_group_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_group_mapping (
    group_id integer NOT NULL,
    account_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.account_group_mapping OWNER TO postgres;

--
-- TOC entry 3397 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.group_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.group_id IS 'It represents the Group Id within a account';


--
-- TOC entry 3398 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.account_id IS 'It represents the Account Id within a division';


--
-- TOC entry 3399 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3400 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3401 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3402 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3403 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3404 (class 0 OID 0)
-- Dependencies: 197
-- Name: COLUMN account_group_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.account_group_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 198 (class 1259 OID 17262)
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    address_id integer NOT NULL,
    location_id integer NOT NULL,
    address_details character varying(200) NOT NULL,
    zip_code character varying(15) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.address OWNER TO postgres;

--
-- TOC entry 3405 (class 0 OID 0)
-- Dependencies: 198
-- Name: TABLE address; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.address IS 'This table contains the address details of the actors client/employee/legal entity';


--
-- TOC entry 3406 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.address_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.address_id IS 'This is Address id for the address details';


--
-- TOC entry 3407 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.location_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.location_id IS 'The location details relevant to this address';


--
-- TOC entry 3408 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.address_details; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.address_details IS 'This contains the address (Building, Street, Locality etc)';


--
-- TOC entry 3409 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.zip_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.zip_code IS 'The ZIP code of the address';


--
-- TOC entry 3410 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3411 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3412 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3413 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3414 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3415 (class 0 OID 0)
-- Dependencies: 198
-- Name: COLUMN address.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.address.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 230 (class 1259 OID 17474)
-- Name: aggregated_tone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aggregated_tone (
    aggregated_tone_id integer NOT NULL,
    aggregated_tone text NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.aggregated_tone OWNER TO postgres;

--
-- TOC entry 3416 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE aggregated_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.aggregated_tone IS 'Aggregated tone details';


--
-- TOC entry 3417 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.aggregated_tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.aggregated_tone_id IS 'Aggregated Tone id';


--
-- TOC entry 3418 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.aggregated_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.aggregated_tone IS 'The JSON message for the tone details of the email';


--
-- TOC entry 3419 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3420 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3421 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3422 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3423 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3424 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN aggregated_tone.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.aggregated_tone.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 240 (class 1259 OID 19877)
-- Name: batch_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.batch_details (
    batch_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    batch_run_date timestamp without time zone,
    batch_status integer,
    batch_status_details text,
    batch_type_id character varying(255),
    from_date timestamp without time zone,
    to_date timestamp without time zone,
    version_num integer
);


ALTER TABLE public.batch_details OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 19885)
-- Name: batch_run_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.batch_run_details (
    batch_run_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    batch_job_id character varying(255),
    batch_run_date character varying(255) NOT NULL,
    batch_status_details text,
    from_date timestamp without time zone,
    status character varying(255),
    to_date timestamp without time zone,
    version_num integer,
    batch_status_id integer NOT NULL,
    batch_run_type_id integer
);


ALTER TABLE public.batch_run_details OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 19893)
-- Name: batch_run_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.batch_run_type (
    batch_run_type_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    batch_run_type_desc character varying(255),
    batch_run_type_name character varying(255)
);


ALTER TABLE public.batch_run_type OWNER TO postgres;

--
-- TOC entry 199 (class 1259 OID 17268)
-- Name: branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.branch (
    branch_id integer NOT NULL,
    legal_entity_id integer NOT NULL,
    address_id integer NOT NULL,
    branch_name character varying(100) NOT NULL,
    branch_code character varying(15) NOT NULL,
    descritption character varying(200),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.branch OWNER TO postgres;

--
-- TOC entry 3425 (class 0 OID 0)
-- Dependencies: 199
-- Name: TABLE branch; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.branch IS 'This table captures the details of all the branches of  legal entity to which the Client/Employee belongs';


--
-- TOC entry 3426 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.branch_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.branch_id IS 'This represents the brach office of the legal entity  & is the primary key ';


--
-- TOC entry 3427 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.legal_entity_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.legal_entity_id IS 'The legal entity to which the branch belongs';


--
-- TOC entry 3428 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.address_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.address_id IS 'The  address to which the legal entity belongs';


--
-- TOC entry 3429 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.branch_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.branch_name IS 'The name of the branch';


--
-- TOC entry 3430 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.branch_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.branch_code IS 'Branch Code';


--
-- TOC entry 3431 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.descritption; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.descritption IS 'Description about the about';


--
-- TOC entry 3432 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3433 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3434 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3435 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3436 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3437 (class 0 OID 0)
-- Dependencies: 199
-- Name: COLUMN branch.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.branch.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 202 (class 1259 OID 17294)
-- Name: bu_divison_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bu_divison_mapping (
    business_unit_id integer NOT NULL,
    division_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.bu_divison_mapping OWNER TO postgres;

--
-- TOC entry 3438 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.business_unit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.business_unit_id IS 'The businees unit ';


--
-- TOC entry 3439 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.division_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.division_id IS 'The Divison in the businees unit ';


--
-- TOC entry 3440 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3441 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3442 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3443 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3444 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3445 (class 0 OID 0)
-- Dependencies: 202
-- Name: COLUMN bu_divison_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bu_divison_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 200 (class 1259 OID 17274)
-- Name: business_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_group (
    group_id integer NOT NULL,
    group_name character varying(30) NOT NULL,
    group_code character varying(15) NOT NULL,
    group_desc character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.business_group OWNER TO postgres;

--
-- TOC entry 3446 (class 0 OID 0)
-- Dependencies: 200
-- Name: TABLE business_group; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.business_group IS 'Master table for all the Group inside a Account';


--
-- TOC entry 3447 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.group_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.group_id IS 'It represents the Group Id within a account';


--
-- TOC entry 3448 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.group_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.group_name IS 'The  Group name';


--
-- TOC entry 3449 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.group_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.group_code IS 'The shortcode for the Group';


--
-- TOC entry 3450 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.group_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.group_desc IS 'The description of the group';


--
-- TOC entry 3451 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3452 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3453 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3454 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3455 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3456 (class 0 OID 0)
-- Dependencies: 200
-- Name: COLUMN business_group.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_group.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 201 (class 1259 OID 17284)
-- Name: business_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_unit (
    business_unit_id integer NOT NULL,
    business_unit_name character varying(20) NOT NULL,
    business_unit_code character varying(10) NOT NULL,
    business_unit_desc character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.business_unit OWNER TO postgres;

--
-- TOC entry 3457 (class 0 OID 0)
-- Dependencies: 201
-- Name: TABLE business_unit; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.business_unit IS 'Master table for all the department for Client/Employee/Legal Entity';


--
-- TOC entry 3458 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.business_unit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.business_unit_id IS 'The businees unit ';


--
-- TOC entry 3459 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.business_unit_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.business_unit_name IS 'The name of the business unit';


--
-- TOC entry 3460 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.business_unit_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.business_unit_code IS 'The shortcode for the business unit';


--
-- TOC entry 3461 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.business_unit_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.business_unit_desc IS 'The description of the business unit';


--
-- TOC entry 3462 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3463 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3464 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3465 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3466 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3467 (class 0 OID 0)
-- Dependencies: 201
-- Name: COLUMN business_unit.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.business_unit.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 231 (class 1259 OID 17500)
-- Name: calculated_tone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calculated_tone (
    calculated_tone_id integer NOT NULL,
    calculated_tone text NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.calculated_tone OWNER TO postgres;

--
-- TOC entry 3468 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE calculated_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.calculated_tone IS 'Calculated tone of the item';


--
-- TOC entry 3469 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.calculated_tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.calculated_tone_id IS 'Calculated Tone Id';


--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.calculated_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.calculated_tone IS 'The JSON message for the tone details of the email';


--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3475 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3476 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN calculated_tone.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.calculated_tone.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 203 (class 1259 OID 17298)
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    city_id integer NOT NULL,
    city_name character varying(20) NOT NULL,
    city_code character varying(10) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.city OWNER TO postgres;

--
-- TOC entry 3477 (class 0 OID 0)
-- Dependencies: 203
-- Name: TABLE city; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.city IS 'Master table to hold the data for all the city';


--
-- TOC entry 3478 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.city_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.city_id IS 'The id for the City';


--
-- TOC entry 3479 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.city_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.city_name IS 'City Name';


--
-- TOC entry 3480 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.city_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.city_code IS 'Small Code for the City';


--
-- TOC entry 3481 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3482 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3483 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3484 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3485 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3486 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN city.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.city.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 204 (class 1259 OID 17304)
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    client_id integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    middle_name character varying(20),
    legal_entity_id integer NOT NULL,
    work_location_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.client OWNER TO postgres;

--
-- TOC entry 3487 (class 0 OID 0)
-- Dependencies: 204
-- Name: TABLE client; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.client IS 'This table describes the attributes corresponding to the Client.';


--
-- TOC entry 3488 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.client_id IS 'ClientId used for internal purpose by the Batch Process';


--
-- TOC entry 3489 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.first_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.first_name IS 'This denotes the first name of the actor';


--
-- TOC entry 3490 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.last_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.last_name IS 'Last name of the actor';


--
-- TOC entry 3491 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.middle_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.middle_name IS 'Middle name of the actor';


--
-- TOC entry 3492 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.legal_entity_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.legal_entity_id IS 'The legal entity/office/subsidary in which actor works';


--
-- TOC entry 3493 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.work_location_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.work_location_id IS 'The branch office in which the actor works';


--
-- TOC entry 3494 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3495 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3496 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3497 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3498 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3499 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN client.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 205 (class 1259 OID 17310)
-- Name: client_emailid_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_emailid_mapping (
    email_id character varying(30) NOT NULL,
    client_id integer NOT NULL,
    analyse_tone character(1) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.client_emailid_mapping OWNER TO postgres;

--
-- TOC entry 3500 (class 0 OID 0)
-- Dependencies: 205
-- Name: TABLE client_emailid_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.client_emailid_mapping IS 'Mapping table to represent the mapping of an client to its email ids';


--
-- TOC entry 3501 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.email_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.email_id IS 'This represents the email id of the actor';


--
-- TOC entry 3502 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.client_id IS 'ClientId used for internal purpose by the Batch Process';


--
-- TOC entry 3503 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.analyse_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.analyse_tone IS 'Whether to enable the email id for tone analysis';


--
-- TOC entry 3504 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3505 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3506 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3507 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3508 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3509 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN client_emailid_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_emailid_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 206 (class 1259 OID 17314)
-- Name: client_employee_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_employee_mapping (
    client_id integer NOT NULL,
    employee_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.client_employee_mapping OWNER TO postgres;

--
-- TOC entry 3510 (class 0 OID 0)
-- Dependencies: 206
-- Name: TABLE client_employee_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.client_employee_mapping IS 'Mapping table for Clients to Employee';


--
-- TOC entry 3511 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.client_id IS 'ClientId used for internal purpose by the Batch Process';


--
-- TOC entry 3512 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.employee_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.employee_id IS 'Employee Id used for internal purpose by the Batch Process';


--
-- TOC entry 3513 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN client_employee_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_employee_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 207 (class 1259 OID 17320)
-- Name: client_hirerachy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_hirerachy (
    hierarchy_id integer NOT NULL,
    client_id integer NOT NULL,
    reports_to_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.client_hirerachy OWNER TO postgres;

--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE client_hirerachy; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.client_hirerachy IS 'This table will contains the Client Hirerachy to capture the org tree';


--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.hierarchy_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.hierarchy_id IS 'The id for the hierarchy relationship';


--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.client_id IS 'The employee id of the employee';


--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.reports_to_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.reports_to_id IS 'The employee id of the person to which this person reports';


--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3527 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3528 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN client_hirerachy.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_hirerachy.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 208 (class 1259 OID 17326)
-- Name: client_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_role_mapping (
    client_id integer NOT NULL,
    role_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.client_role_mapping OWNER TO postgres;

--
-- TOC entry 3529 (class 0 OID 0)
-- Dependencies: 208
-- Name: TABLE client_role_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.client_role_mapping IS 'Mapping table for the Client & its Role';


--
-- TOC entry 3530 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.client_id IS 'ClientId used for internal purpose by the Batch Process';


--
-- TOC entry 3531 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.role_id IS 'The role id of the role assigned';


--
-- TOC entry 3532 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3533 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 208
-- Name: COLUMN client_role_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_role_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 209 (class 1259 OID 17332)
-- Name: client_work_unit_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_work_unit_mapping (
    client_id integer NOT NULL,
    work_unit_type_id integer NOT NULL,
    work_unit_id integer,
    is_owner character(1) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.client_work_unit_mapping OWNER TO postgres;

--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 209
-- Name: TABLE client_work_unit_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.client_work_unit_mapping IS 'This table maps the employee to the work unit at the lowest level. An employee can belong to multiple work uints';


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.client_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.client_id IS 'ClientId used for internal purpose by the Batch Process';


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.work_unit_type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.work_unit_type_id IS 'Type of work unit to which employee belongs - It will be the lowest level in his hirerachy. ';


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.work_unit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.work_unit_id IS 'The id of the work unit';


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.is_owner; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.is_owner IS 'Whether the employee is owner of this work unit ';


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3547 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3548 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN client_work_unit_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.client_work_unit_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 210 (class 1259 OID 17338)
-- Name: continent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.continent (
    continent_id character varying(20) NOT NULL,
    continent_name character varying(20) NOT NULL,
    continent_code character varying(10) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.continent OWNER TO postgres;

--
-- TOC entry 3549 (class 0 OID 0)
-- Dependencies: 210
-- Name: TABLE continent; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.continent IS 'Master table to hold the data for all the continents';


--
-- TOC entry 3550 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.continent_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.continent_id IS 'Continent ID';


--
-- TOC entry 3551 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.continent_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.continent_name IS 'Continent Name';


--
-- TOC entry 3552 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.continent_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.continent_code IS 'Small Code for the Continent';


--
-- TOC entry 3553 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3554 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3555 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3556 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3557 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3558 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN continent.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 211 (class 1259 OID 17344)
-- Name: continent_country_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.continent_country_mapping (
    continent_id character varying(20) NOT NULL,
    country_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.continent_country_mapping OWNER TO postgres;

--
-- TOC entry 3559 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.continent_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.continent_id IS 'Continent ID';


--
-- TOC entry 3560 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.country_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.country_id IS 'The id for the Country';


--
-- TOC entry 3561 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3562 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3563 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3564 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3565 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3566 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN continent_country_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.continent_country_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 212 (class 1259 OID 17348)
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    country_id integer NOT NULL,
    country_name character varying(20) NOT NULL,
    country_code character varying(10) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.country OWNER TO postgres;

--
-- TOC entry 3567 (class 0 OID 0)
-- Dependencies: 212
-- Name: TABLE country; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.country IS 'Master table to hold the data for all the countries';


--
-- TOC entry 3568 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.country_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.country_id IS 'The id for the Country';


--
-- TOC entry 3569 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.country_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.country_name IS 'Country Name';


--
-- TOC entry 3570 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.country_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.country_code IS 'Small Code for the Country';


--
-- TOC entry 3571 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3572 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3573 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3574 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3575 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3576 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN country.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 213 (class 1259 OID 17354)
-- Name: country_district_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country_district_mapping (
    country_id integer NOT NULL,
    district_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.country_district_mapping OWNER TO postgres;

--
-- TOC entry 3577 (class 0 OID 0)
-- Dependencies: 213
-- Name: TABLE country_district_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.country_district_mapping IS 'Country District Mapping table';


--
-- TOC entry 3578 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.country_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.country_id IS 'The id for the Country';


--
-- TOC entry 3579 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.district_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.district_id IS 'The id for the District';


--
-- TOC entry 3580 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3581 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3582 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3583 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3584 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3585 (class 0 OID 0)
-- Dependencies: 213
-- Name: COLUMN country_district_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.country_district_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 232 (class 1259 OID 17509)
-- Name: data_classification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_classification (
    classification_category_id integer NOT NULL,
    classification_category_name character varying(50),
    classification_category_desc character varying(150),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.data_classification OWNER TO postgres;

--
-- TOC entry 3586 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE data_classification; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.data_classification IS 'Master table that defines the various categories in which the data can be classified';


--
-- TOC entry 3587 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.classification_category_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.classification_category_id IS 'The ID for the data classification type';


--
-- TOC entry 3588 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.classification_category_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.classification_category_name IS 'The name of the classification categoreis (Information Query, Complaints, Services, Extras, Application Status etc.)';


--
-- TOC entry 3589 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.classification_category_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.classification_category_desc IS 'Description of the category';


--
-- TOC entry 3590 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3591 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3592 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3593 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3594 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3595 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN data_classification.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.data_classification.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 214 (class 1259 OID 17358)
-- Name: district; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.district (
    district_id integer NOT NULL,
    district_name character varying(20) NOT NULL,
    district_code character varying(10) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.district OWNER TO postgres;

--
-- TOC entry 3596 (class 0 OID 0)
-- Dependencies: 214
-- Name: TABLE district; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.district IS 'Master table to hold the data for all the district';


--
-- TOC entry 3597 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.district_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.district_id IS 'The id for the District';


--
-- TOC entry 3598 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.district_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.district_name IS 'District Name';


--
-- TOC entry 3599 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.district_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.district_code IS 'Small Code for the District';


--
-- TOC entry 3600 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3601 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3602 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3603 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3604 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3605 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN district.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 215 (class 1259 OID 17364)
-- Name: district_city_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.district_city_mapping (
    district_id integer NOT NULL,
    city_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.district_city_mapping OWNER TO postgres;

--
-- TOC entry 3606 (class 0 OID 0)
-- Dependencies: 215
-- Name: TABLE district_city_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.district_city_mapping IS 'Mapping table for District to City';


--
-- TOC entry 3607 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.district_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.district_id IS 'The id for the District';


--
-- TOC entry 3608 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.city_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.city_id IS 'The id for the City';


--
-- TOC entry 3609 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3610 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3611 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3612 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3613 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3614 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN district_city_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.district_city_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 216 (class 1259 OID 17368)
-- Name: division; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.division (
    division_id integer NOT NULL,
    division_name character varying(30) NOT NULL,
    division_code character varying(15) NOT NULL,
    division_desc character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.division OWNER TO postgres;

--
-- TOC entry 3615 (class 0 OID 0)
-- Dependencies: 216
-- Name: TABLE division; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.division IS 'Master table for all the Divisons in the legal entity';


--
-- TOC entry 3616 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.division_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.division_id IS 'The Divison in the businees unit ';


--
-- TOC entry 3617 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.division_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.division_name IS 'The  divison name in the business unit';


--
-- TOC entry 3618 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.division_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.division_code IS 'The shortcode for the division';


--
-- TOC entry 3619 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.division_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.division_desc IS 'The description of the business unit';


--
-- TOC entry 3620 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3621 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3622 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3623 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3624 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3625 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN division.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.division.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 217 (class 1259 OID 17378)
-- Name: divison_account_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.divison_account_mapping (
    division_id integer NOT NULL,
    account_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.divison_account_mapping OWNER TO postgres;

--
-- TOC entry 3626 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.division_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.division_id IS 'The Divison in the businees unit ';


--
-- TOC entry 3627 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.account_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.account_id IS 'It represents the Account Id within a division';


--
-- TOC entry 3628 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3629 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3630 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3631 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3632 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3633 (class 0 OID 0)
-- Dependencies: 217
-- Name: COLUMN divison_account_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.divison_account_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 243 (class 1259 OID 19901)
-- Name: email_domain_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_domain_details (
    email_domain_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    email_domain_name character varying(255),
    email_server_config character varying(255),
    email_service_provider character varying(255),
    server_deployment_type character varying(255),
    status character varying(255),
    version_num integer
);


ALTER TABLE public.email_domain_details OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 17524)
-- Name: email_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_header (
    email_metadata_id integer NOT NULL,
    email_date date NOT NULL,
    subject character varying(200) NOT NULL,
    importance character varying(20),
    message_id character varying(300),
    in_reply_to character varying(300),
    sender_ip character varying(20) NOT NULL,
    content_language character varying(50) NOT NULL,
    cc_email_id text,
    to_email_id text NOT NULL,
    reference_message_id text,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.email_header OWNER TO postgres;

--
-- TOC entry 3634 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE email_header; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.email_header IS 'The table will capture all the  header data  for the email';


--
-- TOC entry 3635 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.email_metadata_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.email_metadata_id IS 'The Email Meta data Id to which this header belongs';


--
-- TOC entry 3636 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.email_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.email_date IS 'The date on which the email is sent or received';


--
-- TOC entry 3637 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.subject; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.subject IS 'Subject of the email';


--
-- TOC entry 3638 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.importance; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.importance IS 'Importance of the email';


--
-- TOC entry 3639 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.message_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.message_id IS 'Message ID of the email as generated by the Exchange server';


--
-- TOC entry 3640 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.in_reply_to; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.in_reply_to IS 'The Message ID of the email on whose reply the mail has been sent';


--
-- TOC entry 3641 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.sender_ip; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.sender_ip IS 'The IP of the sender ';


--
-- TOC entry 3642 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.content_language; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.content_language IS 'The content language of the email';


--
-- TOC entry 3643 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.cc_email_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.cc_email_id IS 'CC Email id list (JSON)';


--
-- TOC entry 3644 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.to_email_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.to_email_id IS 'TO Email id List(JSON)';


--
-- TOC entry 3645 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.reference_message_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.reference_message_id IS 'Message id of reference mails';


--
-- TOC entry 3646 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3647 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3648 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3649 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3650 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3651 (class 0 OID 0)
-- Dependencies: 233
-- Name: COLUMN email_header.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_header.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 249 (class 1259 OID 28516)
-- Name: email_message_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_message_data (
    email character varying(255) NOT NULL,
    unique_mail_body text,
    email_meta_data_id integer NOT NULL,
    message_data_id integer NOT NULL
);


ALTER TABLE public.email_message_data OWNER TO postgres;

--
-- TOC entry 250 (class 1259 OID 29772)
-- Name: email_message_data_message_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_message_data_message_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_message_data_message_data_id_seq OWNER TO postgres;

--
-- TOC entry 3652 (class 0 OID 0)
-- Dependencies: 250
-- Name: email_message_data_message_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_message_data_message_data_id_seq OWNED BY public.email_message_data.message_data_id;


--
-- TOC entry 234 (class 1259 OID 17533)
-- Name: email_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_metadata (
    email_metadata_id integer NOT NULL,
    aggregated_tone_id integer NOT NULL,
    calculated_tone_id integer NOT NULL,
    indvidual_tone_id integer NOT NULL,
    email_direction character varying(50),
    from_email_id character varying(30),
    batch_run_id integer NOT NULL,
    email_processing_status_id integer NOT NULL,
    data_classification_id integer,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone,
    from_mail_id character varying(255)
);


ALTER TABLE public.email_metadata OWNER TO postgres;

--
-- TOC entry 3653 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE email_metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.email_metadata IS 'This table will contain all the metadata details related to email & email tone';


--
-- TOC entry 3654 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.email_metadata_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.email_metadata_id IS 'Represents the ID for the EMAIL details';


--
-- TOC entry 3655 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.aggregated_tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.aggregated_tone_id IS 'The Aggregated tone of the email';


--
-- TOC entry 3656 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.calculated_tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.calculated_tone_id IS 'The calculated tone of the email ';


--
-- TOC entry 3657 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.indvidual_tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.indvidual_tone_id IS 'The tone id for every line in the email';


--
-- TOC entry 3658 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.email_direction; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.email_direction IS 'Direction of Email (Sent or Received)';


--
-- TOC entry 3659 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.from_email_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.from_email_id IS 'Email id from whom the email has been received';


--
-- TOC entry 3660 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.batch_run_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.batch_run_id IS 'The Id of the Batch which has processed the mail';


--
-- TOC entry 3661 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.email_processing_status_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.email_processing_status_id IS 'The processing status of the email (Completed, Failure, Inprogress)';


--
-- TOC entry 3662 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.data_classification_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.data_classification_id IS 'The data classification category in to which the email falls';


--
-- TOC entry 3663 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3664 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3665 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3666 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3667 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3668 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN email_metadata.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.email_metadata.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 244 (class 1259 OID 19909)
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email_preferences (
    email_preference_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    email_preferences text,
    status character varying(255),
    version_num integer
);


ALTER TABLE public.email_preferences OWNER TO postgres;

--
-- TOC entry 245 (class 1259 OID 19917)
-- Name: emailid; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.emailid (
    email_id character varying(255) NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    emailid_domain_type character varying(255),
    emailid_type_id character varying(255),
    status character varying(255),
    version_num integer,
    email_domain_id integer,
    email_preference_id integer
);


ALTER TABLE public.emailid OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 17388)
-- Name: emailid_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.emailid_type (
    emailid_type_id integer NOT NULL,
    type_name character varying(20) NOT NULL,
    type_description character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.emailid_type OWNER TO postgres;

--
-- TOC entry 3669 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE emailid_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.emailid_type IS 'Master table to define the various types of email id that can exits - INDIVIDUAL, WORK UNIT DL, SUPPORT DL etc';


--
-- TOC entry 3670 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.emailid_type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.emailid_type_id IS 'Id for the Email Type';


--
-- TOC entry 3671 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.type_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.type_name IS 'The name of the Email type';


--
-- TOC entry 3672 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.type_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.type_description IS 'Description of the email type';


--
-- TOC entry 3673 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3674 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3675 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3676 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3677 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3678 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN emailid_type.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.emailid_type.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 246 (class 1259 OID 19925)
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    middle_name character varying(255),
    status character varying(255),
    version_num integer
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 19933)
-- Name: employee_emailid_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_emailid_mapping (
    email_id character varying(255) NOT NULL,
    employee_id character varying(255) NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    analyse_tone character varying(255),
    status character varying(255),
    version_num integer
);


ALTER TABLE public.employee_emailid_mapping OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 17404)
-- Name: employee_hirerachy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_hirerachy (
    hierarchy_id integer NOT NULL,
    employee_id integer NOT NULL,
    reports_to_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.employee_hirerachy OWNER TO postgres;

--
-- TOC entry 3679 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE employee_hirerachy; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.employee_hirerachy IS 'This table will contains the Employee Hirerachy to capture the org tree';


--
-- TOC entry 3680 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.hierarchy_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.hierarchy_id IS 'The id for the hierarchy relationship';


--
-- TOC entry 3681 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.employee_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.employee_id IS 'The employee id of the employee';


--
-- TOC entry 3682 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.reports_to_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.reports_to_id IS 'The employee id of the person to which this person reports';


--
-- TOC entry 3683 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3684 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3685 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3686 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3687 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3688 (class 0 OID 0)
-- Dependencies: 219
-- Name: COLUMN employee_hirerachy.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_hirerachy.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 220 (class 1259 OID 17410)
-- Name: employee_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_role_mapping (
    employee_id integer NOT NULL,
    role_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.employee_role_mapping OWNER TO postgres;

--
-- TOC entry 3689 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.employee_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.employee_id IS 'Employee Id used for internal purpose by the Batch Process';


--
-- TOC entry 3690 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.role_id IS 'The role id of the role assigned';


--
-- TOC entry 3691 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3692 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3693 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3694 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3695 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3696 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN employee_role_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_role_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 221 (class 1259 OID 17416)
-- Name: employee_work_unit_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_work_unit_mapping (
    employee_id integer NOT NULL,
    work_unit_type_id integer NOT NULL,
    work_unit_id integer,
    is_owner character(1) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.employee_work_unit_mapping OWNER TO postgres;

--
-- TOC entry 3697 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE employee_work_unit_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.employee_work_unit_mapping IS 'This table maps the employee to the work unit at the lowest level. An employee can belong to multiple work uints';


--
-- TOC entry 3698 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.employee_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.employee_id IS 'Employee Id used for internal purpose by the Batch Process';


--
-- TOC entry 3699 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.work_unit_type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.work_unit_type_id IS 'Type of work unit to which employee belongs - It will be the lowest level in his hirerachy. ';


--
-- TOC entry 3700 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.work_unit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.work_unit_id IS 'The id of the work unit';


--
-- TOC entry 3701 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.is_owner; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.is_owner IS 'Whether the employee is owner of this work unit ';


--
-- TOC entry 3702 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3703 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3704 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3705 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3706 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3707 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN employee_work_unit_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.employee_work_unit_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 222 (class 1259 OID 17422)
-- Name: entity_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entity_type (
    type_id integer NOT NULL,
    type_name character varying(15) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.entity_type OWNER TO postgres;

--
-- TOC entry 3708 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE entity_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.entity_type IS 'Master table that describes the different type of legal entities Internal/ External(Client)';


--
-- TOC entry 3709 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.type_id IS 'The ID for the entity type';


--
-- TOC entry 3710 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.type_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.type_name IS 'The type name of the entity';


--
-- TOC entry 3711 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3712 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3713 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3714 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3715 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3716 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN entity_type.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.entity_type.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 248 (class 1259 OID 19941)
-- Name: execution_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.execution_status (
    status_id integer NOT NULL,
    created_by character varying(255),
    created_on timestamp without time zone,
    updated_by character varying(255),
    updated_on timestamp without time zone,
    status_desc character varying(255),
    status_name character varying(255)
);


ALTER TABLE public.execution_status OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 17428)
-- Name: geo_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_location (
    location_id integer NOT NULL,
    continent_id character varying(20) NOT NULL,
    country_id integer NOT NULL,
    district_id integer NOT NULL,
    city_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.geo_location OWNER TO postgres;

--
-- TOC entry 3717 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE geo_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.geo_location IS 'This table captures the location details of any actor (Client/Legal Entity/Employee) in the entire system';


--
-- TOC entry 3718 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.location_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.location_id IS 'This is the Id for the location and is primary key for the Table ';


--
-- TOC entry 3719 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.continent_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.continent_id IS 'Describes the continent Id for the location';


--
-- TOC entry 3720 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.country_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.country_id IS 'The country Id for the location';


--
-- TOC entry 3721 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.district_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.district_id IS 'The disctrict to which it belongs';


--
-- TOC entry 3722 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.city_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.city_id IS 'Describes the city_id ';


--
-- TOC entry 3723 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3724 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3725 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3726 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3727 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3728 (class 0 OID 0)
-- Dependencies: 223
-- Name: COLUMN geo_location.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_location.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 224 (class 1259 OID 17434)
-- Name: group_team_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_team_mapping (
    team_id integer NOT NULL,
    group_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.group_team_mapping OWNER TO postgres;

--
-- TOC entry 3729 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.team_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.team_id IS 'It represents the Team Id within a group';


--
-- TOC entry 3730 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.group_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.group_id IS 'It represents the Group Id within a account';


--
-- TOC entry 3731 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3732 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3733 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3734 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3735 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3736 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN group_team_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.group_team_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 235 (class 1259 OID 17545)
-- Name: individual_tone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.individual_tone (
    individual_tone_id integer NOT NULL,
    individual_tone text NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.individual_tone OWNER TO postgres;

--
-- TOC entry 3737 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE individual_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.individual_tone IS 'Individual tone of the item';


--
-- TOC entry 3738 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.individual_tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.individual_tone_id IS 'Individual Tone Id';


--
-- TOC entry 3739 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.individual_tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.individual_tone IS 'The JSON message for the tone details of the email';


--
-- TOC entry 3740 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3741 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3742 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3743 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3744 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3745 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN individual_tone.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.individual_tone.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 225 (class 1259 OID 17438)
-- Name: legal_entity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_entity (
    legal_entity_id integer NOT NULL,
    address_id integer NOT NULL,
    type_id integer NOT NULL,
    entity_name character varying(100) NOT NULL,
    entity_code character varying(15) NOT NULL,
    descritption character varying(200),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.legal_entity OWNER TO postgres;

--
-- TOC entry 3746 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE legal_entity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.legal_entity IS 'This table captures the details of the legal entity to which the Client/Employee belongs';


--
-- TOC entry 3747 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.legal_entity_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.legal_entity_id IS 'This represents the legal entity id & is the primary key ';


--
-- TOC entry 3748 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.address_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.address_id IS 'The  address to which the legal entity belongs';


--
-- TOC entry 3749 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.type_id IS 'This represents the type of the legal entity whether internal or client legal entity';


--
-- TOC entry 3750 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.entity_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.entity_name IS 'The name of the legal entity';


--
-- TOC entry 3751 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.entity_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.entity_code IS 'Entity Code';


--
-- TOC entry 3752 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.descritption; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.descritption IS 'Description about the about';


--
-- TOC entry 3753 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3754 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3755 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3756 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3757 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3758 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN legal_entity.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.legal_entity.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 256 (class 1259 OID 30066)
-- Name: qrtz_blob_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE public.qrtz_blob_triggers OWNER TO postgres;

--
-- TOC entry 257 (class 1259 OID 30079)
-- Name: qrtz_calendars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE public.qrtz_calendars OWNER TO postgres;

--
-- TOC entry 254 (class 1259 OID 30040)
-- Name: qrtz_cron_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(120) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE public.qrtz_cron_triggers OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 17933)
-- Name: qrtz_fired_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    sched_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent boolean,
    requests_recovery boolean
);


ALTER TABLE public.qrtz_fired_triggers OWNER TO postgres;

--
-- TOC entry 251 (class 1259 OID 30006)
-- Name: qrtz_job_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    is_nonconcurrent boolean NOT NULL,
    is_update_data boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


ALTER TABLE public.qrtz_job_details OWNER TO postgres;

--
-- TOC entry 260 (class 1259 OID 30097)
-- Name: qrtz_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


ALTER TABLE public.qrtz_locks OWNER TO postgres;

--
-- TOC entry 258 (class 1259 OID 30087)
-- Name: qrtz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


ALTER TABLE public.qrtz_paused_trigger_grps OWNER TO postgres;

--
-- TOC entry 259 (class 1259 OID 30092)
-- Name: qrtz_scheduler_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE public.qrtz_scheduler_state OWNER TO postgres;

--
-- TOC entry 253 (class 1259 OID 30027)
-- Name: qrtz_simple_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE public.qrtz_simple_triggers OWNER TO postgres;

--
-- TOC entry 255 (class 1259 OID 30053)
-- Name: qrtz_simprop_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 boolean,
    bool_prop_2 boolean
);


ALTER TABLE public.qrtz_simprop_triggers OWNER TO postgres;

--
-- TOC entry 252 (class 1259 OID 30014)
-- Name: qrtz_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qrtz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr smallint,
    job_data bytea
);


ALTER TABLE public.qrtz_triggers OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 17444)
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    role_id integer NOT NULL,
    role_name character varying(20) NOT NULL,
    role_code character varying(10) NOT NULL,
    role_desc character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.role OWNER TO postgres;

--
-- TOC entry 3759 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE role; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.role IS 'Master table for all the roles of Client/Employee/Legal Entity';


--
-- TOC entry 3760 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.role_id IS 'The role id of the role assigned';


--
-- TOC entry 3761 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.role_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.role_name IS 'The name of the role ';


--
-- TOC entry 3762 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.role_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.role_code IS 'The shortcode for the role ';


--
-- TOC entry 3763 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.role_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.role_desc IS 'The description of the role ';


--
-- TOC entry 3764 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3765 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3766 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3767 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3768 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3769 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN role.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.role.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 239 (class 1259 OID 19868)
-- Name: scheduler_job_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduler_job_info (
    id bigint NOT NULL,
    batch_id integer,
    cron_expression character varying(255),
    cron_job boolean,
    is_active boolean,
    job_group character varying(255),
    job_name character varying(255),
    repeat_time bigint
);


ALTER TABLE public.scheduler_job_info OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 19866)
-- Name: scheduler_job_info_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scheduler_job_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduler_job_info_id_seq OWNER TO postgres;

--
-- TOC entry 3770 (class 0 OID 0)
-- Dependencies: 238
-- Name: scheduler_job_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scheduler_job_info_id_seq OWNED BY public.scheduler_job_info.id;


--
-- TOC entry 227 (class 1259 OID 17454)
-- Name: team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team (
    team_id integer NOT NULL,
    team_name character varying(30) NOT NULL,
    team_code character varying(15) NOT NULL,
    team_desc character varying(50),
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.team OWNER TO postgres;

--
-- TOC entry 3771 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE team; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.team IS 'Master table for all the Team inside a Group';


--
-- TOC entry 3772 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.team_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.team_id IS 'It represents the Team Id within a group';


--
-- TOC entry 3773 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.team_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.team_name IS 'The  Team name';


--
-- TOC entry 3774 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.team_code; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.team_code IS 'The shortcode for the Team';


--
-- TOC entry 3775 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.team_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.team_desc IS 'The description of the team';


--
-- TOC entry 3776 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3777 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3778 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3779 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3780 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3781 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN team.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.team.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 236 (class 1259 OID 17554)
-- Name: tone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tone (
    tone_id integer NOT NULL,
    tone_name character varying(100) NOT NULL,
    tone_desc character varying(200) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.tone OWNER TO postgres;

--
-- TOC entry 3782 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE tone; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tone IS 'Master table to contain all the types of tone';


--
-- TOC entry 3783 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.tone_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.tone_id IS 'Id for the tone';


--
-- TOC entry 3784 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.tone_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.tone_name IS 'Name of the Tone';


--
-- TOC entry 3785 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.tone_desc; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.tone_desc IS 'Description of the tone';


--
-- TOC entry 3786 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3787 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3788 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3789 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3790 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3791 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN tone.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tone.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 229 (class 1259 OID 17470)
-- Name: work_unit_emailid_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.work_unit_emailid_mapping (
    email_id character varying(30) NOT NULL,
    work_unit_type_id integer NOT NULL,
    work_unit_id integer NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.work_unit_emailid_mapping OWNER TO postgres;

--
-- TOC entry 3792 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE work_unit_emailid_mapping; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.work_unit_emailid_mapping IS 'Mapping table to represent the mapping of an work units to its email ids';


--
-- TOC entry 3793 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.email_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.email_id IS 'This represents the email id of the actor';


--
-- TOC entry 3794 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.work_unit_type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.work_unit_type_id IS 'The id for the work unit';


--
-- TOC entry 3795 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.work_unit_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.work_unit_id IS 'The id of the work unit';


--
-- TOC entry 3796 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3797 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3798 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3799 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3800 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3801 (class 0 OID 0)
-- Dependencies: 229
-- Name: COLUMN work_unit_emailid_mapping.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_unit_emailid_mapping.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 228 (class 1259 OID 17464)
-- Name: work_units_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.work_units_types (
    work_unit_type_id integer NOT NULL,
    work_unit_type_name character varying(20) NOT NULL,
    created_by character varying(50),
    status character(1) DEFAULT 'Y'::bpchar,
    version_num integer,
    updated_on timestamp without time zone,
    updated_by character varying(50),
    created_on timestamp without time zone
);


ALTER TABLE public.work_units_types OWNER TO postgres;

--
-- TOC entry 3802 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE work_units_types; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.work_units_types IS 'Master table for the work units in a legal entity - BU, Division, Accounts etc';


--
-- TOC entry 3803 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.work_unit_type_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.work_unit_type_id IS 'The id for the work unit';


--
-- TOC entry 3804 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.work_unit_type_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.work_unit_type_name IS 'Work Unit Name';


--
-- TOC entry 3805 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.created_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.created_by IS 'The name/Id of the person who has created the record';


--
-- TOC entry 3806 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.status IS 'This field will specifiy whether the record is active or not. The default value is Y';


--
-- TOC entry 3807 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.version_num; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.version_num IS 'The version of this record and will be integer value starting from 1 to N';


--
-- TOC entry 3808 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.updated_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.updated_on IS 'The date & time when the record has been updated in the system';


--
-- TOC entry 3809 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.updated_by; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.updated_by IS 'The name/Id of the item that has updated this record';


--
-- TOC entry 3810 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN work_units_types.created_on; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.work_units_types.created_on IS 'Date & Time at which this record is created for the first time in the system';


--
-- TOC entry 2985 (class 2604 OID 29774)
-- Name: email_message_data message_data_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_message_data ALTER COLUMN message_data_id SET DEFAULT nextval('public.email_message_data_message_data_id_seq'::regclass);


--
-- TOC entry 2984 (class 2604 OID 19871)
-- Name: scheduler_job_info id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduler_job_info ALTER COLUMN id SET DEFAULT nextval('public.scheduler_job_info_id_seq'::regclass);


--
-- TOC entry 3312 (class 0 OID 17248)
-- Dependencies: 196
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (account_id, account_name, account_code, account_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3313 (class 0 OID 17258)
-- Dependencies: 197
-- Data for Name: account_group_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_group_mapping (group_id, account_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3314 (class 0 OID 17262)
-- Dependencies: 198
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (address_id, location_id, address_details, zip_code, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3346 (class 0 OID 17474)
-- Dependencies: 230
-- Data for Name: aggregated_tone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aggregated_tone (aggregated_tone_id, aggregated_tone, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3356 (class 0 OID 19877)
-- Dependencies: 240
-- Data for Name: batch_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.batch_details (batch_id, created_by, created_on, updated_by, updated_on, batch_run_date, batch_status, batch_status_details, batch_type_id, from_date, to_date, version_num) FROM stdin;
\.


--
-- TOC entry 3357 (class 0 OID 19885)
-- Dependencies: 241
-- Data for Name: batch_run_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.batch_run_details (batch_run_id, created_by, created_on, updated_by, updated_on, batch_job_id, batch_run_date, batch_status_details, from_date, status, to_date, version_num, batch_status_id, batch_run_type_id) FROM stdin;
10	\N	\N	\N	\N	1	2019-01-10	In_Progress	2018-12-26 00:00:00	1	2019-01-09 00:00:00	\N	1	1
\.


--
-- TOC entry 3358 (class 0 OID 19893)
-- Dependencies: 242
-- Data for Name: batch_run_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.batch_run_type (batch_run_type_id, created_by, created_on, updated_by, updated_on, batch_run_type_desc, batch_run_type_name) FROM stdin;
1	\N	\N	\N	\N		
\.


--
-- TOC entry 3315 (class 0 OID 17268)
-- Dependencies: 199
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.branch (branch_id, legal_entity_id, address_id, branch_name, branch_code, descritption, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3318 (class 0 OID 17294)
-- Dependencies: 202
-- Data for Name: bu_divison_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bu_divison_mapping (business_unit_id, division_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3316 (class 0 OID 17274)
-- Dependencies: 200
-- Data for Name: business_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_group (group_id, group_name, group_code, group_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3317 (class 0 OID 17284)
-- Dependencies: 201
-- Data for Name: business_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_unit (business_unit_id, business_unit_name, business_unit_code, business_unit_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3347 (class 0 OID 17500)
-- Dependencies: 231
-- Data for Name: calculated_tone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calculated_tone (calculated_tone_id, calculated_tone, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3319 (class 0 OID 17298)
-- Dependencies: 203
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city (city_id, city_name, city_code, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3320 (class 0 OID 17304)
-- Dependencies: 204
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (client_id, first_name, last_name, middle_name, legal_entity_id, work_location_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3321 (class 0 OID 17310)
-- Dependencies: 205
-- Data for Name: client_emailid_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_emailid_mapping (email_id, client_id, analyse_tone, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3322 (class 0 OID 17314)
-- Dependencies: 206
-- Data for Name: client_employee_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_employee_mapping (client_id, employee_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3323 (class 0 OID 17320)
-- Dependencies: 207
-- Data for Name: client_hirerachy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_hirerachy (hierarchy_id, client_id, reports_to_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3324 (class 0 OID 17326)
-- Dependencies: 208
-- Data for Name: client_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_role_mapping (client_id, role_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3325 (class 0 OID 17332)
-- Dependencies: 209
-- Data for Name: client_work_unit_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_work_unit_mapping (client_id, work_unit_type_id, work_unit_id, is_owner, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3326 (class 0 OID 17338)
-- Dependencies: 210
-- Data for Name: continent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.continent (continent_id, continent_name, continent_code, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3327 (class 0 OID 17344)
-- Dependencies: 211
-- Data for Name: continent_country_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.continent_country_mapping (continent_id, country_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3328 (class 0 OID 17348)
-- Dependencies: 212
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (country_id, country_name, country_code, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3329 (class 0 OID 17354)
-- Dependencies: 213
-- Data for Name: country_district_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country_district_mapping (country_id, district_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3348 (class 0 OID 17509)
-- Dependencies: 232
-- Data for Name: data_classification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_classification (classification_category_id, classification_category_name, classification_category_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3330 (class 0 OID 17358)
-- Dependencies: 214
-- Data for Name: district; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.district (district_id, district_name, district_code, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3331 (class 0 OID 17364)
-- Dependencies: 215
-- Data for Name: district_city_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.district_city_mapping (district_id, city_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3332 (class 0 OID 17368)
-- Dependencies: 216
-- Data for Name: division; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.division (division_id, division_name, division_code, division_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3333 (class 0 OID 17378)
-- Dependencies: 217
-- Data for Name: divison_account_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.divison_account_mapping (division_id, account_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3359 (class 0 OID 19901)
-- Dependencies: 243
-- Data for Name: email_domain_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_domain_details (email_domain_id, created_by, created_on, updated_by, updated_on, email_domain_name, email_server_config, email_service_provider, server_deployment_type, status, version_num) FROM stdin;
1	system	2019-01-14 00:00:00	abhi	2019-01-14 00:00:00	irissoftware.com	{\n  "adminUserName": "abhishek.gupta02@irissoftware.com",\n  "adminPassword": "password@1",\n  "exchangeServerURL": "https://mailiris.irissoftware.com/ews/exchange.asmx",\n  "exchangeVersion": "Exchange2010_SP2"\n}	MicrosoftExchange	OnPremise	1	\N
\.


--
-- TOC entry 3349 (class 0 OID 17524)
-- Dependencies: 233
-- Data for Name: email_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_header (email_metadata_id, email_date, subject, importance, message_id, in_reply_to, sender_ip, content_language, cc_email_id, to_email_id, reference_message_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3365 (class 0 OID 28516)
-- Dependencies: 249
-- Data for Name: email_message_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_message_data (email, unique_mail_body, email_meta_data_id, message_data_id) FROM stdin;
\.


--
-- TOC entry 3350 (class 0 OID 17533)
-- Dependencies: 234
-- Data for Name: email_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_metadata (email_metadata_id, aggregated_tone_id, calculated_tone_id, indvidual_tone_id, email_direction, from_email_id, batch_run_id, email_processing_status_id, data_classification_id, created_by, status, version_num, updated_on, updated_by, created_on, from_mail_id) FROM stdin;
\.


--
-- TOC entry 3360 (class 0 OID 19909)
-- Dependencies: 244
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.email_preferences (email_preference_id, created_by, created_on, updated_by, updated_on, email_preferences, status, version_num) FROM stdin;
1	system	2019-01-14 00:00:00	abhi	2019-01-14 00:00:00	 {\n                   "standardFolders": [\n                     "Inbox",\n                     "SentItems"\n                   ],\n                   "customFolders": [\n                   ],\n                   "emailsFromToFilter": [\n                   ],\n                   "emailsFromToRead": [\n                   ]\n }\n	1	1
2	system	2019-01-14 00:00:00	abhi	2019-01-14 00:00:00	 {\n                   "standardFolders": [\n                     "Inbox",\n                     "SentItems"\n                   ],\n                   "customFolders": [\n                   ],\n                   "emailsFromToFilter": [\n                   ],\n                   "emailsFromToRead": [\n                   ]\n }\n	1	1
3	system	2019-01-14 00:00:00	abhi	2019-01-14 00:00:00	 {\n\t\t\t\t\t   "standardFolders": [\n\t\t\t\t\t\t "Inbox",\n\t\t\t\t\t\t "SentItems"\n\t\t\t\t\t   ],\n\t\t\t\t\t   "customFolders": [\n\t\t\t\t\t   ],\n\t\t\t\t\t   "emailsFromToFilter": [\n\t\t\t\t\t   ],\n\t\t\t\t\t   "emailsFromToRead": [\n\t\t\t\t\t   ]\n\t }\n\t	1	1
\.


--
-- TOC entry 3361 (class 0 OID 19917)
-- Dependencies: 245
-- Data for Name: emailid; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emailid (email_id, created_by, created_on, updated_by, updated_on, emailid_domain_type, emailid_type_id, status, version_num, email_domain_id, email_preference_id) FROM stdin;
abhishek.gupta02@irissoftware.com	System	2019-01-14 00:00:00	System	2019-01-14 00:00:00	INTERNAL	1	1	1	1	1
\.


--
-- TOC entry 3334 (class 0 OID 17388)
-- Dependencies: 218
-- Data for Name: emailid_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emailid_type (emailid_type_id, type_name, type_description, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
1	INDIVIDUAL	Represents individual email address 	system	1	1	2019-01-14 00:00:00	system	2019-01-14 00:00:00
2	WORK UNIT DL	Represents Team	system	1	1	2019-01-14 00:00:00	system	2019-01-14 00:00:00
\.


--
-- TOC entry 3362 (class 0 OID 19925)
-- Dependencies: 246
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_id, created_by, created_on, updated_by, updated_on, first_name, last_name, middle_name, status, version_num) FROM stdin;
1691	system	2019-01-14 00:00:00	system	2019-01-14 00:00:00	abhishek	kumar	gupta	1	1
1692	system	2019-01-14 00:00:00	system	2019-01-14 00:00:00	mayank	zindal	\N	1	1
1693	system	2019-01-14 00:00:00	system	2019-01-14 00:00:00	mayank	agrawal	\N	1	1
\.


--
-- TOC entry 3363 (class 0 OID 19933)
-- Dependencies: 247
-- Data for Name: employee_emailid_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_emailid_mapping (email_id, employee_id, created_by, created_on, updated_by, updated_on, analyse_tone, status, version_num) FROM stdin;
abhishek.gupta02@irissoftware.com	1691	system	2019-01-14 00:00:00	system	2019-01-14 00:00:00	Y	1	1
\.


--
-- TOC entry 3335 (class 0 OID 17404)
-- Dependencies: 219
-- Data for Name: employee_hirerachy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_hirerachy (hierarchy_id, employee_id, reports_to_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3336 (class 0 OID 17410)
-- Dependencies: 220
-- Data for Name: employee_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_role_mapping (employee_id, role_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3337 (class 0 OID 17416)
-- Dependencies: 221
-- Data for Name: employee_work_unit_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_work_unit_mapping (employee_id, work_unit_type_id, work_unit_id, is_owner, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3338 (class 0 OID 17422)
-- Dependencies: 222
-- Data for Name: entity_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entity_type (type_id, type_name, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3364 (class 0 OID 19941)
-- Dependencies: 248
-- Data for Name: execution_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.execution_status (status_id, created_by, created_on, updated_by, updated_on, status_desc, status_name) FROM stdin;
1	\N	\N	\N	\N	process is currently running	In_progress
\.


--
-- TOC entry 3339 (class 0 OID 17428)
-- Dependencies: 223
-- Data for Name: geo_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_location (location_id, continent_id, country_id, district_id, city_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3340 (class 0 OID 17434)
-- Dependencies: 224
-- Data for Name: group_team_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_team_mapping (team_id, group_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3351 (class 0 OID 17545)
-- Dependencies: 235
-- Data for Name: individual_tone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.individual_tone (individual_tone_id, individual_tone, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3341 (class 0 OID 17438)
-- Dependencies: 225
-- Data for Name: legal_entity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_entity (legal_entity_id, address_id, type_id, entity_name, entity_code, descritption, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3372 (class 0 OID 30066)
-- Dependencies: 256
-- Data for Name: qrtz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_blob_triggers (sched_name, trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- TOC entry 3373 (class 0 OID 30079)
-- Dependencies: 257
-- Data for Name: qrtz_calendars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_calendars (sched_name, calendar_name, calendar) FROM stdin;
\.


--
-- TOC entry 3370 (class 0 OID 30040)
-- Dependencies: 254
-- Data for Name: qrtz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_cron_triggers (sched_name, trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
quartz-app	Sample Cron Job	DEFAULT	0 0/2 * ? * *	Asia/Calcutta
\.


--
-- TOC entry 3353 (class 0 OID 17933)
-- Dependencies: 237
-- Data for Name: qrtz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_fired_triggers (sched_name, entry_id, trigger_name, trigger_group, instance_name, fired_time, sched_time, priority, state, job_name, job_group, is_nonconcurrent, requests_recovery) FROM stdin;
quartz-app	5c165279-b881-4e06-b2a7-7e07aa27bd441547816491255	Sample Cron Job	DEFAULT	5c165279-b881-4e06-b2a7-7e07aa27bd44	1547816520009	1547816520000	0	EXECUTING	Sample Cron Job	Test Group	t	f
\.


--
-- TOC entry 3367 (class 0 OID 30006)
-- Dependencies: 251
-- Data for Name: qrtz_job_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_job_details (sched_name, job_name, job_group, description, job_class_name, is_durable, is_nonconcurrent, is_update_data, requests_recovery, job_data) FROM stdin;
quartz-app	Sample Cron Job	Test Group	\N	com.hanogi.batch.jobs.CronJob	f	t	f	f	\\x230d0a23467269204a616e2031382031383a33313a33312049535420323031390d0a53616d706c655c2043726f6e5c204a6f62546573745c2047726f75703d636f6d2e68616e6f67692e62617463682e6a6f62732e43726f6e4a6f620d0a
\.


--
-- TOC entry 3376 (class 0 OID 30097)
-- Dependencies: 260
-- Data for Name: qrtz_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_locks (sched_name, lock_name) FROM stdin;
quartz-app	TRIGGER_ACCESS
quartz-app	STATE_ACCESS
\.


--
-- TOC entry 3374 (class 0 OID 30087)
-- Dependencies: 258
-- Data for Name: qrtz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_paused_trigger_grps (sched_name, trigger_group) FROM stdin;
\.


--
-- TOC entry 3375 (class 0 OID 30092)
-- Dependencies: 259
-- Data for Name: qrtz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_scheduler_state (sched_name, instance_name, last_checkin_time, checkin_interval) FROM stdin;
quartz-app	5c165279-b881-4e06-b2a7-7e07aa27bd44	1547816950906	7500
\.


--
-- TOC entry 3369 (class 0 OID 30027)
-- Dependencies: 253
-- Data for Name: qrtz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_simple_triggers (sched_name, trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
\.


--
-- TOC entry 3371 (class 0 OID 30053)
-- Dependencies: 255
-- Data for Name: qrtz_simprop_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_simprop_triggers (sched_name, trigger_name, trigger_group, str_prop_1, str_prop_2, str_prop_3, int_prop_1, int_prop_2, long_prop_1, long_prop_2, dec_prop_1, dec_prop_2, bool_prop_1, bool_prop_2) FROM stdin;
\.


--
-- TOC entry 3368 (class 0 OID 30014)
-- Dependencies: 252
-- Data for Name: qrtz_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qrtz_triggers (sched_name, trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
quartz-app	Sample Cron Job	DEFAULT	Sample Cron Job	Test Group	\N	1547816640000	1547816520000	0	BLOCKED	CRON	1547816491000	0	\N	1	\\x
\.


--
-- TOC entry 3342 (class 0 OID 17444)
-- Dependencies: 226
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role (role_id, role_name, role_code, role_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3355 (class 0 OID 19868)
-- Dependencies: 239
-- Data for Name: scheduler_job_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduler_job_info (id, batch_id, cron_expression, cron_job, is_active, job_group, job_name, repeat_time) FROM stdin;
1	10	0 0/2 * ? * *	t	t	Test Group	Sample Cron Job	\N
\.


--
-- TOC entry 3343 (class 0 OID 17454)
-- Dependencies: 227
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team (team_id, team_name, team_code, team_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3352 (class 0 OID 17554)
-- Dependencies: 236
-- Data for Name: tone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tone (tone_id, tone_name, tone_desc, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3345 (class 0 OID 17470)
-- Dependencies: 229
-- Data for Name: work_unit_emailid_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.work_unit_emailid_mapping (email_id, work_unit_type_id, work_unit_id, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3344 (class 0 OID 17464)
-- Dependencies: 228
-- Data for Name: work_units_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.work_units_types (work_unit_type_id, work_unit_type_name, created_by, status, version_num, updated_on, updated_by, created_on) FROM stdin;
\.


--
-- TOC entry 3811 (class 0 OID 0)
-- Dependencies: 250
-- Name: email_message_data_message_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_message_data_message_data_id_seq', 2, true);


--
-- TOC entry 3812 (class 0 OID 0)
-- Dependencies: 238
-- Name: scheduler_job_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scheduler_job_info_id_seq', 2, true);


--
-- TOC entry 2987 (class 2606 OID 17257)
-- Name: account account_account_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_account_code_key UNIQUE (account_code);


--
-- TOC entry 2989 (class 2606 OID 17255)
-- Name: account account_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_account_name_key UNIQUE (account_name);


--
-- TOC entry 2991 (class 2606 OID 17253)
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_id);


--
-- TOC entry 2993 (class 2606 OID 17267)
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (address_id);


--
-- TOC entry 3061 (class 2606 OID 17482)
-- Name: aggregated_tone aggregated_tone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aggregated_tone
    ADD CONSTRAINT aggregated_tone_pkey PRIMARY KEY (aggregated_tone_id);


--
-- TOC entry 3087 (class 2606 OID 19884)
-- Name: batch_details batch_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batch_details
    ADD CONSTRAINT batch_details_pkey PRIMARY KEY (batch_id);


--
-- TOC entry 3089 (class 2606 OID 19892)
-- Name: batch_run_details batch_run_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batch_run_details
    ADD CONSTRAINT batch_run_details_pkey PRIMARY KEY (batch_run_id);


--
-- TOC entry 3091 (class 2606 OID 19900)
-- Name: batch_run_type batch_run_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batch_run_type
    ADD CONSTRAINT batch_run_type_pkey PRIMARY KEY (batch_run_type_id);


--
-- TOC entry 2995 (class 2606 OID 17273)
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (branch_id);


--
-- TOC entry 2997 (class 2606 OID 17283)
-- Name: business_group business_group_group_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_group
    ADD CONSTRAINT business_group_group_code_key UNIQUE (group_code);


--
-- TOC entry 2999 (class 2606 OID 17281)
-- Name: business_group business_group_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_group
    ADD CONSTRAINT business_group_group_name_key UNIQUE (group_name);


--
-- TOC entry 3001 (class 2606 OID 17279)
-- Name: business_group business_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_group
    ADD CONSTRAINT business_group_pkey PRIMARY KEY (group_id);


--
-- TOC entry 3003 (class 2606 OID 17293)
-- Name: business_unit business_unit_business_unit_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_unit
    ADD CONSTRAINT business_unit_business_unit_code_key UNIQUE (business_unit_code);


--
-- TOC entry 3005 (class 2606 OID 17291)
-- Name: business_unit business_unit_business_unit_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_unit
    ADD CONSTRAINT business_unit_business_unit_name_key UNIQUE (business_unit_name);


--
-- TOC entry 3007 (class 2606 OID 17289)
-- Name: business_unit business_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_unit
    ADD CONSTRAINT business_unit_pkey PRIMARY KEY (business_unit_id);


--
-- TOC entry 3063 (class 2606 OID 17508)
-- Name: calculated_tone calculated_tone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calculated_tone
    ADD CONSTRAINT calculated_tone_pkey PRIMARY KEY (calculated_tone_id);


--
-- TOC entry 3009 (class 2606 OID 17303)
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (city_id);


--
-- TOC entry 3013 (class 2606 OID 17319)
-- Name: client_employee_mapping client_employee_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_employee_mapping
    ADD CONSTRAINT client_employee_mapping_pkey PRIMARY KEY (client_id, employee_id);


--
-- TOC entry 3015 (class 2606 OID 17325)
-- Name: client_hirerachy client_hirerachy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_hirerachy
    ADD CONSTRAINT client_hirerachy_pkey PRIMARY KEY (hierarchy_id);


--
-- TOC entry 3011 (class 2606 OID 17309)
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- TOC entry 3017 (class 2606 OID 17331)
-- Name: client_role_mapping client_role_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_role_mapping
    ADD CONSTRAINT client_role_mapping_pkey PRIMARY KEY (client_id, role_id);


--
-- TOC entry 3019 (class 2606 OID 17337)
-- Name: client_work_unit_mapping client_work_unit_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_work_unit_mapping
    ADD CONSTRAINT client_work_unit_mapping_pkey PRIMARY KEY (client_id);


--
-- TOC entry 3021 (class 2606 OID 17343)
-- Name: continent continent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.continent
    ADD CONSTRAINT continent_pkey PRIMARY KEY (continent_id);


--
-- TOC entry 3023 (class 2606 OID 17353)
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (country_id);


--
-- TOC entry 3065 (class 2606 OID 17514)
-- Name: data_classification data_classification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_classification
    ADD CONSTRAINT data_classification_pkey PRIMARY KEY (classification_category_id);


--
-- TOC entry 3025 (class 2606 OID 17363)
-- Name: district district_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.district
    ADD CONSTRAINT district_pkey PRIMARY KEY (district_id);


--
-- TOC entry 3027 (class 2606 OID 17377)
-- Name: division division_division_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.division
    ADD CONSTRAINT division_division_code_key UNIQUE (division_code);


--
-- TOC entry 3029 (class 2606 OID 17375)
-- Name: division division_division_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.division
    ADD CONSTRAINT division_division_name_key UNIQUE (division_name);


--
-- TOC entry 3031 (class 2606 OID 17373)
-- Name: division division_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.division
    ADD CONSTRAINT division_pkey PRIMARY KEY (division_id);


--
-- TOC entry 3093 (class 2606 OID 19908)
-- Name: email_domain_details email_domain_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_domain_details
    ADD CONSTRAINT email_domain_details_pkey PRIMARY KEY (email_domain_id);


--
-- TOC entry 3067 (class 2606 OID 17532)
-- Name: email_header email_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_header
    ADD CONSTRAINT email_header_pkey PRIMARY KEY (email_metadata_id);


--
-- TOC entry 3105 (class 2606 OID 29776)
-- Name: email_message_data email_message_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_message_data
    ADD CONSTRAINT email_message_data_pkey PRIMARY KEY (message_data_id);


--
-- TOC entry 3069 (class 2606 OID 17538)
-- Name: email_metadata email_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_metadata
    ADD CONSTRAINT email_metadata_pkey PRIMARY KEY (email_metadata_id);


--
-- TOC entry 3095 (class 2606 OID 19916)
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (email_preference_id);


--
-- TOC entry 3097 (class 2606 OID 19924)
-- Name: emailid emailid_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emailid
    ADD CONSTRAINT emailid_pkey PRIMARY KEY (email_id);


--
-- TOC entry 3033 (class 2606 OID 17393)
-- Name: emailid_type emailid_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emailid_type
    ADD CONSTRAINT emailid_type_pkey PRIMARY KEY (emailid_type_id);


--
-- TOC entry 3101 (class 2606 OID 19940)
-- Name: employee_emailid_mapping employee_emailid_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_emailid_mapping
    ADD CONSTRAINT employee_emailid_mapping_pkey PRIMARY KEY (email_id, employee_id);


--
-- TOC entry 3035 (class 2606 OID 17409)
-- Name: employee_hirerachy employee_hirerachy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_hirerachy
    ADD CONSTRAINT employee_hirerachy_pkey PRIMARY KEY (hierarchy_id);


--
-- TOC entry 3099 (class 2606 OID 19932)
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 3037 (class 2606 OID 17415)
-- Name: employee_role_mapping employee_role_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_role_mapping
    ADD CONSTRAINT employee_role_mapping_pkey PRIMARY KEY (employee_id, role_id);


--
-- TOC entry 3039 (class 2606 OID 17421)
-- Name: employee_work_unit_mapping employee_work_unit_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_work_unit_mapping
    ADD CONSTRAINT employee_work_unit_mapping_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 3041 (class 2606 OID 17427)
-- Name: entity_type entity_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entity_type
    ADD CONSTRAINT entity_type_pkey PRIMARY KEY (type_id);


--
-- TOC entry 3103 (class 2606 OID 19948)
-- Name: execution_status execution_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.execution_status
    ADD CONSTRAINT execution_status_pkey PRIMARY KEY (status_id);


--
-- TOC entry 3043 (class 2606 OID 17433)
-- Name: geo_location geo_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_location
    ADD CONSTRAINT geo_location_pkey PRIMARY KEY (location_id);


--
-- TOC entry 3071 (class 2606 OID 17553)
-- Name: individual_tone individual_tone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.individual_tone
    ADD CONSTRAINT individual_tone_pkey PRIMARY KEY (individual_tone_id);


--
-- TOC entry 3045 (class 2606 OID 17443)
-- Name: legal_entity legal_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_entity
    ADD CONSTRAINT legal_entity_pkey PRIMARY KEY (legal_entity_id);


--
-- TOC entry 3131 (class 2606 OID 30073)
-- Name: qrtz_blob_triggers qrtz_blob_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_blob_triggers
    ADD CONSTRAINT qrtz_blob_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 3133 (class 2606 OID 30086)
-- Name: qrtz_calendars qrtz_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_calendars
    ADD CONSTRAINT qrtz_calendars_pkey PRIMARY KEY (sched_name, calendar_name);


--
-- TOC entry 3127 (class 2606 OID 30047)
-- Name: qrtz_cron_triggers qrtz_cron_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_cron_triggers
    ADD CONSTRAINT qrtz_cron_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 3083 (class 2606 OID 17940)
-- Name: qrtz_fired_triggers qrtz_fired_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_fired_triggers
    ADD CONSTRAINT qrtz_fired_triggers_pkey PRIMARY KEY (sched_name, entry_id);


--
-- TOC entry 3109 (class 2606 OID 30013)
-- Name: qrtz_job_details qrtz_job_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_job_details
    ADD CONSTRAINT qrtz_job_details_pkey PRIMARY KEY (sched_name, job_name, job_group);


--
-- TOC entry 3139 (class 2606 OID 30101)
-- Name: qrtz_locks qrtz_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_locks
    ADD CONSTRAINT qrtz_locks_pkey PRIMARY KEY (sched_name, lock_name);


--
-- TOC entry 3135 (class 2606 OID 30091)
-- Name: qrtz_paused_trigger_grps qrtz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_paused_trigger_grps
    ADD CONSTRAINT qrtz_paused_trigger_grps_pkey PRIMARY KEY (sched_name, trigger_group);


--
-- TOC entry 3137 (class 2606 OID 30096)
-- Name: qrtz_scheduler_state qrtz_scheduler_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_scheduler_state
    ADD CONSTRAINT qrtz_scheduler_state_pkey PRIMARY KEY (sched_name, instance_name);


--
-- TOC entry 3125 (class 2606 OID 30034)
-- Name: qrtz_simple_triggers qrtz_simple_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_simple_triggers
    ADD CONSTRAINT qrtz_simple_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 3129 (class 2606 OID 30060)
-- Name: qrtz_simprop_triggers qrtz_simprop_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_simprop_triggers
    ADD CONSTRAINT qrtz_simprop_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 3123 (class 2606 OID 30021)
-- Name: qrtz_triggers qrtz_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_triggers
    ADD CONSTRAINT qrtz_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 3047 (class 2606 OID 17449)
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (role_id);


--
-- TOC entry 3049 (class 2606 OID 17453)
-- Name: role role_role_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_role_code_key UNIQUE (role_code);


--
-- TOC entry 3051 (class 2606 OID 17451)
-- Name: role role_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_role_name_key UNIQUE (role_name);


--
-- TOC entry 3085 (class 2606 OID 19876)
-- Name: scheduler_job_info scheduler_job_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduler_job_info
    ADD CONSTRAINT scheduler_job_info_pkey PRIMARY KEY (id);


--
-- TOC entry 3053 (class 2606 OID 17459)
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (team_id);


--
-- TOC entry 3055 (class 2606 OID 17463)
-- Name: team team_team_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_team_code_key UNIQUE (team_code);


--
-- TOC entry 3057 (class 2606 OID 17461)
-- Name: team team_team_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_team_name_key UNIQUE (team_name);


--
-- TOC entry 3073 (class 2606 OID 17559)
-- Name: tone tone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tone
    ADD CONSTRAINT tone_pkey PRIMARY KEY (tone_id);


--
-- TOC entry 3075 (class 2606 OID 17561)
-- Name: tone tone_tone_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tone
    ADD CONSTRAINT tone_tone_name_key UNIQUE (tone_name);


--
-- TOC entry 3059 (class 2606 OID 17469)
-- Name: work_units_types work_units_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_units_types
    ADD CONSTRAINT work_units_types_pkey PRIMARY KEY (work_unit_type_id);


--
-- TOC entry 3076 (class 1259 OID 17966)
-- Name: idx_qrtz_ft_inst_job_req_rcvry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_inst_job_req_rcvry ON public.qrtz_fired_triggers USING btree (sched_name, instance_name, requests_recovery);


--
-- TOC entry 3077 (class 1259 OID 17967)
-- Name: idx_qrtz_ft_j_g; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_j_g ON public.qrtz_fired_triggers USING btree (sched_name, job_name, job_group);


--
-- TOC entry 3078 (class 1259 OID 17968)
-- Name: idx_qrtz_ft_jg; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_jg ON public.qrtz_fired_triggers USING btree (sched_name, job_group);


--
-- TOC entry 3079 (class 1259 OID 17969)
-- Name: idx_qrtz_ft_t_g; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_t_g ON public.qrtz_fired_triggers USING btree (sched_name, trigger_name, trigger_group);


--
-- TOC entry 3080 (class 1259 OID 17970)
-- Name: idx_qrtz_ft_tg; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_tg ON public.qrtz_fired_triggers USING btree (sched_name, trigger_group);


--
-- TOC entry 3081 (class 1259 OID 17965)
-- Name: idx_qrtz_ft_trig_inst_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_trig_inst_name ON public.qrtz_fired_triggers USING btree (sched_name, instance_name);


--
-- TOC entry 3106 (class 1259 OID 30103)
-- Name: idx_qrtz_j_grp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_j_grp ON public.qrtz_job_details USING btree (sched_name, job_group);


--
-- TOC entry 3107 (class 1259 OID 30102)
-- Name: idx_qrtz_j_req_recovery; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_j_req_recovery ON public.qrtz_job_details USING btree (sched_name, requests_recovery);


--
-- TOC entry 3110 (class 1259 OID 30106)
-- Name: idx_qrtz_t_c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_c ON public.qrtz_triggers USING btree (sched_name, calendar_name);


--
-- TOC entry 3111 (class 1259 OID 30107)
-- Name: idx_qrtz_t_g; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_g ON public.qrtz_triggers USING btree (sched_name, trigger_group);


--
-- TOC entry 3112 (class 1259 OID 30104)
-- Name: idx_qrtz_t_j; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_j ON public.qrtz_triggers USING btree (sched_name, job_name, job_group);


--
-- TOC entry 3113 (class 1259 OID 30105)
-- Name: idx_qrtz_t_jg; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_jg ON public.qrtz_triggers USING btree (sched_name, job_group);


--
-- TOC entry 3114 (class 1259 OID 30110)
-- Name: idx_qrtz_t_n_g_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_n_g_state ON public.qrtz_triggers USING btree (sched_name, trigger_group, trigger_state);


--
-- TOC entry 3115 (class 1259 OID 30109)
-- Name: idx_qrtz_t_n_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_n_state ON public.qrtz_triggers USING btree (sched_name, trigger_name, trigger_group, trigger_state);


--
-- TOC entry 3116 (class 1259 OID 30111)
-- Name: idx_qrtz_t_next_fire_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_next_fire_time ON public.qrtz_triggers USING btree (sched_name, next_fire_time);


--
-- TOC entry 3117 (class 1259 OID 30113)
-- Name: idx_qrtz_t_nft_misfire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_misfire ON public.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time);


--
-- TOC entry 3118 (class 1259 OID 30112)
-- Name: idx_qrtz_t_nft_st; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_st ON public.qrtz_triggers USING btree (sched_name, trigger_state, next_fire_time);


--
-- TOC entry 3119 (class 1259 OID 30114)
-- Name: idx_qrtz_t_nft_st_misfire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_st_misfire ON public.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_state);


--
-- TOC entry 3120 (class 1259 OID 30115)
-- Name: idx_qrtz_t_nft_st_misfire_grp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_st_misfire_grp ON public.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_group, trigger_state);


--
-- TOC entry 3121 (class 1259 OID 30108)
-- Name: idx_qrtz_t_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_qrtz_t_state ON public.qrtz_triggers USING btree (sched_name, trigger_state);


--
-- TOC entry 3140 (class 2606 OID 17562)
-- Name: account_group_mapping account_group_mapping_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_group_mapping
    ADD CONSTRAINT account_group_mapping_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.account(account_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3141 (class 2606 OID 17582)
-- Name: account_group_mapping account_group_mapping_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_group_mapping
    ADD CONSTRAINT account_group_mapping_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.business_group(group_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3142 (class 2606 OID 17702)
-- Name: address address_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.geo_location(location_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3143 (class 2606 OID 17572)
-- Name: branch branch_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.address(address_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3144 (class 2606 OID 17707)
-- Name: branch branch_legal_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_legal_entity_id_fkey FOREIGN KEY (legal_entity_id) REFERENCES public.legal_entity(legal_entity_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3145 (class 2606 OID 17592)
-- Name: bu_divison_mapping bu_divison_mapping_business_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bu_divison_mapping
    ADD CONSTRAINT bu_divison_mapping_business_unit_id_fkey FOREIGN KEY (business_unit_id) REFERENCES public.business_unit(business_unit_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3146 (class 2606 OID 17647)
-- Name: bu_divison_mapping bu_divison_mapping_division_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bu_divison_mapping
    ADD CONSTRAINT bu_divison_mapping_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.division(division_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3148 (class 2606 OID 17737)
-- Name: client_emailid_mapping client_emailid_mapping_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_emailid_mapping
    ADD CONSTRAINT client_emailid_mapping_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3149 (class 2606 OID 17742)
-- Name: client_employee_mapping client_employee_mapping_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_employee_mapping
    ADD CONSTRAINT client_employee_mapping_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3150 (class 2606 OID 17747)
-- Name: client_hirerachy client_hirerachy_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_hirerachy
    ADD CONSTRAINT client_hirerachy_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3151 (class 2606 OID 17752)
-- Name: client_hirerachy client_hirerachy_reports_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_hirerachy
    ADD CONSTRAINT client_hirerachy_reports_to_id_fkey FOREIGN KEY (reports_to_id) REFERENCES public.client(client_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3147 (class 2606 OID 17767)
-- Name: client client_legal_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_legal_entity_id_fkey FOREIGN KEY (legal_entity_id) REFERENCES public.legal_entity(legal_entity_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3152 (class 2606 OID 17757)
-- Name: client_role_mapping client_role_mapping_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_role_mapping
    ADD CONSTRAINT client_role_mapping_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3153 (class 2606 OID 17772)
-- Name: client_role_mapping client_role_mapping_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_role_mapping
    ADD CONSTRAINT client_role_mapping_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(role_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3154 (class 2606 OID 17762)
-- Name: client_work_unit_mapping client_work_unit_mapping_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_work_unit_mapping
    ADD CONSTRAINT client_work_unit_mapping_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3155 (class 2606 OID 17777)
-- Name: client_work_unit_mapping client_work_unit_mapping_work_unit_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_work_unit_mapping
    ADD CONSTRAINT client_work_unit_mapping_work_unit_type_id_fkey FOREIGN KEY (work_unit_type_id) REFERENCES public.work_units_types(work_unit_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3156 (class 2606 OID 17607)
-- Name: continent_country_mapping continent_country_mapping_continent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.continent_country_mapping
    ADD CONSTRAINT continent_country_mapping_continent_id_fkey FOREIGN KEY (continent_id) REFERENCES public.continent(continent_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3157 (class 2606 OID 17617)
-- Name: continent_country_mapping continent_country_mapping_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.continent_country_mapping
    ADD CONSTRAINT continent_country_mapping_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(country_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3158 (class 2606 OID 17622)
-- Name: country_district_mapping country_district_mapping_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country_district_mapping
    ADD CONSTRAINT country_district_mapping_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(country_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3159 (class 2606 OID 17632)
-- Name: country_district_mapping country_district_mapping_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country_district_mapping
    ADD CONSTRAINT country_district_mapping_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.district(district_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3160 (class 2606 OID 17597)
-- Name: district_city_mapping district_city_mapping_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.district_city_mapping
    ADD CONSTRAINT district_city_mapping_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.city(city_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3161 (class 2606 OID 17637)
-- Name: district_city_mapping district_city_mapping_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.district_city_mapping
    ADD CONSTRAINT district_city_mapping_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.district(district_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3162 (class 2606 OID 17567)
-- Name: divison_account_mapping divison_account_mapping_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divison_account_mapping
    ADD CONSTRAINT divison_account_mapping_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.account(account_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3163 (class 2606 OID 17652)
-- Name: divison_account_mapping divison_account_mapping_division_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divison_account_mapping
    ADD CONSTRAINT divison_account_mapping_division_id_fkey FOREIGN KEY (division_id) REFERENCES public.division(division_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3175 (class 2606 OID 17807)
-- Name: email_header email_header_email_metadata_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_header
    ADD CONSTRAINT email_header_email_metadata_id_fkey FOREIGN KEY (email_metadata_id) REFERENCES public.email_metadata(email_metadata_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3177 (class 2606 OID 17782)
-- Name: email_metadata email_metadata_aggregated_tone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_metadata
    ADD CONSTRAINT email_metadata_aggregated_tone_id_fkey FOREIGN KEY (aggregated_tone_id) REFERENCES public.aggregated_tone(aggregated_tone_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3178 (class 2606 OID 17797)
-- Name: email_metadata email_metadata_calculated_tone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_metadata
    ADD CONSTRAINT email_metadata_calculated_tone_id_fkey FOREIGN KEY (calculated_tone_id) REFERENCES public.calculated_tone(calculated_tone_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3179 (class 2606 OID 17802)
-- Name: email_metadata email_metadata_data_classification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_metadata
    ADD CONSTRAINT email_metadata_data_classification_id_fkey FOREIGN KEY (data_classification_id) REFERENCES public.data_classification(classification_category_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3180 (class 2606 OID 17822)
-- Name: email_metadata email_metadata_indvidual_tone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_metadata
    ADD CONSTRAINT email_metadata_indvidual_tone_id_fkey FOREIGN KEY (indvidual_tone_id) REFERENCES public.individual_tone(individual_tone_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3164 (class 2606 OID 17717)
-- Name: employee_role_mapping employee_role_mapping_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_role_mapping
    ADD CONSTRAINT employee_role_mapping_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(role_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3165 (class 2606 OID 17727)
-- Name: employee_work_unit_mapping employee_work_unit_mapping_work_unit_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_work_unit_mapping
    ADD CONSTRAINT employee_work_unit_mapping_work_unit_type_id_fkey FOREIGN KEY (work_unit_type_id) REFERENCES public.work_units_types(work_unit_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3183 (class 2606 OID 28534)
-- Name: emailid fk6evl2r20o1lrlmwxdievg6ryh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emailid
    ADD CONSTRAINT fk6evl2r20o1lrlmwxdievg6ryh FOREIGN KEY (email_preference_id) REFERENCES public.email_preferences(email_preference_id);


--
-- TOC entry 3184 (class 2606 OID 19959)
-- Name: emailid fk87lnf6vgpnrb07dk0sreevtxi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.emailid
    ADD CONSTRAINT fk87lnf6vgpnrb07dk0sreevtxi FOREIGN KEY (email_domain_id) REFERENCES public.email_domain_details(email_domain_id);


--
-- TOC entry 3182 (class 2606 OID 19954)
-- Name: batch_run_details fkb21v84d278wbodr8558t4eqn; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batch_run_details
    ADD CONSTRAINT fkb21v84d278wbodr8558t4eqn FOREIGN KEY (batch_run_type_id) REFERENCES public.batch_run_type(batch_run_type_id);


--
-- TOC entry 3181 (class 2606 OID 19949)
-- Name: batch_run_details fkdda9niv7gjmhnt70lb197e1q8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.batch_run_details
    ADD CONSTRAINT fkdda9niv7gjmhnt70lb197e1q8 FOREIGN KEY (batch_status_id) REFERENCES public.execution_status(status_id);


--
-- TOC entry 3185 (class 2606 OID 28524)
-- Name: email_message_data fkiao2gyvsp4tu2c4dxfq7j4dls; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_message_data
    ADD CONSTRAINT fkiao2gyvsp4tu2c4dxfq7j4dls FOREIGN KEY (email_meta_data_id) REFERENCES public.email_metadata(email_metadata_id);


--
-- TOC entry 3176 (class 2606 OID 28529)
-- Name: email_metadata fkqcp4xplufs0tkqp8hx3fwdb93; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email_metadata
    ADD CONSTRAINT fkqcp4xplufs0tkqp8hx3fwdb93 FOREIGN KEY (batch_run_id) REFERENCES public.batch_run_details(batch_run_id);


--
-- TOC entry 3166 (class 2606 OID 17602)
-- Name: geo_location geo_location_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_location
    ADD CONSTRAINT geo_location_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.city(city_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3167 (class 2606 OID 17612)
-- Name: geo_location geo_location_continent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_location
    ADD CONSTRAINT geo_location_continent_id_fkey FOREIGN KEY (continent_id) REFERENCES public.continent(continent_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3168 (class 2606 OID 17627)
-- Name: geo_location geo_location_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_location
    ADD CONSTRAINT geo_location_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(country_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3169 (class 2606 OID 17642)
-- Name: geo_location geo_location_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_location
    ADD CONSTRAINT geo_location_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.district(district_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3170 (class 2606 OID 17587)
-- Name: group_team_mapping group_team_mapping_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_team_mapping
    ADD CONSTRAINT group_team_mapping_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.business_group(group_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3171 (class 2606 OID 17722)
-- Name: group_team_mapping group_team_mapping_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_team_mapping
    ADD CONSTRAINT group_team_mapping_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(team_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3172 (class 2606 OID 17577)
-- Name: legal_entity legal_entity_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_entity
    ADD CONSTRAINT legal_entity_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.address(address_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3173 (class 2606 OID 17697)
-- Name: legal_entity legal_entity_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_entity
    ADD CONSTRAINT legal_entity_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.entity_type(type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3190 (class 2606 OID 30074)
-- Name: qrtz_blob_triggers qrtz_blob_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_blob_triggers
    ADD CONSTRAINT qrtz_blob_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- TOC entry 3188 (class 2606 OID 30048)
-- Name: qrtz_cron_triggers qrtz_cron_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_cron_triggers
    ADD CONSTRAINT qrtz_cron_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- TOC entry 3187 (class 2606 OID 30035)
-- Name: qrtz_simple_triggers qrtz_simple_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_simple_triggers
    ADD CONSTRAINT qrtz_simple_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- TOC entry 3189 (class 2606 OID 30061)
-- Name: qrtz_simprop_triggers qrtz_simprop_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_simprop_triggers
    ADD CONSTRAINT qrtz_simprop_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- TOC entry 3186 (class 2606 OID 30022)
-- Name: qrtz_triggers qrtz_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qrtz_triggers
    ADD CONSTRAINT qrtz_triggers_sched_name_fkey FOREIGN KEY (sched_name, job_name, job_group) REFERENCES public.qrtz_job_details(sched_name, job_name, job_group);


--
-- TOC entry 3174 (class 2606 OID 17732)
-- Name: work_unit_emailid_mapping work_unit_emailid_mapping_work_unit_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_unit_emailid_mapping
    ADD CONSTRAINT work_unit_emailid_mapping_work_unit_type_id_fkey FOREIGN KEY (work_unit_type_id) REFERENCES public.work_units_types(work_unit_type_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


-- Completed on 2019-01-18 18:39:12

--
-- PostgreSQL database dump complete
--

