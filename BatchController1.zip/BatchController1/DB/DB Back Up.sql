--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 10.6

-- Started on 2019-02-12 18:36:45

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3358 (class 0 OID 17248)
-- Dependencies: 196
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3359 (class 0 OID 17258)
-- Dependencies: 197
-- Data for Name: account_group_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3360 (class 0 OID 17262)
-- Dependencies: 198
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3392 (class 0 OID 17474)
-- Dependencies: 230
-- Data for Name: aggregated_tone; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3401 (class 0 OID 19885)
-- Dependencies: 239
-- Data for Name: batch_run_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.batch_run_details (batch_run_id, created_by, created_on, updated_by, updated_on, batch_job_id, batch_run_date, batch_status_details, from_date, status, to_date, version_num, batch_status_id, batch_run_type_id) VALUES (10, NULL, NULL, NULL, NULL, '1', '2019-01-10', 'In_Progress', '2018-12-26 00:00:00', '1', '2019-01-09 00:00:00', NULL, 1, 1);


--
-- TOC entry 3402 (class 0 OID 19893)
-- Dependencies: 240
-- Data for Name: batch_run_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.batch_run_type (batch_run_type_id, created_by, created_on, updated_by, updated_on, batch_run_type_desc, batch_run_type_name) VALUES (1, NULL, NULL, NULL, NULL, '', '');


--
-- TOC entry 3361 (class 0 OID 17268)
-- Dependencies: 199
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3364 (class 0 OID 17294)
-- Dependencies: 202
-- Data for Name: bu_divison_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3362 (class 0 OID 17274)
-- Dependencies: 200
-- Data for Name: business_group; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3363 (class 0 OID 17284)
-- Dependencies: 201
-- Data for Name: business_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3393 (class 0 OID 17500)
-- Dependencies: 231
-- Data for Name: calculated_tone; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.calculated_tone (calculated_tone_id, calculated_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (100, '', 'Abhi', '1', 0, '2019-01-24 15:50:17.799', 'Abhi', '2019-01-24 15:50:17.799');
INSERT INTO public.calculated_tone (calculated_tone_id, calculated_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (101, '', 'Abhi', '1', 0, '2019-01-24 15:52:20.441', 'Abhi', '2019-01-24 15:52:20.441');
INSERT INTO public.calculated_tone (calculated_tone_id, calculated_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (102, '', 'Abhi', '1', 0, '2019-01-24 15:52:29.64', 'Abhi', '2019-01-24 15:52:29.64');
INSERT INTO public.calculated_tone (calculated_tone_id, calculated_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (103, '', 'Abhi', '1', 0, '2019-01-24 15:53:44.377', 'Abhi', '2019-01-24 15:53:44.377');


--
-- TOC entry 3365 (class 0 OID 17298)
-- Dependencies: 203
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3366 (class 0 OID 17304)
-- Dependencies: 204
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3367 (class 0 OID 17310)
-- Dependencies: 205
-- Data for Name: client_emailid_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3368 (class 0 OID 17314)
-- Dependencies: 206
-- Data for Name: client_employee_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3369 (class 0 OID 17320)
-- Dependencies: 207
-- Data for Name: client_hirerachy; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3370 (class 0 OID 17326)
-- Dependencies: 208
-- Data for Name: client_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3371 (class 0 OID 17332)
-- Dependencies: 209
-- Data for Name: client_work_unit_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3372 (class 0 OID 17338)
-- Dependencies: 210
-- Data for Name: continent; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3373 (class 0 OID 17344)
-- Dependencies: 211
-- Data for Name: continent_country_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3374 (class 0 OID 17348)
-- Dependencies: 212
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3375 (class 0 OID 17354)
-- Dependencies: 213
-- Data for Name: country_district_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3394 (class 0 OID 17509)
-- Dependencies: 232
-- Data for Name: data_classification; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3376 (class 0 OID 17358)
-- Dependencies: 214
-- Data for Name: district; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3377 (class 0 OID 17364)
-- Dependencies: 215
-- Data for Name: district_city_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3378 (class 0 OID 17368)
-- Dependencies: 216
-- Data for Name: division; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3379 (class 0 OID 17378)
-- Dependencies: 217
-- Data for Name: divison_account_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3403 (class 0 OID 19901)
-- Dependencies: 241
-- Data for Name: email_domain_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.email_domain_details (email_domain_id, created_by, created_on, updated_by, updated_on, email_domain_name, email_server_config, email_service_provider, server_deployment_type, status, version_num) VALUES (1, 'system', '2019-01-14 00:00:00', 'abhi', '2019-01-14 00:00:00', 'irissoftware.com', '{
  "adminUserName": "abhishek.gupta02@irissoftware.com",
  "adminPassword": "password@1",
  "exchangeServerURL": "https://mailiris.irissoftware.com/ews/exchange.asmx",
  "exchangeVersion": "Exchange2010_SP2"
}', 'MicrosoftExchange', 'OnPremise', '1', NULL);


--
-- TOC entry 3418 (class 0 OID 37611)
-- Dependencies: 256
-- Data for Name: email_header; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3409 (class 0 OID 28516)
-- Dependencies: 247
-- Data for Name: email_message_data; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3395 (class 0 OID 17533)
-- Dependencies: 233
-- Data for Name: email_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3404 (class 0 OID 19909)
-- Dependencies: 242
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.email_preferences (email_preference_id, created_by, created_on, updated_by, updated_on, email_preferences, status, version_num) VALUES (1, 'system', '2019-01-14 00:00:00', 'abhi', '2019-01-14 00:00:00', ' {
                   "standardFolders": [
                     "Inbox",
                     "SentItems"
                   ],
                   "customFolders": [
                   ],
                   "emailsFromToFilter": [
                   ],
                   "emailsFromToRead": [
                   ]
 }
', '1', 1);
INSERT INTO public.email_preferences (email_preference_id, created_by, created_on, updated_by, updated_on, email_preferences, status, version_num) VALUES (2, 'system', '2019-01-14 00:00:00', 'abhi', '2019-01-14 00:00:00', ' {
                   "standardFolders": [
                     "Inbox",
                     "SentItems"
                   ],
                   "customFolders": [
                   ],
                   "emailsFromToFilter": [
                   ],
                   "emailsFromToRead": [
                   ]
 }
', '1', 1);
INSERT INTO public.email_preferences (email_preference_id, created_by, created_on, updated_by, updated_on, email_preferences, status, version_num) VALUES (3, 'system', '2019-01-14 00:00:00', 'abhi', '2019-01-14 00:00:00', ' {
					   "standardFolders": [
						 "Inbox",
						 "SentItems"
					   ],
					   "customFolders": [
					   ],
					   "emailsFromToFilter": [
					   ],
					   "emailsFromToRead": [
					   ]
	 }
	', '1', 1);


--
-- TOC entry 3405 (class 0 OID 19917)
-- Dependencies: 243
-- Data for Name: emailid; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.emailid (email_id, created_by, created_on, updated_by, updated_on, emailid_domain_type, emailid_type_id, status, version_num, email_domain_id, email_preference_id) VALUES ('abhishek.gupta02@irissoftware.com', 'System', '2019-01-14 00:00:00', 'System', '2019-01-14 00:00:00', 'INTERNAL', '1', '1', 1, 1, 1);


--
-- TOC entry 3380 (class 0 OID 17388)
-- Dependencies: 218
-- Data for Name: emailid_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.emailid_type (emailid_type_id, type_name, type_description, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (1, 'INDIVIDUAL', 'Represents individual email address ', 'system', '1', 1, '2019-01-14 00:00:00', 'system', '2019-01-14 00:00:00');
INSERT INTO public.emailid_type (emailid_type_id, type_name, type_description, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (2, 'WORK UNIT DL', 'Represents Team', 'system', '1', 1, '2019-01-14 00:00:00', 'system', '2019-01-14 00:00:00');


--
-- TOC entry 3406 (class 0 OID 19925)
-- Dependencies: 244
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.employee (employee_id, created_by, created_on, updated_by, updated_on, first_name, last_name, middle_name, status, version_num) VALUES (1691, 'system', '2019-01-14 00:00:00', 'system', '2019-01-14 00:00:00', 'abhishek', 'kumar', 'gupta', '1', 1);
INSERT INTO public.employee (employee_id, created_by, created_on, updated_by, updated_on, first_name, last_name, middle_name, status, version_num) VALUES (1692, 'system', '2019-01-14 00:00:00', 'system', '2019-01-14 00:00:00', 'mayank', 'zindal', NULL, '1', 1);
INSERT INTO public.employee (employee_id, created_by, created_on, updated_by, updated_on, first_name, last_name, middle_name, status, version_num) VALUES (1693, 'system', '2019-01-14 00:00:00', 'system', '2019-01-14 00:00:00', 'mayank', 'agrawal', NULL, '1', 1);


--
-- TOC entry 3407 (class 0 OID 19933)
-- Dependencies: 245
-- Data for Name: employee_emailid_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.employee_emailid_mapping (email_id, employee_id, created_by, created_on, updated_by, updated_on, analyse_tone, status, version_num) VALUES ('abhishek.gupta02@irissoftware.com', '1691', 'system', '2019-01-14 00:00:00', 'system', '2019-01-14 00:00:00', 'Y', '1', 1);


--
-- TOC entry 3381 (class 0 OID 17404)
-- Dependencies: 219
-- Data for Name: employee_hirerachy; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3382 (class 0 OID 17410)
-- Dependencies: 220
-- Data for Name: employee_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3383 (class 0 OID 17416)
-- Dependencies: 221
-- Data for Name: employee_work_unit_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3384 (class 0 OID 17422)
-- Dependencies: 222
-- Data for Name: entity_type; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3408 (class 0 OID 19941)
-- Dependencies: 246
-- Data for Name: execution_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.execution_status (status_id, created_by, created_on, updated_by, updated_on, status_desc, status_name) VALUES (1, NULL, NULL, NULL, NULL, 'process is currently running', 'Inprogress');
INSERT INTO public.execution_status (status_id, created_by, created_on, updated_by, updated_on, status_desc, status_name) VALUES (2, 'System', '2019-01-29 00:00:00', 'System', '2019-01-29 00:00:00', 'process is completed successfully', 'Complete');
INSERT INTO public.execution_status (status_id, created_by, created_on, updated_by, updated_on, status_desc, status_name) VALUES (3, 'System', '2019-01-29 00:00:00', 'System', '2019-01-29 00:00:00', 'execution failed', 'failure');


--
-- TOC entry 3385 (class 0 OID 17428)
-- Dependencies: 223
-- Data for Name: geo_location; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3386 (class 0 OID 17434)
-- Dependencies: 224
-- Data for Name: group_team_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3396 (class 0 OID 17545)
-- Dependencies: 234
-- Data for Name: individual_tone; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.individual_tone (individual_tone_id, individual_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (101, '', 'Abhi', '1', NULL, '2019-01-24 15:52:20.453', 'Abhi', '2019-01-24 15:52:20.453');
INSERT INTO public.individual_tone (individual_tone_id, individual_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (102, '', 'Abhi', '1', NULL, '2019-01-24 15:52:29.776', 'Abhi', '2019-01-24 15:52:29.776');
INSERT INTO public.individual_tone (individual_tone_id, individual_tone, created_by, status, version_num, updated_on, updated_by, created_on) VALUES (103, '', 'Abhi', '1', NULL, '2019-01-24 15:53:44.513', 'Abhi', '2019-01-24 15:53:44.513');


--
-- TOC entry 3387 (class 0 OID 17438)
-- Dependencies: 225
-- Data for Name: legal_entity; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3429 (class 0 OID 37868)
-- Dependencies: 267
-- Data for Name: login_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.login_details (user_id, created_by, created_on, updated_by, updated_on, access_key, is_active, login_type_id, pass, pass_history) VALUES ('shanu12@religiousIndia.com', 'System', '2019-01-29 00:00:00', 'System', '2019-01-29 00:00:00', NULL, '1', NULL, '1234', NULL);


--
-- TOC entry 3424 (class 0 OID 37792)
-- Dependencies: 262
-- Data for Name: qrtz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3425 (class 0 OID 37805)
-- Dependencies: 263
-- Data for Name: qrtz_calendars; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3422 (class 0 OID 37766)
-- Dependencies: 260
-- Data for Name: qrtz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.qrtz_cron_triggers (sched_name, trigger_name, trigger_group, cron_expression, time_zone_id) VALUES ('quartz-app', 'Sample Cron Job', 'DEFAULT', '0 0/2 * ? * *', 'Asia/Calcutta');


--
-- TOC entry 3398 (class 0 OID 17933)
-- Dependencies: 236
-- Data for Name: qrtz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.qrtz_fired_triggers (sched_name, entry_id, trigger_name, trigger_group, instance_name, fired_time, sched_time, priority, state, job_name, job_group, is_nonconcurrent, requests_recovery) VALUES ('quartz-app', 'c9985621-22ef-4f31-ae8f-1d0a14d17f881548412080725', 'Sample Cron Job', 'DEFAULT', 'c9985621-22ef-4f31-ae8f-1d0a14d17f88', 1548412320002, 1548412320000, 0, 'EXECUTING', 'Sample Cron Job', 'Test Group', true, false);


--
-- TOC entry 3419 (class 0 OID 37732)
-- Dependencies: 257
-- Data for Name: qrtz_job_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.qrtz_job_details (sched_name, job_name, job_group, description, job_class_name, is_durable, is_nonconcurrent, is_update_data, requests_recovery, job_data) VALUES ('quartz-app', 'Sample Cron Job', 'Test Group', NULL, 'com.hanogi.batch.jobs.CronJob', false, true, false, false, '\x230d0a23467269204a616e2032352031353a35383a30312049535420323031390d0a53616d706c655c2043726f6e5c204a6f62546573745c2047726f75703d636f6d2e68616e6f67692e62617463682e6a6f62732e43726f6e4a6f620d0a');


--
-- TOC entry 3428 (class 0 OID 37823)
-- Dependencies: 266
-- Data for Name: qrtz_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.qrtz_locks (sched_name, lock_name) VALUES ('quartz-app', 'TRIGGER_ACCESS');
INSERT INTO public.qrtz_locks (sched_name, lock_name) VALUES ('quartz-app', 'STATE_ACCESS');


--
-- TOC entry 3426 (class 0 OID 37813)
-- Dependencies: 264
-- Data for Name: qrtz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3427 (class 0 OID 37818)
-- Dependencies: 265
-- Data for Name: qrtz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.qrtz_scheduler_state (sched_name, instance_name, last_checkin_time, checkin_interval) VALUES ('quartz-app', 'c9985621-22ef-4f31-ae8f-1d0a14d17f88', 1548420746447, 7500);


--
-- TOC entry 3421 (class 0 OID 37753)
-- Dependencies: 259
-- Data for Name: qrtz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3423 (class 0 OID 37779)
-- Dependencies: 261
-- Data for Name: qrtz_simprop_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3420 (class 0 OID 37740)
-- Dependencies: 258
-- Data for Name: qrtz_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.qrtz_triggers (sched_name, trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) VALUES ('quartz-app', 'Sample Cron Job', 'DEFAULT', 'Sample Cron Job', 'Test Group', NULL, 1548412440000, 1548412320000, 0, 'BLOCKED', 'CRON', 1548412081000, 0, NULL, 1, '\x');


--
-- TOC entry 3388 (class 0 OID 17444)
-- Dependencies: 226
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3431 (class 0 OID 37886)
-- Dependencies: 269
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3400 (class 0 OID 19868)
-- Dependencies: 238
-- Data for Name: scheduler_job_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.scheduler_job_info (id, batch_id, cron_expression, cron_job, is_active, job_group, job_name, repeat_time, version_num, created_by, updated_by, updated_on, created_on) VALUES (1, 10, '0 0/2 * ? * *', true, true, 'Test Group', 'Sample Cron Job', NULL, NULL, NULL, NULL, NULL, NULL);


--
-- TOC entry 3389 (class 0 OID 17454)
-- Dependencies: 227
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3397 (class 0 OID 17554)
-- Dependencies: 235
-- Data for Name: tone; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3434 (class 0 OID 37936)
-- Dependencies: 272
-- Data for Name: user_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.user_details (user_id, created_by, created_on, updated_by, updated_on, email, firstname, gender, is_active, lastname, location, middlename, user_role_id) VALUES (1, 'System', '2019-01-29 00:00:00', 'System', '2019-01-29 00:00:00', 'shanu12@religiousIndia.com', NULL, NULL, '1', NULL, NULL, NULL, NULL);


--
-- TOC entry 3432 (class 0 OID 37895)
-- Dependencies: 270
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3391 (class 0 OID 17470)
-- Dependencies: 229
-- Data for Name: work_unit_emailid_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3390 (class 0 OID 17464)
-- Dependencies: 228
-- Data for Name: work_units_types; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3852 (class 0 OID 0)
-- Dependencies: 251
-- Name: aggregated_tone_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aggregated_tone_seq', 98, true);


--
-- TOC entry 3853 (class 0 OID 0)
-- Dependencies: 253
-- Name: calculated_tone_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calculated_tone_seq', 109, true);


--
-- TOC entry 3854 (class 0 OID 0)
-- Dependencies: 255
-- Name: email_header_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_header_seq', 106, true);


--
-- TOC entry 3855 (class 0 OID 0)
-- Dependencies: 248
-- Name: email_message_data_message_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_message_data_message_data_id_seq', 2, true);


--
-- TOC entry 3856 (class 0 OID 0)
-- Dependencies: 250
-- Name: email_message_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_message_data_seq', 100, false);


--
-- TOC entry 3857 (class 0 OID 0)
-- Dependencies: 252
-- Name: email_metadata_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_metadata_seq', 120, true);


--
-- TOC entry 3858 (class 0 OID 0)
-- Dependencies: 271
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1, false);


--
-- TOC entry 3859 (class 0 OID 0)
-- Dependencies: 254
-- Name: individual_tone_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.individual_tone_seq', 109, true);


--
-- TOC entry 3860 (class 0 OID 0)
-- Dependencies: 268
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 1, false);


--
-- TOC entry 3861 (class 0 OID 0)
-- Dependencies: 237
-- Name: scheduler_job_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scheduler_job_info_id_seq', 2, true);


--
-- TOC entry 3862 (class 0 OID 0)
-- Dependencies: 249
-- Name: test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_id_seq', 461, true);


-- Completed on 2019-02-12 18:36:49

--
-- PostgreSQL database dump complete
--

