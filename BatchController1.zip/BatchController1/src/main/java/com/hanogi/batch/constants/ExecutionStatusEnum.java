package com.hanogi.batch.constants;

public enum ExecutionStatusEnum {
	
	Complete,
	
	Inprogress,
	
	failure

}
