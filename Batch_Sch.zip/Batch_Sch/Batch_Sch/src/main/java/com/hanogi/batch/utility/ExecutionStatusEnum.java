package com.hanogi.batch.utility;

public enum ExecutionStatusEnum {
	Complete,

	Inprogress,

	failure,

	New

}
