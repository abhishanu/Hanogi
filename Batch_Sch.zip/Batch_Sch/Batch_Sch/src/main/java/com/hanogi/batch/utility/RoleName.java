package com.hanogi.batch.utility;

public enum RoleName {
	ROLE_USER, ROLE_ADMIN,ROLE_SUPER_ADMIN
}
