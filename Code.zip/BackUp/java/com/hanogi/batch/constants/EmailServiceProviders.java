package com.hanogi.batch.constants;

public enum EmailServiceProviders {
	
	MicrosoftExchange,
	
	Gmail,
	
	LotunNotes,
	
	Zymbra,
	
	Yahoo,
	
	Outlook,
	
	Office365

}
