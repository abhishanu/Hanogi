package com.hanogi.batch.reader;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.hanogi.batch.constants.ExecutionStatusEnum;
import com.hanogi.batch.dto.BatchRunDetails;
import com.hanogi.batch.dto.Email;
import com.hanogi.batch.utils.bo.EmailMessageData;

@Component
public class DataReader implements IDataReader {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	@Qualifier("mailReadersMaps")
	private Map<String, Map<String, IEmailReader>> mailReaders;

	@Autowired
	@Qualifier("emailDataQueue")
	private BlockingQueue<EmailMessageData> emailDataProcessingQueue;

	@Autowired
	private ToneReader<EmailMessageData> emailToneReader;

	private Calendar calendar = Calendar.getInstance();

	/**
	 * Exchange stores the datetimes with a precision down to the Millisecond, EWS
	 * only give you a precision on datetimes to the second however the
	 * Searchfilters do have a precision of milliseconds with Date time. So if you
	 * datetime stamps your using only have a precision of seconds then you need to
	 * use something like this eg where you wanted all email that was received after
	 * 7:43 and 8 seconds
	 * 
	 * SearchFilter sfs = new
	 * SearchFilter.IsGreaterThan(ItemSchema.DateTimeReceived,
	 * DateTime.ParseExact("2014/12/29 07:43:08.999", "yyyy/MM/dd HH:mm:ss.fff",
	 * null))
	 */
	@Override
	public void readData(List<Email> emailList, BatchRunDetails batchRunDetails) throws Exception {

		Map<String, ExecutionStatusEnum> emailProcessingStatusMap = new ConcurrentHashMap<>();

		try {
			logger.warn("Start processing batch for total emailId List:" + emailList.size());

			logger.warn("Batch processing start time:" + calendar.getTimeInMillis());

			for (Email email : emailList) {
				logger.info("setting execution status as Inprogress");
				emailProcessingStatusMap.put(email.getEmailId(), ExecutionStatusEnum.Inprogress);
			}

			for (Email email : emailList) {
				IEmailReader emailReader = mailReaders.get(email.getObjEmailDomainDetails().getEmailServiceProvider())
						.get(email.getObjEmailDomainDetails().getServerDeploymentType());

				logger.info("Start processing mailId:" + email.getEmailId());

				emailReader.readMail(email, batchRunDetails, emailProcessingStatusMap);

			}
		} catch (Exception e) {
			logger.error("Batch execution failed dew to:" + e.getMessage());
			// TO-Do mark batch as failed in DB.
			logger.error("BatchId:" + batchRunDetails.getBatchJobId() + "marked as Failed.");
			return;
		}

		while (!(emailDataProcessingQueue.isEmpty() && hasEmailReadersFinishedProcessing(emailProcessingStatusMap))) {

			EmailMessageData emailMessage = emailDataProcessingQueue.poll();

			if (null != emailMessage) {
				emailToneReader.readTone(emailMessage);
			}

		}

	}

	public boolean hasEmailReadersFinishedProcessing(Map<String, ExecutionStatusEnum> emailProcessingStatusMap) {

		boolean isComplete = emailProcessingStatusMap.containsValue(ExecutionStatusEnum.Inprogress) ? false : true;

		return isComplete;
	}

	public boolean hasEmailReadersContainsErrors(Map<String, ExecutionStatusEnum> emailProcessingStatusMap) {

		boolean hasErrors = emailProcessingStatusMap.containsValue(ExecutionStatusEnum.failure) ? true : false;

		return hasErrors;
	}

}
