package com.hanogi.batch.reader;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.hanogi.batch.constants.EmailDirection;
import com.hanogi.batch.constants.EmailPreference;
import com.hanogi.batch.constants.ExecutionStatusEnum;
import com.hanogi.batch.dto.BatchRunDetails;
import com.hanogi.batch.dto.Email;
import com.hanogi.batch.dto.EmailDomainDetails;
import com.hanogi.batch.dto.EmailHeader;
import com.hanogi.batch.dto.EmailMetadata;
import com.hanogi.batch.dto.EmailPreferenceMap;
import com.hanogi.batch.exceptions.ConnectionException;
import com.hanogi.batch.repositories.EmailPreferenceMapRepositry;
import com.hanogi.batch.services.CacheService;
import com.hanogi.batch.utils.bo.EmailMessageData;
import com.hanogi.batch.utils.bo.OPMSExchangeConnectionParams;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.BodyType;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.LogicalOperator;
import microsoft.exchange.webservices.data.core.exception.service.remote.ServiceRequestException;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.schema.EmailMessageSchema;
import microsoft.exchange.webservices.data.core.service.schema.FolderSchema;
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.FolderId;
import microsoft.exchange.webservices.data.property.complex.Mailbox;
import microsoft.exchange.webservices.data.search.FindFoldersResults;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.FolderView;
import microsoft.exchange.webservices.data.search.ItemView;
import microsoft.exchange.webservices.data.search.filter.SearchFilter;

@Component
public class OPMSExchangeReader implements IEmailReader {

	private final Logger log = LoggerFactory.getLogger(getClass());

	private Calendar calendar = Calendar.getInstance();

	@Autowired
	@Qualifier("emailDataQueue")
	private BlockingQueue<EmailMessageData> emailDataProcessingQueue;

	@Autowired
	private EmailPreferenceMapRepositry emailPreferenceMapRepo;

	@Autowired
	@Qualifier("cacheService")
	private CacheService cacheService;

	@Value("${connectionRetryAttems}")
	private Integer noOfConnectionAttempts = 1;

	@PostConstruct
	public void postConstruct() {
		log.info("OPMSExchangeReader bean created....");
	}

	@Async("batchProcessorThreadPool")
	public void readMail(Email email, BatchRunDetails batchRunDetails,
			Map<String, ExecutionStatusEnum> emailProcessingStatusMap) throws Exception {

		int noOfTriedCOunt = 0;

		try {
			if (noOfTriedCOunt <= noOfConnectionAttempts) {

				noOfTriedCOunt++;
				log.info(noOfTriedCOunt + ":Attempt to connect with mail server for mailId:" + email.getEmailId());

				// Load Connection Configurations
				OPMSExchangeConnectionParams connectionParams = populateConnectionParams(
						email.getObjEmailDomainDetails());

				// Create connection
				ExchangeService exchangeService = createExchangeConnection(connectionParams);

				Mailbox userMailbox = new Mailbox(email.getEmailId());

				if (null != email.getObjEmailPreferences()) {

					EmailPreference emailPreferences = getMailPreferences(email);

					// Reading the standard folders

					if (null != emailPreferences.getStandardFolders()
							& emailPreferences.getStandardFolders().size() > 0) {

						List<String> standardFolders = emailPreferences.getStandardFolders();

						for (String folder : standardFolders) {

							FolderId folderId = new FolderId(WellKnownFolderName.valueOf(folder), userMailbox);

							processEmails(folderId, email, exchangeService, batchRunDetails, emailPreferences);

							log.warn("Processing complete for:" + folder + ",at:" + calendar.getTimeInMillis());
						}

						log.warn("Finished all standard folders.");

					}

					// Reading the custom folders

					if (null != emailPreferences.getCustomFolders() & emailPreferences.getCustomFolders().size() > 0) {

						List<String> customFolders = emailPreferences.getCustomFolders();

						for (String folder : customFolders) {

							Folder customFolder = getFolderFromPath(folder, exchangeService, userMailbox);

							processEmails(customFolder.getId(), email, exchangeService, batchRunDetails,
									emailPreferences);

							log.warn("Processing complete for:" + folder + ",at:" + calendar.getTimeInMillis());
						}
					}
				}

				log.warn("Processing complete for:" + email.getEmailId() + ",at:" + calendar.getTimeInMillis());
				log.info(email.getEmailId() + ":mailId execution completed");
				emailProcessingStatusMap.put(email.getEmailId(), ExecutionStatusEnum.Complete);

			} else {
				log.error(
						"No of retry to connect with mail server are over and still unable to connect with server for mailId:"
								+ email.getEmailId());
				emailProcessingStatusMap.put(email.getEmailId(), ExecutionStatusEnum.failure);
			}
		} catch (ConnectionException e) {

			log.error(
					"BatchId:" + batchRunDetails.getBatchJobId() + "marked as Failed dew to" + e.getLocalizedMessage());

		} catch (ServiceRequestException connectionSericeException) {

			log.error("Service unable to connect with Mail Exchange Server dew to:"
					+ connectionSericeException.getMessage());
			log.info(email.getEmailId() + ":mailId execution failed.Retrying....");

			readMail(email, batchRunDetails, emailProcessingStatusMap);

		} catch (Exception e) {
			log.info(email.getEmailId() + ":mailId execution failed.Retrying....");

			readMail(email, batchRunDetails, emailProcessingStatusMap);
		}
	}

	private OPMSExchangeConnectionParams populateConnectionParams(EmailDomainDetails objEmailDomainDetails)
			throws Exception {

		Gson g = new Gson();

		OPMSExchangeConnectionParams connectionParams = null;

		if (StringUtils.isNotBlank(objEmailDomainDetails.getEmailServerConfig())) {

			connectionParams = g.fromJson(objEmailDomainDetails.getEmailServerConfig(),
					OPMSExchangeConnectionParams.class);
		} else {
			throw new ConnectionException(
					"Missing Mail Server Connection Parameters for email Domain : " + objEmailDomainDetails);
		}

		return connectionParams;
	}

	private ExchangeService createExchangeConnection(OPMSExchangeConnectionParams connectionParams) throws Exception {

		ExchangeService exchangeService = null;

		try {

			exchangeService = new ExchangeService(ExchangeVersion.valueOf(connectionParams.getExchangeVersion()));

			exchangeService.setUrl(new URI(connectionParams.getExchangeServerURL()));

			ExchangeCredentials credentials = new WebCredentials(connectionParams.getAdminUserName(),
					connectionParams.getAdminPassword());

			exchangeService.setCredentials(credentials);

		} catch (URISyntaxException e) {

			log.error("Error while making connection with exchange server ( Incorrect URL ): ", e);

			throw new ConnectionException("Error while making connection with exchange server ( Incorrect URL )");
		}

		return exchangeService;
	}

	private void processEmails(FolderId folderId, Email email, ExchangeService exchangeService,
			BatchRunDetails batchRunDetails, EmailPreference emailPreferences) throws Exception {
		log.info("processing mail(s) for mailId:" + email.getEmailId());

		log.warn(email.getEmailId() + ":: Email processing start time:" + calendar.getTimeInMillis());

		List<String> emailsFromToRead = emailPreferences.getEmailsFromToRead();

		// Start reading mails
		SearchFilter unreadFilter = emailFilterCriteriaDateRange(batchRunDetails.getFromDate(),
				batchRunDetails.getToDate());

		if (unreadFilter != null) {

			if (null != folderId) {

				String folderName = folderId.getFolderName().name();

				log.info("processing mail(s) for folder name:" + folderName);

				log.warn("Processing for folder name:" + folderName + ",at:" + calendar.getTimeInMillis());

				ItemView view = new ItemView(50);

				FindItemsResults<Item> results = exchangeService.findItems(folderId, unreadFilter, view);

				log.warn("Got results from mail server at:" + calendar.getTimeInMillis());

				System.out.println("Result Count:" + results.getTotalCount());

				for (Item item : results.getItems()) {

					PropertySet psPropset = new PropertySet(EmailMessageSchema.UniqueBody);
					psPropset.setRequestedBodyType(BodyType.Text);
					psPropset.setBasePropertySet(BasePropertySet.FirstClassProperties);

					EmailMessage emailMessage = EmailMessage.bind(exchangeService, item.getId(), psPropset);

					String senderMailAddress = emailMessage.getSender().getAddress();

					EmailMessageData emailMessageData = new EmailMessageData();

					if (!folderName.equalsIgnoreCase(WellKnownFolderName.SentItems.name())) {

						boolean shallReadMail = emailsFromToRead.stream()
								.anyMatch(e -> e.equalsIgnoreCase(senderMailAddress));

						// Filter the email from the sender that is not mentioned in the FromEmailToRead
						// list
						if (shallReadMail) {
							continue;
						}
					}

					emailMessageData.setEmailBody(emailMessage.getBody().toString());
					emailMessageData.setUniqueEmailBody(emailMessage.getUniqueBody().getText());

					// Setting up Meta data
					EmailMetadata emailMetaData = new EmailMetadata();

					emailMetaData.setBatchRunDetails(batchRunDetails.getBatchRunId());
					emailMetaData.setFromEmailId(emailMessage.getSender().getAddress());
					emailMetaData.setEmailProcessingExecutionStatus(ExecutionStatusEnum.Inprogress.name());

					if (folderName.equalsIgnoreCase(WellKnownFolderName.SentItems.name())) {
						emailMetaData.setEmailDirection(EmailDirection.Sent.name());
					} else {
						emailMetaData.setEmailDirection(EmailDirection.Received.name());
					}

					// Setting up Header in Meta data

					EmailHeader emailHeader = new EmailHeader();

					if (null != emailMessage.getCcRecipients()) {

						String ccEmailAddresses = String.join(",", emailMessage.getCcRecipients().getItems().stream()
								.map(eAdd -> eAdd.getAddress()).collect(Collectors.toList()));

						emailHeader.setCcEmailId(ccEmailAddresses);
					}

					if (folderName.equalsIgnoreCase(WellKnownFolderName.SentItems.name())) {
						emailHeader.setEmailDate(emailMessage.getDateTimeSent());
					} else {
						emailHeader.setEmailDate(emailMessage.getDateTimeReceived());
					}

					emailHeader.setImportance(emailMessage.getImportance().name());

					emailHeader.setInReplyTo(emailMessage.getInReplyTo());

					emailHeader.setMessageId(emailMessage.getInternetMessageId());

					emailHeader.setReferenceMessageId(emailMessage.getReferences());

					emailHeader.setSubject(emailMessage.getSubject());

					if (null != emailMessage.getToRecipients()) {

						String toEmailAddresses = String.join(",", emailMessage.getToRecipients().getItems().stream()
								.map(eAdd -> eAdd.getAddress()).collect(Collectors.toList()));

						emailHeader.setToEmailId(toEmailAddresses);
					}

					emailMetaData.setEmailHeader(emailHeader);

					emailMessageData.setEmailMetaData(emailMetaData);

					// Update the Cache with the EmailMessage if not already present
					String MessageId = emailMessageData.getEmailMetaData().getEmailHeader().getMessageId();

					log.warn("Setting execution status as Inprogress in cache at:" + calendar.getTimeInMillis());

					boolean doNotExists = cacheService.checkAddUpdateCache(MessageId, ExecutionStatusEnum.Inprogress);

					if (!doNotExists) {
						emailDataProcessingQueue.put(emailMessageData);
						// log.info("dataQuesue size:" + emailDataProcessingQueue.size());
					}

				}

			}
		} else {
			log.error("Issue with filter range.");
		}

	}

	public SearchFilter emailFilterCriteriaDateRange(Date fromDate, Date toDate) {
		log.info("Date range criteria is from:" + fromDate.toString() + " To:" + toDate.toString());

		try {
			SearchFilter searchFromFilter = new SearchFilter.IsGreaterThanOrEqualTo(ItemSchema.DateTimeReceived,
					fromDate);

			SearchFilter searchToFilter = new SearchFilter.IsLessThanOrEqualTo(ItemSchema.DateTimeReceived, toDate);

			SearchFilter unreadFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, searchFromFilter,
					searchToFilter);

			return unreadFilter;
		} catch (Exception e) {
			log.error("Error while setting date range filter dew to:" + e.getMessage());
			return null;
		}
	}

	public Folder getFolderFromPath(String FolderPath, ExchangeService exchangeService, Mailbox userMailbox)
			throws Exception {

		FolderId folderid = new FolderId(WellKnownFolderName.MsgFolderRoot, userMailbox);

		Folder tfTargetFolder = Folder.bind(exchangeService, folderid);

		PropertySet psPropset = new PropertySet(BasePropertySet.FirstClassProperties);

		String[] fldArray = FolderPath.split("#");

		for (int lint = 0; lint < fldArray.length; lint++) {

			FolderView fvFolderView = new FolderView(1);

			fvFolderView.setPropertySet(psPropset);

			SearchFilter SfSearchFilter = new SearchFilter.IsEqualTo(FolderSchema.DisplayName, fldArray[lint]);

			FindFoldersResults findFolderResults = exchangeService.findFolders(tfTargetFolder.getId(), SfSearchFilter,
					fvFolderView);

			if (findFolderResults.getTotalCount() > 0) {

				for (Folder folder : findFolderResults.getFolders()) {
					tfTargetFolder = folder;
				}
			} else {
				tfTargetFolder = null;
				break;
			}
		}
		if (tfTargetFolder != null) {
			return tfTargetFolder;
		} else {
			throw new Exception("Folder Not found");
		}
	}

	private EmailPreference getMailPreferences(Email email) {
		try {
			log.info("Getting mail preferences......");

			EmailPreferenceMap emailPreferencesMap = email.getObjEmailPreferences();

			Gson gson = new Gson();

			EmailPreference emailPreferences = null;

			if (emailPreferencesMap != null) {
				emailPreferences = gson.fromJson(emailPreferencesMap.getEmailPreferencesJson(), EmailPreference.class);
			}
			return emailPreferences;
		} catch (Exception e) {
			log.error("Email preferences string is not as expected with error:" + e.getMessage());
			return null;
		}
	}

}
