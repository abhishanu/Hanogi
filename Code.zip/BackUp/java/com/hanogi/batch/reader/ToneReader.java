package com.hanogi.batch.reader;

public interface ToneReader<T> {
	
	public void readTone(T data);

}
