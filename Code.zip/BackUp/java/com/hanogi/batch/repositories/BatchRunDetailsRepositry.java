package com.hanogi.batch.repositories;

import org.springframework.data.repository.CrudRepository;

import com.hanogi.batch.dto.BatchRunDetails;

public interface BatchRunDetailsRepositry extends CrudRepository<BatchRunDetails, java.lang.Integer> {

}
