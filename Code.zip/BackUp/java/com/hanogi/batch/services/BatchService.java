package com.hanogi.batch.services;

import com.hanogi.batch.dto.BatchRunDetails;

/**
 * @author abhishek.gupta02
 *
 */

public interface BatchService {

	void createNewBatch(BatchRunDetails batchRunDetails);

	Boolean runBatch(BatchRunDetails batchRunDetails);

	BatchRunDetails getBatchRunDetails(Integer batchId);

}
