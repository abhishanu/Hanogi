package com.hanogi.batch.services;

import com.hanogi.batch.constants.ExecutionStatusEnum;

public interface CacheService {

	boolean checkAddUpdateCache(String messageId, ExecutionStatusEnum inprogress);

	void cleanConcurrentCache();
	
	ExecutionStatusEnum getStatusOfMessage(String messageId);

}
