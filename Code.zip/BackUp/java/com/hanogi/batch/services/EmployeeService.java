package com.hanogi.batch.services;

import java.util.List;

import com.hanogi.batch.dto.Email;

public interface EmployeeService {

	public List<Email> getEmployeeMailListToToneAnalyse();
}
