package com.hanogi.batch.services;

public interface IToneAnalyser {
	
	public String analyseTone(String messageBody);
	
}
