package com.hanogi.batch.services.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hanogi.batch.dto.BatchRunDetails;
import com.hanogi.batch.dto.Email;
import com.hanogi.batch.reader.DataReader;
import com.hanogi.batch.repositories.BatchRunDetailsRepositry;
import com.hanogi.batch.services.BatchService;
import com.hanogi.batch.services.EmployeeService;

@Component
public class BatchServiceImpl implements BatchService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataReader dataReader;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private BatchRunDetailsRepositry batchrunDetailsRepo;

	@Override
	public void createNewBatch(BatchRunDetails batchRunDetails) {

	}

	@Override
	public Boolean runBatch(BatchRunDetails batchRunDetails) {

		try {
			List<Email> employeeMailListToToneAnalyse = employeeService.getEmployeeMailListToToneAnalyse();

			if (employeeMailListToToneAnalyse != null && employeeMailListToToneAnalyse.size() != 0) {
				dataReader.readData(employeeMailListToToneAnalyse, batchRunDetails);
				return Boolean.TRUE;
			} else {
				logger.warn("No mail Id to found to process");
				return Boolean.FALSE;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Failure while running the batch:" + e.getMessage());
			return Boolean.FALSE;
		}
	}

	@Override
	public BatchRunDetails getBatchRunDetails(Integer batchId) {
		Optional<BatchRunDetails> batchRun = batchrunDetailsRepo.findById(batchId);

		BatchRunDetails batchRunDetails = batchRun.get();

		if (batchRunDetails != null) {
			return batchRunDetails;
		} else {
			return null;
		}
	}

}
