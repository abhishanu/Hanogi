package com.hanogi.batch.constants;

public enum ExecutionStatus {
	
	Complete,
	
	Inprogress,
	
	failure

}
