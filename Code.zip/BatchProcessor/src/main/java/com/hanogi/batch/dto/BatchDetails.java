package com.hanogi.batch.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import com.hanogi.batch.configs.audit.AuditFields;

@Entity
@Table(name = "BATCH_DETAILS")
public class BatchDetails extends AuditFields<String> {

	@Version
	@Column(name = "version_num")
	private Integer versionNum;

	@Id
	@Column(name = "batch_id")
	private Integer batchId;

	@Column
	private Date fromDate;

	@Column
	private Date toDate;

	@Column(name = "batch_status")
	private Integer batchStatus;

	@Column(name = "batch_type_id")
	private String batchTypeId;

	@Column(name = "batch_status_details", columnDefinition = "TEXT")
	private String batchStatusDetails;

	@Column(name = "batch_run_date")
	private Date batchRunDate;

	public Integer getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(Integer versionNum) {
		this.versionNum = versionNum;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Integer getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(Integer batchStatus) {
		this.batchStatus = batchStatus;
	}

	public String getBatchTypeId() {
		return batchTypeId;
	}

	public void setBatchTypeId(String batchTypeId) {
		this.batchTypeId = batchTypeId;
	}

	public String getBatchStatusDetails() {
		return batchStatusDetails;
	}

	public void setBatchStatusDetails(String batchStatusDetails) {
		this.batchStatusDetails = batchStatusDetails;
	}

	public Date getBatchRunDate() {
		return batchRunDate;
	}

	public void setBatchRunDate(Date batchRunDate) {
		this.batchRunDate = batchRunDate;
	}

}
