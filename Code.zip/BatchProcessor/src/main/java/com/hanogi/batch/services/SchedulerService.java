package com.hanogi.batch.services;

import com.hanogi.batch.dto.BatchDetails;
import com.hanogi.batch.dto.SchedulerJobInfo;

/**
 * @author Abhishek
 */

public interface SchedulerService {

	void startAllActiveSchedulers();

	void scheduleNewJob(SchedulerJobInfo jobInfo);

	void updateScheduleJob(SchedulerJobInfo jobInfo);

	boolean unScheduleJob(String jobName);

	boolean deleteJob(SchedulerJobInfo jobInfo);

	boolean pauseJob(SchedulerJobInfo jobInfo);

	boolean resumeJob(SchedulerJobInfo jobInfo);

	boolean startJobNow(SchedulerJobInfo jobInfo);

	boolean createNewBatch(BatchDetails batchDetails);

	boolean createNewScheduler(SchedulerJobInfo schedulerJobInfo);

}
