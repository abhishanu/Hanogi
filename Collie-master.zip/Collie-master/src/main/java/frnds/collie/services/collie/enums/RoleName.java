package frnds.collie.services.collie.enums;

public enum RoleName {
	ROLE_USER, ROLE_ADMIN, ROLE_SUPER_ADMIN, ROLE_AGENT, ROLE_PARTNER
}
