package abhi.game.cric.MyCricket.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import abhi.game.cric.MyCricket.util.AuditFields;

@Entity
@Table(name = "all_games")
@JsonDeserialize
public class Games extends AuditFields<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer gameId;

	@Column(name = "Game_Name")
	private String gameName;

	private String descr;

	private Integer points;
	
	@Column(name="page_url")
	private String pageUrl;

	public Integer getGameId() {
		return gameId;
	}

	public void setGameId(Integer gameId) {
		this.gameId = gameId;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public String getDesc() {
		return descr;
	}

	public void setDesc(String desc) {
		this.descr = desc;
	}

	public Integer getPoints() {
		return points;
	}

	public void setPoints(Integer points) {
		this.points = points;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

}
