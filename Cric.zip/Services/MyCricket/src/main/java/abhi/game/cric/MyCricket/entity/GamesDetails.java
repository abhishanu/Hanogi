package abhi.game.cric.MyCricket.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import abhi.game.cric.MyCricket.util.AuditFields;

@Entity
@Table(name = "user_game_details")
public class GamesDetails extends AuditFields<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer detailsId;

	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "team_order", columnDefinition = "TEXT")
	private String teamorder;

	private Long totalPoints;

	private Integer gameId;

	private double averagePoints;

	public Integer getDetailsId() {
		return detailsId;
	}

	public void setDetailsId(Integer detailsId) {
		this.detailsId = detailsId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getTeamorder() {
		return teamorder;
	}

	public void setTeamorder(String teamorder) {
		this.teamorder = teamorder;
	}

	public Long getTotalPoints() {
		return totalPoints;
	}

	public void setTotalPoints(Long totalPoints) {
		this.totalPoints = totalPoints;
	}

	public double getAveragePoints() {
		return averagePoints;
	}

	public void setAveragePoints(double d) {
		this.averagePoints = d;
	}

	public Integer getGameId() {
		return gameId;
	}

	public void setGameId(Integer gameId) {
		this.gameId = gameId;
	}
}
