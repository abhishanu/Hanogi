package abhi.game.cric.MyCricket.entity.games;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import abhi.game.cric.MyCricket.util.AuditFields;

@Entity
@Table(name = "batsman_fight_game")
public class BatsmanFightGame extends AuditFields<String> {

	@Version
	private Integer changeAttempted;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "entry_id")
	private Integer entryId;

	@Column(name="game_Id")
	private Long gameId;
	
	@Column
	private Integer userId;

	@Column(name = "selected_players", columnDefinition = "TEXT")
	private String selectedPlayersArray;

	private Boolean isActive;

	@Column(name = "total_scored_runs")
	private Integer totalScoredRuns;

	public Integer getEntryId() {
		return entryId;
	}

	public void setEntryId(Integer entryId) {
		this.entryId = entryId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getChangeAttempted() {
		return changeAttempted;
	}

	public void setChangeAttempted(Integer changeAttempted) {
		this.changeAttempted = changeAttempted;
	}

	public String getSelectedPlayersArray() {
		return selectedPlayersArray;
	}

	public void setSelectedPlayersArray(String selectedPlayersArray) {
		this.selectedPlayersArray = selectedPlayersArray;
	}

	public Integer getTotalScoredRuns() {
		return totalScoredRuns;
	}

	public void setTotalScoredRuns(Integer totalScoredRuns) {
		this.totalScoredRuns = totalScoredRuns;
	}

	public Long getGameId() {
		return gameId;
	}

	public void setGameId(Long gameId) {
		this.gameId = gameId;
	}

}
