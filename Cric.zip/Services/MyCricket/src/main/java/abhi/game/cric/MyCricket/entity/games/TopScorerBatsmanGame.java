package abhi.game.cric.MyCricket.entity.games;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import abhi.game.cric.MyCricket.util.AuditFields;

@Entity
@Table(name = "top_scorer_batsman_game")
public class TopScorerBatsmanGame extends AuditFields<String> {

	@Version
	private Integer changeAttempted;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "entry_id")
	private Integer entryId;

	@Column
	private Integer userId;

	@Column(name = "player_selected")
	private String selectedPlayer;

	private Boolean isActive;

	@Column(name = "game_Id")
	private Long gameId;

	@Column(name = "total_scored_runs")
	private Integer totalScoredRuns;

	public Integer getEntryId() {
		return entryId;
	}

	public void setEntryId(Integer entryId) {
		this.entryId = entryId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getChangeAttempted() {
		return changeAttempted;
	}

	public void setChangeAttempted(Integer changeAttempted) {
		this.changeAttempted = changeAttempted;
	}

	public Integer getTotalScoredRuns() {
		return totalScoredRuns;
	}

	public void setTotalScoredRuns(Integer totalScoredRuns) {
		this.totalScoredRuns = totalScoredRuns;
	}

	public String getSelectedPlayer() {
		return selectedPlayer;
	}

	public void setSelectedPlayer(String selectedPlayer) {
		this.selectedPlayer = selectedPlayer;
	}

	public Long getGameId() {
		return gameId;
	}

	public void setGameId(Long gameId) {
		this.gameId = gameId;
	}

}
