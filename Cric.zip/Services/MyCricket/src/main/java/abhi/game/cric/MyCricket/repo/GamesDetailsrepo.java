package abhi.game.cric.MyCricket.repo;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.GamesDetails;

public interface GamesDetailsrepo extends CrudRepository<GamesDetails, Integer> {

	GamesDetails findByUserId(Integer userId);

}
