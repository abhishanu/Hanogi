package abhi.game.cric.MyCricket.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.Games;

public interface GamesRepo extends CrudRepository<Games, Integer> {
	@Override
    List<Games> findAll();
}
