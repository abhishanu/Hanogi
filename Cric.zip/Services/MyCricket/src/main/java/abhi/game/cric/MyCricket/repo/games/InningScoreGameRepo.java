package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.InningScoreGame;

public interface InningScoreGameRepo extends CrudRepository<InningScoreGame, Integer>{

}
