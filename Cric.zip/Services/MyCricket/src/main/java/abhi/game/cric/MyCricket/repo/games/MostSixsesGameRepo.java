package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.MostSixsesGame;

public interface MostSixsesGameRepo extends CrudRepository<MostSixsesGame, Integer>{

}
