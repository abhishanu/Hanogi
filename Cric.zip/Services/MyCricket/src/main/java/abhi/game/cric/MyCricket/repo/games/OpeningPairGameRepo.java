package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.OpeningPairGame;

public interface OpeningPairGameRepo extends CrudRepository<OpeningPairGame, Integer> {

	OpeningPairGame findByUserIdAndGameId(Integer userId, Long gameId);
}
