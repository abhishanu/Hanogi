package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.TeamRankGame;

public interface TeamRankGameRepo extends CrudRepository<TeamRankGame, Integer>{
	TeamRankGame findByUserId(Integer userId);
}
