package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.TopMatchPlayerScoreGame;

public interface TopMatchPlayerScoreGameRepo extends CrudRepository<TopMatchPlayerScoreGame, Integer>{

}
