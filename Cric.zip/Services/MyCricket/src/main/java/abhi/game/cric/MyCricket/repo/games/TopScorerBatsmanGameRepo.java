package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.TopScorerBatsmanGame;

public interface TopScorerBatsmanGameRepo extends CrudRepository<TopScorerBatsmanGame, Integer> {

}
