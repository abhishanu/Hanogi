package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.TossGame;

public interface TossGameRepo extends CrudRepository<TossGame, Integer>{

}
