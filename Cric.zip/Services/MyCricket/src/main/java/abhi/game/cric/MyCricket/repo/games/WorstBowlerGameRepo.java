package abhi.game.cric.MyCricket.repo.games;

import org.springframework.data.repository.CrudRepository;

import abhi.game.cric.MyCricket.entity.games.WorstBowlerGame;

public interface WorstBowlerGameRepo extends CrudRepository<WorstBowlerGame, Integer>{

}
