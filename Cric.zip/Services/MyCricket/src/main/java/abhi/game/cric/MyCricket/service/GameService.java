package abhi.game.cric.MyCricket.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

import abhi.game.cric.MyCricket.entity.Games;
import abhi.game.cric.MyCricket.entity.GamesDetails;
import abhi.game.cric.MyCricket.entity.games.OpeningPairGame;
import abhi.game.cric.MyCricket.entity.games.TeamRankGame;
import abhi.game.cric.MyCricket.repo.GamesDetailsrepo;
import abhi.game.cric.MyCricket.repo.GamesRepo;
import abhi.game.cric.MyCricket.repo.games.BatsmanFightGameRepo;
import abhi.game.cric.MyCricket.repo.games.InningScoreGameRepo;
import abhi.game.cric.MyCricket.repo.games.MostSixsesGameRepo;
import abhi.game.cric.MyCricket.repo.games.OpeningPairGameRepo;
import abhi.game.cric.MyCricket.repo.games.TeamRankGameRepo;
import abhi.game.cric.MyCricket.repo.games.TopMatchPlayerScoreGameRepo;
import abhi.game.cric.MyCricket.repo.games.TopScorerBatsmanGameRepo;
import abhi.game.cric.MyCricket.repo.games.TossGameRepo;
import abhi.game.cric.MyCricket.repo.games.WorstBowlerGameRepo;
import abhi.game.cric.MyCricket.util.Response;

@Service
public class GameService {

	@Autowired
	private GamesDetailsrepo userGamesDetailsRepo;

	@Autowired
	private GamesRepo gamesRepo;

	@Autowired
	private TeamRankGameRepo teamRankRepo;

	@Autowired
	private TossGameRepo tossRepo;

	@Autowired
	private BatsmanFightGameRepo batsmanFightGameRepo;

	@Autowired
	private InningScoreGameRepo inningScoreGameRepo;

	@Autowired
	private MostSixsesGameRepo mostSixsesGameRepo;

	@Autowired
	private OpeningPairGameRepo openingPairGameRepo;

	@Autowired
	private TopMatchPlayerScoreGameRepo topMatchPlayerScoreGameRepo;

	@Autowired
	private TopScorerBatsmanGameRepo topScorerBatsmanGameRepo;

	@Autowired
	private WorstBowlerGameRepo worstBowlerGameRepo;

	@SuppressWarnings("finally")
	@Transactional
	public Response saveTeamOrder(Map<String, Object> request) {
		Response response = new Response();

		response.setState(false);

		TeamRankGame teamRank;

		try {
			if (request != null) {
				Integer userId = (Integer) request.get("userId");

				List<String> teamOrder = (List<String>) request.get("teamList");

				teamRank = teamRankRepo.findByUserId(userId);

				if (teamRank == null) {
					teamRank = new TeamRankGame();
					teamRank.setIsActive(true);
					teamRank.setUserId(userId);
				}

				if (teamOrder != null) {
					teamRank.setTeamOrder(teamOrder.toString());
				}
				boolean isSaved = teamRankRepo.save(teamRank) != null;

				String msg = isSaved ? "Success" : "Failure";

				response.setMsg(msg);
				response.setState(isSaved);
			}
		} catch (Exception e) {
			response.setMsg("Error while saving the teamPreference...Try later!");
		} finally {
			return response;
		}

	}

	@SuppressWarnings("finally")
	public Response getGamesDetails(Integer userId) {
		Response response = new Response();

		response.setState(false);

		try {
			GamesDetails gamesDetails = userGamesDetailsRepo.findByUserId(userId);

			if (gamesDetails != null) {
				Map<String, Object> map = new HashMap<String, Object>(1);
				response.setMsg("Success");
				response.setState(true);
				map.put("game_details", gamesDetails);
				response.setResponseMap(map);
			} else {
				response.setMsg("User Not Found");
			}
		} catch (Exception e) {
			response.setMsg("Error while fetching details...");
		} finally {
			return response;
		}

	}

	public Response getAllGames() {
		Response response = new Response();

		response.setState(false);
		try {
			List<Games> allGames = gamesRepo.findAll();

			if (allGames != null) {
				Map<String, Object> map = new HashMap<String, Object>(1);
				if (allGames.isEmpty()) {
					response.setMsg("No games found");
				} else {
					map.put("All_Games", allGames);
					response.setMsg("Success");
					response.setResponseMap(map);
				}
			} else {
				response.setMsg("No games found");
			}
			response.setState(true);
			return response;
		} catch (Exception e) {
			response.setMsg("Error...");
			return response;
		}

	}

	@SuppressWarnings("finally")
	public Response getTeamOrder(Integer userId) {
		Response response = new Response();
		response.setState(false);

		try {
			JsonParser jsonParser = new JsonParser();
			TeamRankGame userTeamRank = teamRankRepo.findByUserId(userId);

			if (userTeamRank != null) {
				String teamorder = userTeamRank.getTeamOrder();

				JsonArray teamOrderObject = (JsonArray) jsonParser.parse(teamorder);

				Map<String, Object> map = new HashMap<String, Object>(1);
				map.put("teamOrder", teamOrderObject.toString());
				response.setResponseMap(map);
			}
			response.setState(true);
			response.setMsg("Success");
		} catch (Exception e) {
			System.err.println("Error in getTeamOrder:" + e.getMessage());
			response.setMsg("Error....");
		} finally {
			return response;
		}
	}

	public Response saveOpeningPair(Map<String, Object> request) {
		Response response = new Response();
		Boolean isSaved = false;
		response.setState(isSaved);

		try {
			OpeningPairGame openingPairGame;
			Integer userId = (Integer) request.get("userId");
			Long gameId = (Long) request.get("gameId");

			if (userId != null) {
				openingPairGame = openingPairGameRepo.findByUserIdAndGameId(userId, gameId);
				if (openingPairGame != null) {
					openingPairGame.setIsActive(true);
					openingPairGame.setSelectedTeam((String) request.get("selectedTeam"));
				} else {
					openingPairGame = new OpeningPairGame();
					openingPairGame.setIsActive(true);
					openingPairGame.setGameId(gameId);
					openingPairGame.setSelectedTeam((String) request.get("selectedTeam"));
					openingPairGame.setUserId(userId);
				}
				isSaved = openingPairGameRepo.save(openingPairGame) != null;
			}

			response.setState(isSaved);
		} catch (Exception e) {
			response.setMsg("Failed");
			response.setState(false);
		} finally {
			return response;
		}

	}

}
