package abhi.game.cric.MyCricket.util;

public enum PlayingRole {
	Batsman, Bowler, All_Rounder
}
