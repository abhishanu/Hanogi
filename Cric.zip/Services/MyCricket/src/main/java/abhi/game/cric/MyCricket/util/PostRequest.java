package abhi.game.cric.MyCricket.util;

import java.util.Map;

public class PostRequest {

	private Map<String, Object> request;

	public Map<String, Object> getRequest() {
		return request;
	}

	public void setRequest(Map<String, Object> request) {
		this.request = request;
	}
}
