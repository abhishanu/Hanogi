import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { Storage } from '@ionic/storage';

@Injectable()
export class AuthGuardService implements CanActivate {
    isUserLoggedIn: BehaviorSubject<Boolean> = new BehaviorSubject(false);
    isNewUser : BehaviorSubject<Boolean> = new BehaviorSubject(true);
    constructor(private router: Router, private storage: Storage) {
            this.checkIsNewUser();
    }

    // logout() {
    //     this.isUserLoggedIn.next(false);
    //     this.router.navigateByUrl('login');
    // }

    async checkIsNewUser() {
        let savedValue;
        await this.storage.get('isNewUser').then(val => {
            this.isNewUser.next(val);
            savedValue = val;
       });
       
       if (savedValue === null || savedValue === undefined || savedValue === false) {
            this.router.navigateByUrl('/welcome');
            
        } else { 
            this.isNewUser.next(false);
        }
        return this.isNewUser;
    }

    async canActivate(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
      ): Promise<boolean> {
          if (!this.isNewUser.getValue().valueOf()) {
            if (!this.isUserLoggedIn.getValue().valueOf()) {
                this.router.navigateByUrl('/login');
                return false;
            }
          } else {
            this.router.navigateByUrl('/welcome');
            return false;
          }
            
        return true;
      }

    // isPinCreated() {
    //   if ( this.commonService.getAppPin() !== undefined
    //       || this.commonService.getAppPin() !== null
    //       || this.commonService.getAppPin() !== '') {
    //     console.log('pin existed');
    //     this.isUserLoggedIn.next(true);
    //   } else {
    //     this.isUserLoggedIn.next(false);
    //   }
    // }
}
