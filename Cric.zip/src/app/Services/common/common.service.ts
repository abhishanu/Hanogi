import { BehaviorSubject } from 'rxjs';
import { async } from '@angular/core/testing';

import { GameDesc, TeamDesc } from './../../utility/commonUtil';

import { AuthGuardService } from './../auth/auth-gaurd.service';
import { Injectable } from '@angular/core';

import {Storage } from '@ionic/storage';

import { LoadingController, NavController } from '@ionic/angular';

import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { RequestService } from '../request/request.service';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  isPageLoaded: BehaviorSubject<Boolean> = new BehaviorSubject(false);
  showMatchName: Array<{'name', 'id'}> = [];
  private items: Array<{ title: string; note: string}> = [];
  private _userId: any = null;
  public get userId(): any {
    return this._userId;
  }
  public set userId(value: any) {
    this._userId = value;
  }
  Userlogin = {name: '', pwd: ''};
  gamesList: Array<any> = [];
  private _appPin: String;
  public get appPin(): String {
    return this._appPin;
  }
  public set appPin(value: String) {
    this._appPin = value;
  }
  private _teamNameList: Array<TeamDesc> = [
    { teamName: 'CSK', flag: 'cskFlag', id: 1 },
    { teamName: 'RCB', flag: 'rcbFlag', id: 2 },
    { teamName: 'DC', flag: 'dcFlag', id: 3 },
    { teamName: 'MI', flag: 'miFlag', id: 4 },
    { teamName: 'XIPU', flag: 'kxpFlag', id: 5 },
    { teamName: 'RR', flag: 'rrFlag', id: 6 },
    { teamName: 'KKR', flag: 'kkrFlag', id: 7 },
    { teamName: 'SRH', flag: 'srhFlag', id: 8 }
  ];

  private isPinFetched: Boolean = false;

  public getTeamNameList(): Array<TeamDesc> {
    return this._teamNameList;
  }

  public setTeamList(teamListNew: Array<TeamDesc>) {
    this._teamNameList = teamListNew;
  }

  constructor(private storage: Storage,
              private alertCtrl: AlertController,
              private loadingController: LoadingController,
              private auth: AuthGuardService,
              private router: Router,
              private req: RequestService
              ) {
                console.log('CommonService: const()');
                this.getAppPin();
              }

  public getAllGameList (): Array<any> {
    console.log('CommonService: getAllGameList()');
    if (this.gamesList.length === 0) {
      this.req.get('getAllGames').toPromise().then(res => {
        this.gamesList = res['responseMap'].All_Games;
        console.log('Games:' + this.gamesList.length);
      }).catch(err => {
        console.log('Error:' + err);
      });
    }
    return this.gamesList;
  }

  public addGameToList(game: GameDesc) {
    console.log('CommonService: addGameToList()');
    this.gamesList.push(game);
  }

   async isPinExists() {
    console.log('CommonService: isPinExists()');
    await this.getAppPin();
    if ( this.appPin !== undefined && this.appPin !== null) {
      console.log('pin existed');
      this.router.navigateByUrl('/check-pin');
    } else {

    }
  }

  public async getAppPin() {
    console.log('CommonService: getAppPin()');
    if (!this.isPinFetched) {
      if ( this.appPin === undefined || this.appPin === null) {
        await this.storage.get('pin').then(val => {
          this.appPin = val;
          this.isPinFetched = true;
          console.log('Pin:' + this.appPin);
        });
      }
    }
  }

  public savePin(pin: String) {
    console.log('CommonService: savePin()');
    if (this.userId !== null) {
      const requestBody = {'User_Id': this.userId, 'Pin': pin };
      this.req.post('savePin', requestBody).toPromise().then(res => {
        this.savePinToLocal(pin);
      }).catch(err => {
        this.router.navigateByUrl('/login');
      });
    } else {
      this.router.navigateByUrl('/login');
    }
  }

 async savePinToLocal(pin: any) {
  console.log('CommonService: savePinToLocal()');
    this.appPin = pin;
    await this.storage.set('pin', pin).then(() => {
      console.log('Pin saved locally.....');
       this.router.navigateByUrl('/check-pin');
    });
  }

  public clearAppPin() {
    console.log('CommonService: clearAppPin()');
    this.storage.remove('pin').then(err => {
      this.appPin = undefined;
      console.log('Pin removed....');
      if (this.auth.isUserLoggedIn.value === false) {
        this.logOut();
      }
    }).catch(() => {
      this.presentAlert('Log Out Failed.');
    });
  }

  public getPin() {
    console.log('CommonService: getPin()');
    return this.storage.get('pin').then(res => {
      if (res) {
        this.appPin = res;
      } else {
        this.appPin = undefined;
      }
    });
  }

  public logOut () {
    console.log('CommonService: logOut()');
    this.auth.isUserLoggedIn.next(false);
    this.removeUserIdFromLocal();
    this.router.navigateByUrl('/login');
  }

  async presentAlert(msg: string) {
    const alert = await this.alertCtrl.create({
      header: 'Alert',
      message: msg,
      buttons: ['OK']
    });

    await alert.present();
  }

  getMatches() {
    console.log('CommonService: getMatches()');
    if (this.showMatchName.length === 0) {
      this.req.upcomingMatches.forEach(element => {
        let team1: String = '';
        element['team-1'].split(' ')
                            .forEach(name => {
                              team1 += name.slice(0, 1);
                            });
        let team2: String = '';
        element['team-2'].split(' ')
                          .forEach(name => {
                            team2 += name.slice(0, 1);
                          });
        this.showMatchName.push({'name': team1.toUpperCase() + ' ' + 'Vs ' + team2.toUpperCase(), 'id': element['unique_id']});
      });
    }
  }

  async presentLoadingWithOptions(msg: string) {
    const loading = await this.loadingController.create({
      spinner: null,
      duration: 2000,
      message: msg,
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });
    return await loading.present();
  }

  async presentPageLoader(msg: string) {
    const loading = await this.loadingController.create({
      spinner: 'crescent',
      message: msg,
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });
    return await loading.present();
  }

  dismissLoader() {
    this.isPageLoaded.subscribe(data => {
      if (data.valueOf() === true ) {
        this.loadingController.dismiss();
      }
    });
  }

  public onBackPressed(page: any) {
    console.log('Back Button Pressed');
    this.presentPageLoader('Please wait...');
    this.router.navigateByUrl(page);
  }

  public logIn(user: any, pwd: any) {
    console.log('CommonService: logIn()');
    const request = {
      'name': user, 'pwd': pwd
    };
    return this.req.login(request);
  }

  public getPlayersList(id: any) {
    console.log('CommonService: getPlayersList()');
    return this.req.get('getPlayerList/' + id);
  }

  public saveUserIdToLocal(userid: any) {
    this.storage.set('userId', userid).then(res => {
      console.log('UserId saved to local');
      this.userId = res;
      // this.req.get('getUserName/' + this.userId).subscribe(data => {
      //   this.Userlogin.name = data.toString();
      // });
    });
  }

  public getUseridFromLocal() {
    this.storage.get('userId').then(res => {
      console.log('Fetched userId from local..');
      this.userId = res;
      this.getUserName(this.userId);
    });
  }

  public getUserName(userId: any) {
    this.req.get('getUserName/' + userId).subscribe(data => {
      this.Userlogin.name = data.toString();
    });
  }

  public removeUserIdFromLocal() {
    this.storage.remove('userId').then(res => {
      console.log('userId removed');

    });
  }
}
