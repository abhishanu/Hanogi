import { Injectable } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { GameModalPage } from '../game/game-modal/game-modal.page';
import { CommonService } from './common/common.service';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  constructor( public modalController: ModalController,
    public dataService: CommonService) { }

 
  page: any = GameModalPage;
  selectedTeam: any;

  async openModal(gameName: any, isOpenMatch: boolean, data: any) {
    const modal = await this.modalController.create({
      component: GameModalPage,
      componentProps: {
        "paramID": gameName,
        "title": gameName,
        "isOpenMatch": isOpenMatch,
        "data": data
      }
    });
 
    modal.onDidDismiss().then((dataReturned) => {
      if (dataReturned !== null) {
        this.selectedTeam = dataReturned;
        console.log('Modal Sent Data :', dataReturned);
      }
    });
 
    return await modal.present();
  }
}
