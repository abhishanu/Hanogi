import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from './Services/auth/auth-gaurd.service';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: './home/home.module#HomePageModule',
    canActivate: [AuthGuardService]
  },
  {
    path: 'list',
    loadChildren: './list/list.module#ListPageModule'
  },
  { path: 'profile',
    loadChildren: './profile/profile/profile.module#ProfilePageModule',
    canActivate: [AuthGuardService]
  },
  { path: 'login',
    loadChildren: './login/login.module#LoginPageModule'
  },
  { path: 'register',
    loadChildren: './register/register.module#RegisterPageModule'
  },
  {
    path: 'unlockWithPin',
    loadChildren: './login/unlock-with-pin/unlock-with-pin.module#UnlockWithPinPageModule'
  },
  {
    path: 'check-pin',
    loadChildren: './login/check-pin/check-pin.module#CheckPinPageModule'
  },
  {
    path: 'quiz',
    loadChildren: './game/quiz/quiz.module#QuizPageModule'
  },
  {
    path: 'forgetPwd',
    loadChildren: './login/forget-pwd/forget-pwd.module#ForgetPwdPageModule'
  },
  {
    path: 'teamRank',
    loadChildren: './game/team-rank/team-rank.module#TeamRankPageModule'
  },
  {
    path: 'games/:name',
    loadChildren: './game/games/games.module#GamesPageModule'
  },
  {
    path: 'choose-team/:team1name/:team2name/:gameId',
    loadChildren: './game/list/choose-team/choose-team.module#ChooseTeamPageModule'
  },
  {
    path: 'welcome',
    loadChildren: './login/welcome/welcome.module#WelcomePageModule'
  },
  {
    path: 'choose-team',
    redirectTo: 'choose-team/null',
    pathMatch: 'full'
  },
  {
    path: 'games',
    redirectTo: 'games/null',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'home'
  },  { path: 'game-modal', loadChildren: './game/game-modal/game-modal.module#GameModalPageModule' }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
