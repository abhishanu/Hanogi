import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GameModalPage } from './game-modal.page';

describe('GameModalPage', () => {
  let component: GameModalPage;
  let fixture: ComponentFixture<GameModalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GameModalPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GameModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
