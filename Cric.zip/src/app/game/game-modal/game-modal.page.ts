import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { CommonService } from 'src/app/Services/common/common.service';
import { RequestService } from 'src/app/Services/request/request.service';

@Component({
  selector: 'app-game-modal',
  templateUrl: './game-modal.page.html',
  styleUrls: ['./game-modal.page.scss'],
})
export class GameModalPage implements OnInit {

  modalTitle:string;
  modelId:number;
  pagedata: any;
  score : any = null;
 
  constructor(
    private modalController: ModalController,
    private navParams: NavParams,
    public dataService: CommonService
    //public reqService: RequestService,
  ) { }
  onClosedData: any;
  //isOpenMatch: boolean = false;
  showTeams: Boolean = false;
  chooseTeamScore: Boolean = false;
  gameId: any;
 
  ngOnInit() {
    console.table(this.navParams);
    this.modelId = this.navParams.data.title;
    this.gameId = this.navParams.data.gameId;
    
    this.pagedata = this.navParams.data.data;
    this.gameId = this.pagedata.uniqueId;
    console.log("data:" + this.pagedata);
    if (this.pagedata.team1 !== "null" && this.pagedata.team1 !== undefined) {
      this.showTeams = true;
    } else if(this.pagedata['score'] === "") {
      this.chooseTeamScore = true;
    }
  }
 
  async closeModal() {
    if (this.score !== null) {
      this.modalController.dismiss('Score' + this.score); 
    } else {
      //this.reqService.post('saveOpeningPair',)
      await this.modalController.dismiss('Closing model for:' + this.onClosedData); 
    }
  }

  selectTeam(selectedTeamName:any) {
    this.onClosedData = selectedTeamName;
    console.log('Choosen Team: ' + this.onClosedData);
  }
  
}
