import { UtilService } from './../../Services/util.service';
import { RequestService } from './../../Services/request/request.service';
import { CommonService } from 'src/app/Services/common/common.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-games',
  templateUrl: './games.page.html',
  styleUrls: ['./games.page.scss'],
})
export class GamesPage {
  teamsName:any;
  allGamesList: Array<any> = [];
  team1: any;
  team2: any;

  constructor(
                public _commonService: CommonService,
                public router: Router,
                public reqService: RequestService,
                private activatedRoute: ActivatedRoute,
                private utilService: UtilService 
             ) {
              // this.allGamesList = this._commonService.getAllGameList();
              this._commonService.getAllGameList();
             }
             
  
  ionViewWillEnter() {
    console.log('Games Page entered...');
    
    // if (this.allGamesList.length === 0) {
    //   this.allGamesList = this._commonService.getAllGameList();
    // }
    this.teamsName = this.activatedRoute.snapshot.paramMap.get('name');
    this.setteamName();
   }

   setteamName() {
    let teams = this.teamsName.split(' Vs ');
    this.team1 = teams[0];
    this.team2 = teams[1];
    console.log('Name:'+ teams);
   }
   
  openGame(gameIndex: any) {
    console.log('Open Game:' + this._commonService.gamesList[gameIndex].gameTitle);

    const gameName = this._commonService.gamesList[gameIndex].gameName;
    const uniqueId = this._commonService.gamesList[gameIndex].unique_id;
    let teamdata = {'team1': this.team1 , 'team2': this.team2 , 'uniqueId': uniqueId};
    switch (gameIndex) {
      case 0:
        this.router.navigateByUrl('teamRank');
        break;
      case 1:
        this.utilService.openModal(gameName, false, teamdata);
        break;
      case 2:
        this.router.navigateByUrl('choose-team/' + this.team1 + '/' + this.team2 + '/3');
        break;
      case 3:
        this.router.navigateByUrl('choose-team/' + this.team1 + '/' + this.team2 + '/4');
        break;
      case 4:
        this.utilService.openModal(gameName, false, teamdata);
        break;
      case 5:
        this.utilService.openModal(gameName, false, teamdata);
        break;
      case 6:
        this.router.navigateByUrl('choose-team/' + this.team1 + '/' + this.team2 + '/7');
        break;
      case 7:
        this.router.navigateByUrl('choose-team/' + this.team1 + '/' + this.team2 + '/8');
        break;
      case 8:
        this.utilService.openModal(gameName,false,{"score":""});
        break;
     
      default:
        this.router.navigateByUrl('choose-team/' +this.team1 +'/'+ this.team2 + '/'+ gameIndex);
        break;
    }
    
  }

  doRefresh(event) {
    console.log('Begin async operation');

    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);
  }
}
