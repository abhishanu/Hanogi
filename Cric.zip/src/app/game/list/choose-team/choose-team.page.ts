import { UtilService } from './../../../Services/util.service';
import { PlayerDesc } from './../../../utility/commonUtil';
import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/Services/request/request.service';
import { CommonService } from 'src/app/Services/common/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-choose-team',
  templateUrl: './choose-team.page.html',
  styleUrls: ['./choose-team.page.scss'],
})
export class ChooseTeamPage implements OnInit {
  playersListTeam1: Array<PlayerDesc> = [];
  playersListTeam2: Array<PlayerDesc> = [];

  playersList: Array<PlayerDesc> = [];

  currentPlayersList: Array<PlayerDesc> = [];

  wkList: Array<PlayerDesc> = [];
  batList: Array<PlayerDesc> = [];
  bowlList: Array<PlayerDesc> = [];
  allList: Array<PlayerDesc> = [];

  constructor(
    private req: RequestService,
    public _commonService: CommonService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public modalController: ModalController,
    public utilServices: UtilService
  ) {
    //this.getPlayers();
   }

  ngOnInit() {
  }

  ionViewWillEnter() {
   let team1name = this.activatedRoute.snapshot.paramMap.get('team1name');
   let team2name = this.activatedRoute.snapshot.paramMap.get('team2name');
   let gameId = this.activatedRoute.snapshot.paramMap.get('gameId');
  //  if (team1name === "null" || team2name === "undefined" || team2name === "null") {
  //    let teamName = this.utilServices.openModal('choose-team',true,);
  //    console.log('Choose-team:' + teamName);
     
  //  }
   console.log('Name:'+team1name+team2name);
   this.getPlayers(team1name,team2name);
  }

  getTeamPlayers(teamName: any) {
    return this.req.get('getPlayersOfTeam/' + teamName);
  }

  async getPlayers(team1: any, team2: any) {
    this.getTeamPlayers(team1).toPromise().then(data => {
      this.playersListTeam1 = data['responseMap'].PlayersMap;

      this.getTeamPlayers(team2).toPromise().then(data2 => {
        this.playersListTeam2 = data2['responseMap'].PlayersMap;

        this.playersList = this.playersListTeam1.concat(this.playersListTeam2);

        this.playersList.forEach(player => {
          if (player.playingRole==='WK') {
            this.currentPlayersList.push(player); 
          }
        });
      });
    });
  }

  selectPlayer(playerName: any) {
    console.log(playerName);
  }

  changePlayers(type:any) {
    console.log('Clicked:' + type);
    switch (type) {
      case 'WK':
        if (this.wkList.length === 0) {
          this.playersList.forEach(player => {
            if (player.playingRole==='WK') {
              this.wkList.push(player); 
            }
          });
        }
        this.currentPlayersList=this.wkList;
        break;
    
      case 'BAT':
      if (this.wkList.length === 0) {
        this.playersList.forEach(player => {
          if (player.playingRole ==='BAT') {
            this.batList.push(player); 
          }
        });
        console.log('Batsman:' + this.batList.length);
        
      }
        this.currentPlayersList=this.batList;
        break;
      case 'BOWL':
      if (this.wkList.length === 0) {
        this.playersList.forEach(player => {
          if (player.playingRole ==='BALL') {
            this.bowlList.push(player); 
          }
        });
        console.log('Batsman:' + this.bowlList.length);
      }
        this.currentPlayersList=this.bowlList;
        break;
      case 'ALL':
      if (this.wkList.length === 0) {
        this.playersList.forEach(player => {
          if (player.playingRole ==='ALL') {
            this.allList.push(player); 
          }
        });
      }
        this.currentPlayersList=this.allList;
        break;
     }
  }
}

