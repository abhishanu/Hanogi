import { Component } from '@angular/core';
import { CommonService } from '../Services/common/common.service';
import { RequestService } from '../Services/request/request.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  upcomingAllMatches: Array<any> = [];
  showMatchName: Array<String> = [];
  constructor() { }

  ionViewWillEnter() {
    console.log('HomePage Enter');
  }
}
