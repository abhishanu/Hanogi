import { RequestService } from './../Services/request/request.service';
import { Component, OnInit } from '@angular/core';
import { CommonService } from '../Services/common/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})
export class ListPage implements OnInit {
  private selectedMatch: any;
  public isItemLoaded: Boolean = false;
  public items: Array<{ title: string; note: string}> = [];

  constructor(
    public dataService: CommonService,
    private req: RequestService,
    private router: Router) {
      this.req.getAllUpcomingMatches();
  }

  ngOnInit() {}

  ionViewWillEnter() {
    console.log('ListPage Eneterd');
      if (this.upcomingAllMatches.length !== 0) {
        this.isItemLoaded = true;
      } else {
        this.loadMatches();
      }
  }

  loadMatches() {
    this.upcomingAllMatches = this.req.upcomingMatches;
    this.dataService.getMatches();
    if(this.upcomingAllMatches.length !== 0) {
      this.isItemLoaded = true;
    }
  }

  upcomingAllMatches: Array<any> = [];
  
  // getMatches(){
  //   this.upcomingAllMatches.forEach(element => {
  //     let team1:String='';
  //     element['team-1'].split(' ')
  //                         .forEach(name=> {
  //                           team1 += name.slice(0,1);
  //                         });
  //     let team2:String='';
  //     element['team-2'].split(' ')
  //                       .forEach(name=> {
  //                         team2 += name.slice(0,1);
  //                       })
  //     this.showMatchName.push({"name":team1.toUpperCase()+' ' + 'Vs ' + team2.toUpperCase(),"id":element['unique_id']});
  //   });
  //}

  openMatch(index:any) {
    this.router.navigateByUrl('/games/' + this.dataService.showMatchName[index].name);
  }

}
