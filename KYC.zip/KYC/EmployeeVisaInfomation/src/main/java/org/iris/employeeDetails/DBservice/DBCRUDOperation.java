package org.iris.employeeDetails.DBservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.iris.employeeDetails.bean.RegistrationBean;
import org.iris.employeeDetails.bean.VisaInfomation;


import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class DBCRUDOperation {
	Connection conn=null;
	Statement stmt=null;
	PreparedStatement prStmt=null;
	
	public void insertRecord(VisaInfomation visa, SessionService sessionService){
		conn= DBConnection.getDBInstance().getDBConnection();
		
		try {
			stmt=conn.createStatement();
			String sql= getInsertQuery(visa);
			stmt.executeUpdate(sql);
			
		} catch (MySQLIntegrityConstraintViolationException e) {
			 VisaService visaService = new VisaService();
			 visaService.updateRecord(visa,sessionService);
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public VisaInfomation getRecord(int id, String countryToVisit){
		VisaInfomation visa = new VisaInfomation();
		 visa.setId(id);
		conn= DBConnection.getDBInstance().getDBConnection();
		// our SQL SELECT query. 
	      // if you only need a few columns, specify them by name instead of using "*"
	     
			String query= getRetrivalQuery(id,countryToVisit);
			 Statement st = null;
			try {
				st = conn.createStatement();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
   		  ResultSet rs = null;
		try {
			rs = st.executeQuery(query);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      
	      // iterate through the java resultset
	      try {
			while (rs.next())
			  {
			    
				 
				  try {
					 
					visa.setTravelerName(rs.getString("travelerName"));
					visa.setCountryToVisit(rs.getString("countryToVisit"));
					visa.setClientName(rs.getString("clientName"));
					visa.setClientAddress(rs.getString("clientAddress"));
					visa.setClientsContactNo(rs.getString("clientsContactNo"));
					visa.setClientContactPersonName(rs.getString("clientContactPersonName"));
					visa.setProjectDetails(rs.getString("projectDetails"));
					visa.setProjectType(rs.getString("projectType"));
					visa.setProjectType(rs.getString("projectType"));
				/*	visa.setTravelDates(rs.getString("travelDates"));*/
					visa.setToDate(rs.getDate("toDate"));
					visa.setFromDate(rs.getDate("fromDate"));
					visa.setBdm(rs.getString("bdm"));
					 visa.setPreSales(rs.getString("preSales"));
					visa.setPmo(rs.getString("pmo"));
					visa.setTravelBillable(rs.getString("travelBillable"));
					visa.setIsBillable(rs.getString("isBillable"));
					visa.setAirfare(rs.getString("airfare"));
					visa.setHotel(rs.getString("hotel"));
					visa.setCar(rs.getString("car"));
					visa.setMeals(rs.getString("meals"));
					visa.setOther(rs.getString("other"));
					visa.setContactNumber(rs.getString("contactNumber"));
					visa.setMealPreferences(rs.getString("mealpreferences"));
					visa.setSeatPreferences(rs.getString("seatPreferences"));
					visa.setAnyOthers(rs.getString("anyOthers"));
					
					
					//visa.setCountryToVisit(rs.getString("countryToVisit"));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      
	      return visa;
	}

	public void updateRecord(VisaInfomation visa){
		String sql = getUpdateQuery(visa);
		conn= DBConnection.getDBInstance().getDBConnection();
		try {
			PreparedStatement prStmt= conn.prepareStatement(sql);
			prStmt.setString(1, visa.getTravelerName());
			prStmt.setString(2, visa.getCountryToVisit());
			
			prStmt.setString(3, visa.getClientName());
			prStmt.setString(4, visa.getClientAddress());
			prStmt.setString(5, visa.getClientsContactNo());
			prStmt.setString(6, visa.getClientContactPersonName());
			prStmt.setString(7, visa.getProjectDetails());
			prStmt.setString(8, visa.getProjectType());
			prStmt.setDate(9, visa.getToDate());
			prStmt.setDate(10, visa.getFromDate());
			/*prStmt.setString(9, visa.getTravelDates());*/
			prStmt.setString(11, visa.getBdm());
			prStmt.setString(12, visa.getPreSales());
			prStmt.setString(13, visa.getPmo());
			prStmt.setString(14, visa.getTravelBillable());
			prStmt.setString(15, visa.getIsBillable());
			prStmt.setString(16, visa.getAirfare());
			prStmt.setString(17, visa.getHotel());
			prStmt.setString(18, visa.getCar());
			prStmt.setString(19, visa.getMeals());
			prStmt.setString(20, visa.getOther());
			prStmt.setString(21, visa.getContactNumber());
			prStmt.setString(22, visa.getMealPreferences());
			prStmt.setString(23, visa.getSeatPreferences());
			prStmt.setString(24, visa.getAnyOthers());
			
			prStmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public boolean deleteRecord(){
		return false;
		
	}
	/*private Statement getStatment(){
		try {
			conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stmt;
		
	}*/
	
	private String getUpdateQuery(VisaInfomation visa){
		
		String sql     = "UPDATE visatable SET travelerName = ?, "
	               + " countryToVisit = ?, "
	               +" clientName = ?, "
	               +" clientAddress = ?, "
	               +" clientsContactNo = ?, "
	               +" clientContactPersonName = ?, "
	               +" projectDetails = ?, "
	               +" projectType = ?, "
	               +" toDate = ?, "
	               +" fromDate = ?, "
	               +" bdm = ?, "
	               +" preSales = ?, "
	               +" pmo = ?, "
	               +" travelBillable = ?, "
	               +" isBillable = ?, "
	               +" airfare = ?, "
	               +" hotel = ?, "
	               +" car = ?, "
	               +" meals = ?, "
	               +" other = ?, "
	               +" contactNumber = ?, "
	               +" mealPreferences = ?, "
	               +" seatPreferences = ?, "
	               +" anyOthers = ? "
	               
	               + " WHERE id = "+visa.getId()+" AND countryToVisit='"+visa.getCountryToVisit()+"'";
		
		
		return sql;
		
	}
	
	private static String getInsertQuery(VisaInfomation visa){
		String sql = "INSERT INTO visatable " +
	            "VALUES ("
	            + visa.getId()
	            + ","+"'"
	            + visa.getTravelerName()           
	            + "',"+"'"
	            + visa.getCountryToVisit()
	            + "',"+"'"
	            + visa.getClientName()
	            + "',"+"'"
	            + visa.getClientAddress()
	            + "',"+"'"
	            + visa.getClientsContactNo()
	            + "',"+"'"
	            + visa.getClientContactPersonName()
	            + "',"+"'"
	            + visa.getProjectDetails()
	            + "',"+"'"
	            + visa.getProjectType()
	            + "',"+"'"
	            + visa.getToDate()
	            + "',"+"'"
	            + visa.getFromDate()
	            + "',"+"'"
	            + visa.getBdm()
	            + "',"+"'"
	            + visa.getPreSales()
	            + "',"+"'"
	            + visa.getPmo()
	            + "',"+"'"
	            + visa.getTravelBillable()
	            + "',"+"'"
	            + visa.getIsBillable()
	            + "',"+"'"
	            + visa.getAirfare()
	            + "',"+"'"
	            + visa.getHotel()
	            + "',"+"'"
	            + visa.getCar()
	            + "',"+"'"
	            + visa.getMeals()
	            + "',"+"'"
	            + visa.getOther()
	            + "',"+"'"
	            + visa.getContactNumber()
	            + "',"+"'"
	            + visa.getMealPreferences()
	            + "',"+"'"
	            + visa.getSeatPreferences()
	            +"'"+ ","
	            + "'"+visa.getAnyOthers() 
	            + "')";
		return sql;
		
	}
	
	private static String getRetrivalQuery(int id, String countryToVisit){
		String sql =   "SELECT * FROM visatable WHERE id = "+id+" AND countryToVisit='"+countryToVisit+"';";
	
		return sql;
		
	}
}
