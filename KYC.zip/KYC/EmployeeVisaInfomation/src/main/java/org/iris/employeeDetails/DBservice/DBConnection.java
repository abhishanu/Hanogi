package org.iris.employeeDetails.DBservice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/*
 * This is Singletone class to established the DB connection
 */
public class DBConnection {
	 Connection conn = null;
	 Statement stmt = null;
	 String DB_URL="jdbc:mysql://localhost/visa_db"; 
	 String USER="root";
	 String PASS="password@1";
	 String DRIVER="com.mysql.jdbc.Driver";	
	/*
	 * read the DB connection parameter from properties file
	 */
	//static Properties properties = new Properties();
	

		
	
	private static final DBConnection dbobject = new DBConnection();
	
	private DBConnection(){
		//InputStream inputStream= getClass().getClassLoader().getResourceAsStream("DB.properties");
		/*File file = new File("DB.properties");
		
		
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Properties properties = new Properties();
		try {
			properties.load(fileInput);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		
		
		
	}
		
	
	
	public static DBConnection getDBInstance()
	{
		return dbobject;
	
		
	}
	public Connection getDBConnection(){
		if(conn==null){
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		//properties.getProperty(key)
		return conn;
		
	}

	public void closeConnection(){
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
