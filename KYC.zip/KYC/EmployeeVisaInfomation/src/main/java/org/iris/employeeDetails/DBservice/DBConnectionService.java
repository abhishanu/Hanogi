package org.iris.employeeDetails.DBservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionService {

	Connection conn=null;
	Statement stmt=null;
	PreparedStatement prStmt=null;
	public Connection getConn() {
		return conn;
	}
	public void setConn(Connection conn) {
		this.conn = conn;
	}
	public Statement getStmt() {
		return stmt;
	}
	public void setStmt(Statement stmt) {
		this.stmt = stmt;
	}
	public PreparedStatement getPrStmt() {
		return prStmt;
	}
	public void setPrStmt(PreparedStatement prStmt) {
		this.prStmt = prStmt;
	}
	
	
	public Connection createConnection(){
		return  DBConnection.getDBInstance().getDBConnection();
		
	}
}
