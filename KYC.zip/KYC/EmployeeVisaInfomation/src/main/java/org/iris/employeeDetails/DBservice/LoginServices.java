package org.iris.employeeDetails.DBservice;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.iris.employeeDetails.bean.LoginBean;
import org.iris.employeeDetails.bean.RegistrationBean;

public class LoginServices {

	public RegistrationBean login(LoginBean login) {
		return getRecord(login.getUser());
	}

	private static RegistrationBean getRecord(String user) {
		RegistrationBean record = new RegistrationBean();
		Connection con = getConnection();
		ResultSet rs = null;
		int counter = 0;
		try {
			Statement stmt = con.createStatement();
			String query = loginQuery(user);
			rs = stmt.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			while (rs.next()) {
				counter = 1;

				try {

					record.setEmail(rs.getString("email"));
					record.setId(rs.getInt("id"));
					record.setName(rs.getString("name"));
					record.setPassword(rs.getString("password"));
					// visa.setCountryToVisit(rs.getString("countryToVisit"));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (counter == 0) {
			return null;
		}
		return record;
	}

	private static Connection getConnection() {
		return DBConnection.getDBInstance().getDBConnection();

	}

	private static String loginQuery(String user) {
		String query = "SELECT * FROM registrationtable WHERE email = '" + user + "';";

		return query;

	}

}
