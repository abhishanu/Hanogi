package org.iris.employeeDetails.DBservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.RandomStringUtils;
import org.iris.employeeDetails.bean.LoginBean;
import org.iris.employeeDetails.bean.LoginResponse;
import org.iris.employeeDetails.bean.RegistrationBean;



public class PasswordService {
	
/*
 * Reset Password in case of forget/reset
 */
public LoginResponse resetPassword(String email,String oldPassword, String NewPassword){
	Connection conn=null; 
	LoginResponse loginBean = new LoginResponse();
	if(checkUser(email,oldPassword)){
		String sql = updateQuery(email);
		conn= DBConnection.getDBInstance().getDBConnection();
			try {
				PreparedStatement prStmt= conn.prepareStatement(sql);
				prStmt.setString(1,NewPassword);
				prStmt.executeUpdate();
				loginBean.setResetSuccess(true);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}else{
		
		loginBean.setMessage("Either User does not exits or wrong password!");
		
		loginBean.setResetSuccess(false);
		
	}
	return loginBean;
	
}
/*
 * system generated password
 */
public String generatePassword(){
	String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
	String pwd = RandomStringUtils.random( 15, characters );
	//System.out.println( pwd );
return pwd;
	
}
private static String updateQuery(String email){
	
	String query="update registrationTable set password = ? where email ='"+email+"';";
	return query;
	}
private static boolean checkUser(String email,String oldPassword){
	
	LoginServices loginService = new LoginServices();
	LoginBean loginBean = new LoginBean();
	loginBean.setUser(email);
	loginBean.setPassword(oldPassword);
	if(loginService.login(loginBean)==null)
		return false;
	return true;
	
}

public String getUserName(String email){
	Connection conn=null; 
	ResultSet rs =null;
	String userName=null;
	/*
	 * retrieve query 
	 */
	String query =getRetriveQuery(email);
	conn= DBConnection.getDBInstance().getDBConnection();
	try {
		rs= conn.createStatement().executeQuery(query);
		if(rs.next()){
		userName = rs.getString("name");
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return userName;
	
}
private static String getRetriveQuery(String email){
	
	
	String query= "select name from registrationTable where email='"+email+"';";
	return query;
}
}