package org.iris.employeeDetails.DBservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.iris.employeeDetails.bean.RegisterBean;
import org.iris.employeeDetails.bean.RegistrationBean;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class RegistrationServices {

	Connection conn = null;
	Statement stmt = null;
	PreparedStatement prStmt = null;

	public RegisterBean register(RegistrationBean user) {
		RegisterBean registerBean = new RegisterBean();
		String query = null;
		// TODO Auto-generated method stub
		conn = DBConnection.getDBInstance().getDBConnection();

		try {
			stmt = conn.createStatement();
			if (!isRecordFound(stmt, user)) {
				query = registerQuery(user);
				stmt.executeUpdate(query);
				registerBean.setMessage("Registartion successful!");
				registerBean.setrFound(false);
			} else {
				registerBean.setMessage("You are already registered User!");
				registerBean.setrFound(true);
			}

		} catch (MySQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return registerBean;

	}

	private static String registerQuery(RegistrationBean user) {
		String sql = "INSERT INTO RegistrationTable " + "VALUES (" + user.getId() + "," + "'" + user.getName() + "',"
				+ "'" + user.getEmail() + "'," + "'" + user.getPassword() + "')";
		return sql;

	}

	private static String selectQuery(RegistrationBean user) {

		String query = "select * from RegistrationTable where email='" + user.getEmail() + "';";
		return query;

	}

	private static boolean isRecordFound(Statement stmt, RegistrationBean user) throws SQLException {
		ResultSet rs = null;
		String query = selectQuery(user);
		rs = stmt.executeQuery(query);
		if (rs.next()) {
			return true;
		}
		return false;

	}
}
