package org.iris.employeeDetails.DBservice;

import java.util.Properties;  
import javax.mail.*;  
import javax.mail.internet.*;  
  
public  class SendEmail
{
  public void getEmail(String to,String from, String userName,String password,Properties props,String subject,String messageBody) throws MessagingException
 {
     MimeBodyPart mimeBodyPart=new MimeBodyPart();
     mimeBodyPart.setContent(messageBody,"text/html");
     MimeMultipart multipart=new MimeMultipart();
     multipart.addBodyPart(mimeBodyPart);
     Session session=Session.getInstance(props,new Authenticator()
       {
         protected PasswordAuthentication getPasswordAuthentication()
          {
             return new PasswordAuthentication("madan.lodhi@irissoftware.com","iris@12345");
          }
      });
        try{
             MimeMessage message=new MimeMessage(session);
             message.setFrom(new InternetAddress(from));
             message.setContent(multipart);
             message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
            message.setSubject("Have You got Mail!");
            message.setText(messageBody,"UTF-8","html");
            Transport.send(message);
          }
          catch(MessagingException ex){
        	  System.out.println(ex);}
          }
     public static void main(String arg[]) throws MessagingException{
        SendEmail sendEmail=new SendEmail();
          String to = "madan.lodhi@irissoftware.com";      
          String from = "madan.lodhi@irissoftware.com";
          final String username = "madan.lodhi@irissoftware.com";
          final String password = "iris@12345";
           String subject="Html Template";

         String body = "<i> Hi All,!</i><br>";
         body += "<b>Your Email is working!</b><br>";
        // body += "<font color=red>Thank </font>";
         body += "<a href ='http://localhost:8080/EmployeeVisaInfomation/#/'>Visa Portal </a>";
         String host = "mailiris.irissoftware.com";
         Properties props = new Properties();
         props.put("mail.smtp.auth", "true");
       //  props.put("mail.smtp.starttls.enable", "true");
         props.put("mail.smtp.host", host);
         props.put("mail.smtp.port", "587");
         sendEmail.getEmail(to,from,username,password,props,subject,body);
    }
 }