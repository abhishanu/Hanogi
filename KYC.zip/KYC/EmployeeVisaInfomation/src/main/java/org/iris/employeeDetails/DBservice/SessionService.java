package org.iris.employeeDetails.DBservice;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.UUID;



public class SessionService {

	private static  Connection conn=null;
	private static Statement stmt = null;
	

	public SessionService(){
		conn =DBConnection.getDBInstance().getDBConnection();
		try {
			stmt=conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/*
	 * generate random token
	 * 
	 */

	public static  String generateToken(){
		
		return UUID.randomUUID().toString();
	}

	/*public static void main(String[] args) {
		
		SessionService SService = new SessionService();
		
		// generate token
		 
		String token = generateToken();
		
		//  save Session
		 
		SService.saveSession(token,"madan");
		
		
		// * check for validity for session
		 
		
		//SService.isSessionAlive(token);
		
		
		// * update session for subsequent request
		 
		String  newtoken = generateToken();
		SService.updateSession(newtoken,token);
		
		
	}*/


	public boolean saveSession(String token ,String user){
       boolean isPersist=false;
		/*
		 * 1: get DB connection
		 * 2: get Query String 
		 * 3: insert record 
		 */
		String query= insertQuery(token, user);
		try {
			stmt.executeUpdate(query);
			isPersist=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return isPersist;

	}
	public static void deleteSession(String token){
		
		String query = deleteQuery(token);
		try {
			stmt.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public String getUser(String token){
		
		/*
		 * check the record w.r.t. token 
		 */
		String query = selectQuery(token);
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  ResultSet rs = null;
	try {
		rs = st.executeQuery(query);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
      
      // iterate through the java resultset
      try {
		while(rs.next()){
			
			return rs.getString("user");
		  }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      return null;
	}
	public boolean isSessionAlive(String token){
		/*
		 * check the record w.r.t. token 
		 */
		String query = selectQuery(token);
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  ResultSet rs = null;
	try {
		rs = st.executeQuery(query);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
      
      // iterate through the java resultset
      try {
		while (rs.next())
		  {
		    
			 
			  try {
				 
				
				long startTime = (long)rs.getLong("startTime");
				long CurrentTime =System.currentTimeMillis();
				
				if((CurrentTime-startTime)<300000){
					return true;
				}else{
					deleteSession(token);
					return false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		  }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return false;
	}

	public String updateSession(String newToken, String oldToken){

		/*
		 * get DB connection
		 * get the update Query 
		 * update table 
		 */
		String sql =updateQuery(newToken,  oldToken);
		try {
			//PreparedStatement prStmt= conn.prepareStatement(sql);
			stmt=conn.createStatement();
			
			//prStmt.setString(1, token);
			//prStmt.setString(2, token);
			stmt.execute(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newToken; 
	}

	private static String updateQuery(String  newToken, String oldToken){

		String query  = "UPDATE sessionTable SET token = '"+newToken+"' WHERE token = '"+oldToken+"'";
		
		return query;
	}
	private static String insertQuery(String token,String user){

		String query = "insert into sessiontable VALUES ('"+
		user+"','"+token+"',"+System.currentTimeMillis()+");";
		return query;
	}
	
	private static String selectQuery(String token){
		
		String query ="select *from sessionTable where token='"+token+"';";
		return query;
	}
	
	private static String deleteQuery(String token){
		
		String query ="delete from sessiontable where token='"+token+"';";
		return query;
	}

}
