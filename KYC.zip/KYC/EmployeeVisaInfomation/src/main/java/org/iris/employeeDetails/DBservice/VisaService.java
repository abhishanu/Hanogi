package org.iris.employeeDetails.DBservice;

import javax.mail.MessagingException;

import org.iris.employeeDetails.Mailservice.MailService;
import org.iris.employeeDetails.bean.VisaInfomation;

/*
 * It is just a helper class which should be replaced by database implementation.
 * It is not very well written class, it is just used for demonstration.
 */
public class VisaService {
	DBCRUDOperation db = new DBCRUDOperation();
	 
	MailService mailService = new MailService();
	String toMail;
	String text="";
	public static final String fromMail="fsadminsupport@irissoftware.com";
	public VisaService() {
		
	}

	public VisaInfomation getVisa(int id,String countryToVisit)
	{
		
		return db.getRecord(id,countryToVisit);
	}
	public void addRecord(VisaInfomation visa, SessionService sessionService)
	{
		
		db.insertRecord(visa,sessionService);
		/*
		 * send mail to HR/admin for successful submission 
		 */
		//String text1="Madan [1692] has submiited the record for US location";
		String subject = "Visa Information Update";
		String body = " Hi All,<br><br>";
        body += "The User ";
        body+=visa.getTravelerName();
        body+=" [Employee ID-";
        body+= visa.getId();
        body+="] has updated/added his visa information for ";
        body+=visa.getCountryToVisit();
        body+=" &nbsplocation.<br><br>";
        body+="<table><tr><td width='60%'><h2 style='border-bottom:1px solid'>Travel Details</h2><table style='font-size:12px;font-family:arial' cellpadding='5' cellspacing='2' border='1'>";
        body+="<tr><td><b>Traveler Name:</b></td><td>"+visa.getTravelerName()+"</td><td><b>Country to Visit:</b></td><td>"+visa.getCountryToVisit()+"</td></tr>";
        body+="<tr><td><b>Client Name:</b></td><td>"+visa.getClientName()+"</td><td><b>Client address:</b></td><td>"+visa.getClientAddress()+"</td></tr>";
        body+="<tr><td><b>Client's contact no:</b></td><td>"+visa.getClientsContactNo()+"</td><td><b>Contact Person:</b></td><td>"+visa.getClientContactPersonName()+"</td></tr>";
        body+="<tr><td><b>Project Details:</b></td><td>"+visa.getProjectDetails()+"</td><td><b>Project Type:</b></td><td>"+visa.getProjectType()+"</td></tr>";
        body+="<tr><td><b>Travel Dates:</b></td><td><b>From:</b> "+visa.getFromDate()+" <b>TO:</b> "+visa.getToDate()+"&nbsp;&nbsp;&nbsp;&nbsp;</td><td><b>BDM:</b></td><td>"+visa.getBdm()+"</td></tr>";
        body+="<tr><td><b>Pre Sales:</b></td><td>"+visa.getPreSales()+"</td><td><b>PMO:</b></td><td>"+visa.getPmo()+"</td></tr>";
        body+="<tr><td><b>Travel Billable:</b></td><td>"+visa.getTravelBillable()+"</td><td><b>If billable, provide comment:</b></td><td>"+visa.getIsBillable()+"</td></tr>";
        body+="<tr><td><b>Airfare:</b></td><td>"+visa.getAirfare()+"</td><td><b>Hotel:</b></td><td>"+visa.getHotel()+"</td></tr>";
        body+="<tr><td><b>Car:</b></td><td>"+visa.getCar()+"</td><td><b>Meals:</b></td><td>"+visa.getMeals()+"</td></tr>";
        body+="<tr><td><b>Other:</b></td><td colspan='3'>"+visa.getOther()+"</td></tr></table>";
        body+="</td><td width='10%'>&nbsp;</td><td width='30%' style='vertical-align: top;'><h2 style='border-bottom:1px solid'>Personal Details</h2><table style='font-size:12px;font-family:arial' cellpadding='5' cellspacing='2' border='1'>"
        		+ "<tr><td><b>Contact Number :</b></td><td>"+visa.getContactNumber()+"</td></tr>"
        		+ "<tr><td><b>Meal preferences :</b></td><td>"+visa.getMealPreferences()+"</td></tr>"
        		+ "<tr><td><b>Seat preferences :</b></td><td>"+visa.getSeatPreferences()+"</td></tr>"
        		+ "<tr><td><b>Any others :</b></td><td>"+visa.getAnyOthers()+"</td></tr></table>";
        body += "</td></tr></table>";
        body +="<br/><div>Please login <a  href ='http://iris-csg-750:8080/EmployeeVisaInfomation/#/'>Visa Portal </a> to view the Visa information </div><br>";
        body+="Thanks,<br> Admin Support";
        
       // body += "<font color=red>Thank </font>";
        
        
		try {
			mailService.sendMail(sessionService.getUser(visa.getSessionbean().getSessionId()), fromMail, body,subject);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void updateRecord(VisaInfomation visa, SessionService sessionService)
	{
		db.updateRecord(visa);
		/*
		 * send mail to HR/Admin for successful update  
		 */
		/*toMail=sessionService.getUser(visa.getSessionbean().getSessionId());
		text="record updated succesfully!!";
		mailService.sendMail(toMail, fromMail,text);*/
	}

	public String getToMail() {
		return toMail;
	}

	public void setToMail(String toMail) {
		this.toMail = toMail;
	}
	
}
