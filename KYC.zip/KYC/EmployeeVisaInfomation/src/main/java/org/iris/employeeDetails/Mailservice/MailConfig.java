package org.iris.employeeDetails.Mailservice;

public class MailConfig {

}
