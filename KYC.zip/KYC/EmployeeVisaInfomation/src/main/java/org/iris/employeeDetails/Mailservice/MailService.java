package org.iris.employeeDetails.Mailservice;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MailService {
	
	/*
	 * configure SMTP server 
	 */
	private static Properties ConfigMail(){
		final String username = "fsadminsupport@irissoftware.com";//"madan.lodhi@irissoftware.com";
	     final String password = "password@33";

	     Properties props = new Properties();
	     props.put("mail.smtp.auth", "true");
	    // props.put("mail.smtp.starttls.enable", "true");
	   //  props.put("mail.smtp.host", "outlook.office365.com");
	     props.put("mail.smtp.host", "mailiris.irissoftware.com");
	     
	     props.put("mail.smtp.port", "587");
	     props.put("userName",username);
	     props.put("password",password);

		return props;
		
	}
	
	/*
	 * send mail to HR/admin 
	 */
	
	public void sendMail(String toMail, String fromMail,String messageBody, String Subject) throws MessagingException{
		
		final Properties props =ConfigMail();

		MimeBodyPart mimeBodyPart=new MimeBodyPart();

		 mimeBodyPart.setContent(messageBody,"text/html");

		 MimeMultipart multipart=new MimeMultipart();

		 multipart.addBodyPart(mimeBodyPart);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(props.getProperty("userName"), props.getProperty("password"));
			}
		});

	     try {

	    	 MimeMessage message=new MimeMessage(session);
	        
	         message.setFrom(new InternetAddress(fromMail));
	         message.setContent(multipart);
	         message.setRecipients(Message.RecipientType.TO,
	             InternetAddress.parse(toMail));
	         message.setRecipients(Message.RecipientType.CC,
		             InternetAddress.parse(toMail));
	         message.setSubject(Subject);
	         message.setText(messageBody,"UTF-8","html");

	         Transport.send(message);

	        // System.out.println("Done");

	     } catch (MessagingException e) {
	         throw new RuntimeException(e);
	     }
	 }
		
		

	

}
