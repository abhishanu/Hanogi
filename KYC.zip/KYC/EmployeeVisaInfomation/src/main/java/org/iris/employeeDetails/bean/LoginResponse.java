package org.iris.employeeDetails.bean;

public class LoginResponse {

	String email;
	int id;
	String message;
	boolean isAdmin;
	boolean wrongpassword = false;
	boolean rFound = true;
	boolean resetSuccess = false;
	SessionBean sessionbean;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public boolean isWrongpassword() {
		return wrongpassword;
	}

	public void setWrongpassword(boolean wrongpassword) {
		this.wrongpassword = wrongpassword;
	}

	public boolean isrFound() {
		return rFound;
	}

	public void setrFound(boolean rFound) {
		this.rFound = rFound;
	}

	public boolean isResetSuccess() {
		return resetSuccess;
	}

	public void setResetSuccess(boolean resetSuccess) {
		this.resetSuccess = resetSuccess;
	}

	public SessionBean getSessionbean() {
		return sessionbean;
	}

	public void setSessionbean(SessionBean sessionbean) {
		this.sessionbean = sessionbean;
	}
}
