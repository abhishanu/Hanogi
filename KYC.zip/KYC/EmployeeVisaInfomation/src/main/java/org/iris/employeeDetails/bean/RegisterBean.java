package org.iris.employeeDetails.bean;

public class RegisterBean {

	String message = "";
	boolean rFound = false;

	public String getMessage() {
		return message;
	}

	public void setMessage(String messag) {
		this.message = messag;
	}

	public boolean isrFound() {
		return rFound;
	}

	public void setrFound(boolean rFound) {
		this.rFound = rFound;
	}

}
