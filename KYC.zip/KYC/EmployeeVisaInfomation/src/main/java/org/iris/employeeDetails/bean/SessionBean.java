package org.iris.employeeDetails.bean;

public class SessionBean {

	String sessionId;

	String user;

	boolean validSession = false;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public boolean isValidSession() {
		return validSession;
	}

	public void setValidSession(boolean validSession) {
		this.validSession = validSession;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
}
