package org.iris.employeeDetails.bean;

import java.sql.Date;

public class VisaInfomation {
	/*
	 * VISA Related Information
	 */
	int id;
	String travelerName = "";
	String countryToVisit;
	String clientName = "";
	String clientAddress = "";
	String clientsContactNo = "";
	String clientContactPersonName = "";
	String projectDetails = "";
	String projectType = "";
	Date fromDate;
	Date toDate;
	String bdm = "";
	String preSales = "";
	String pmo = "";
	String travelBillable = "";
	String isBillable = "";
	String airfare = "";
	String hotel = "";
	String car = "";
	String meals = "";
	String other = "";

	// Employee person Details

	String contactNumber = "";
	String mealPreferences = "";
	String seatPreferences = "";
	String anyOthers = "";
	SessionBean sessionbean;

	public String getTravelerName() {
		return travelerName;
	}

	public void setTravelerName(String travelerName) {
		this.travelerName = travelerName;
	}

	public String getCountryToVisit() {
		return countryToVisit;
	}

	public void setCountryToVisit(String countryToVisit) {
		this.countryToVisit = countryToVisit;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	public String getClientsContactNo() {
		return clientsContactNo;
	}

	public void setClientsContactNo(String clientsContactNo) {
		this.clientsContactNo = clientsContactNo;
	}

	public String getClientContactPersonName() {
		return clientContactPersonName;
	}

	public void setClientContactPersonName(String clientContactPersonName) {
		this.clientContactPersonName = clientContactPersonName;
	}

	public String getProjectDetails() {
		return projectDetails;
	}

	public void setProjectDetails(String projectDetails) {
		this.projectDetails = projectDetails;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getBdm() {
		return bdm;
	}

	public void setBdm(String bdm) {
		this.bdm = bdm;
	}

	public String getPreSales() {
		return preSales;
	}

	public void setPreSales(String preSales) {
		this.preSales = preSales;
	}

	public String getPmo() {
		return pmo;
	}

	public void setPmo(String pmo) {
		this.pmo = pmo;
	}

	public String getTravelBillable() {
		return travelBillable;
	}

	public void setTravelBillable(String travelBillable) {
		this.travelBillable = travelBillable;
	}

	public String getIsBillable() {
		return isBillable;
	}

	public void setIsBillable(String isBillable) {
		this.isBillable = isBillable;
	}

	public String getAirfare() {
		return airfare;
	}

	public void setAirfare(String airfare) {
		this.airfare = airfare;
	}

	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}

	public String getMeals() {
		return meals;
	}

	public void setMeals(String meals) {
		this.meals = meals;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getAnyOthers() {
		return anyOthers;
	}

	public void setAnyOthers(String anyOthers) {
		this.anyOthers = anyOthers;
	}

	/*
	 * public VisaInfomation(String travelerName, String CountryToVisit, String
	 * clientName, String clientAddress, String clientsContactNo, String
	 * clientContactPersonName, String projectDetails, String projectType,
	 * String travelDates, String bdm, String preSales, String pmo, String
	 * travelBillable, String isBillable, String airfare, String hotel, String
	 * car, String meals, String other,
	 * 
	 * Employee person Details
	 * 
	 * 
	 * String contactNumber, String mealPreferences, String seatPreferences,
	 * String anyOthers){ super(); this.travelerName =travelerName;
	 * this.countryToVisit=countryToVisit; this.clientName =clientName;
	 * this.clientAddress=clientAddress; this.clientsContactNo=clientsContactNo;
	 * this.clientContactPersonName=clientContactPersonName;
	 * this.projectDetails=projectDetails; this.projectType=projectType;
	 * this.travelDates=travelDates; this.bdm=bdm; this.preSales=preSales;
	 * this.pmo=pmo; this.travelBillable=travelBillable;
	 * this.isBillable=isBillable; this.airfare=airfare; this.hotel=hotel;
	 * this.car=car; this.meals=meals; this.meals=meals;
	 * 
	 * Employee person Details
	 * 
	 * 
	 * this.contactNumber=contactNumber; this. mealPreferences=seatPreferences;
	 * this.seatPreferences=seatPreferences; this.anyOthers=anyOthers; }
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getMealPreferences() {
		return mealPreferences;
	}

	public void setMealPreferences(String mealPreferences) {
		this.mealPreferences = mealPreferences;
	}

	public String getSeatPreferences() {
		return seatPreferences;
	}

	public void setSeatPreferences(String seatPreferences) {
		this.seatPreferences = seatPreferences;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public SessionBean getSessionbean() {
		return sessionbean;
	}

	public void setSessionbean(SessionBean sessionbean) {
		this.sessionbean = sessionbean;
	}

}
