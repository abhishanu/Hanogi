package org.iris.employeeDetails.controller;

import javax.mail.MessagingException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.PasswordService;
import org.iris.employeeDetails.Mailservice.MailService;
import org.iris.employeeDetails.bean.GeneratePasswordBean;
import org.iris.employeeDetails.bean.LoginResponse;
import org.iris.employeeDetails.bean.RegistrationBean;
import org.iris.employeeDetails.bean.ResetPasswordBean;
import org.iris.employeeDetails.bean.RegisterBean;

@Path("/gPassword")
public class GeneratePasswordController {

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public LoginResponse registerUser(GeneratePasswordBean user) {
		ResetPasswordBean passwordBean = new ResetPasswordBean();
		PasswordService passworService = new PasswordService();
		LoginResponse loginResponse = new LoginResponse();
		MailService mailService = new MailService();
		String subject = "Password for Visa portal";

		// Following is the system generated password for Visa Portal. Please
		// use this password to login or reset .

		// <password>

		// return registration.register(user);
		/*
		 * 1: generate password using the system 2: update the record in
		 * registrationTable for given email id 2: send password notification
		 * mail to user
		 */

		passwordBean.setEmail(user.getEmail());
		passwordBean.setPassword(passworService.generatePassword());
		passwordBean.setOldPassword("");

		String body = "Hi " + passworService.getUserName(user.getEmail()) + ",<br><br>";
		body += "Following is the system genereated password for ";
		body += "<a  href ='http://iris-csg-750:8080/EmployeeVisaInfomation/#/'>Visa Portal </a> Please use below password to login.</div><br>";
		body += "<div>" + passwordBean.getPassword() + "</div><br>";
		// body +=passwordBean.getPassword()+"<br>";
		body += "Thanks,<br> Admin Support";

		loginResponse = passworService.resetPassword(passwordBean.getEmail(), passwordBean.getOldPassword(),
				passwordBean.getPassword());
		if (loginResponse.isResetSuccess()) {
			// mailService.ConfigMail();
			try {
				mailService.sendMail(passwordBean.getEmail(), "fsadminsupport@irissoftware.com", body, subject);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// loginResponse.get
		return loginResponse;

	}

}
