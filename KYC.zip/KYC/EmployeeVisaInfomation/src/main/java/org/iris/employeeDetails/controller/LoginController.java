package org.iris.employeeDetails.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.DBConnection;
import org.iris.employeeDetails.DBservice.LoginServices;
import org.iris.employeeDetails.DBservice.SessionService;
import org.iris.employeeDetails.bean.LoginBean;
import org.iris.employeeDetails.bean.LoginResponse;
import org.iris.employeeDetails.bean.RegistrationBean;
import org.iris.employeeDetails.bean.SessionBean;

@Path("/login")
public class LoginController {
	public static List<String> adminUser = new ArrayList<>();

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public LoginResponse loginUser(LoginBean login) {
		LoginServices loginService = new LoginServices();
		LoginResponse loginResponse = new LoginResponse();
		RegistrationBean record = new RegistrationBean();
		SessionBean sessionbean = new SessionBean();

		SessionService sessionService = new SessionService();
		// System.out.println("Logoin");
		/*
		 * search record in registrationTable fetch email check for email for
		 * Admin or norrmal user
		 */
		record = loginService.login(login);
		loginResponse.setSessionbean(sessionbean);
		if (record == null) {
			loginResponse.setMessage("User does not exist. Please Register");
			loginResponse.setrFound(false);

		} else {

			loginResponse.setAdmin(isAdmin(login, record));
			loginResponse.setId(record.getId());
			loginResponse.setEmail(record.getEmail());
			if (isPasswordMatch(login, record)) {
				loginResponse.setMessage("record found");

				/*
				 * 1: generate the random token
				 * 
				 */
				String sessionId = sessionService.generateToken();
				/*
				 * 2: save the session to DB
				 */
				if (sessionService.saveSession(sessionId, login.getUser())) {

					/*
					 * 3: set the token to response and send it back to UI
					 */
					sessionbean.setSessionId(sessionId);
					sessionbean.setUser(login.getUser());
					sessionbean.setValidSession(true);
					loginResponse.setSessionbean(sessionbean);
				}
			} else {
				loginResponse.setMessage("Please enter the correct password");
				loginResponse.setWrongpassword(true);
			}
		}

		// loginService.
		return loginResponse;
	}

	private static boolean isAdmin(LoginBean loginBean, RegistrationBean record) {
		if (adminUser.isEmpty()) {
			populateAdmin();
		}
		if (!adminUser.isEmpty()) {
			if (adminUser.indexOf(loginBean.getUser()) > -1) {
				return true;
			}
		}
		return false;
	}

	private static boolean isPasswordMatch(LoginBean loginBean, RegistrationBean record) {

		if (loginBean.getPassword().equals((record.getPassword())))
			return true;
		return false;

	}

	private static List<String> populateAdmin() {

		ResultSet rs = null;
		try {
			rs = DBConnection.getDBInstance().getDBConnection().createStatement()
					.executeQuery("select *from adminUser;");
			while (rs.next()) {
				adminUser.add(rs.getString("user"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return adminUser;
	}

}
