package org.iris.employeeDetails.controller;

import javax.activation.MimeType;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.SessionService;
import org.iris.employeeDetails.DBservice.VisaService;
import org.iris.employeeDetails.bean.SessionBean;
import org.iris.employeeDetails.bean.VisaInfomation;

@Path("/logout")
public class LogoutController {
	
	
	@GET
	@Path("/{sessionId}")
	@Produces(MediaType.APPLICATION_JSON)
	public void logout(@PathParam("sessionId") String sessionId){
		//VisaService visaService=new VisaService();
		//SessionBean sessionbean = new SessionBean();
		SessionService sessionService = new SessionService();
		sessionService.deleteSession(sessionId);
	}
	

}
