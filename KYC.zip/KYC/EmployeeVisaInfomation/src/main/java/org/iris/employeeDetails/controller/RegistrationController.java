package org.iris.employeeDetails.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.RegistrationServices;
import org.iris.employeeDetails.DBservice.VisaService;
import org.iris.employeeDetails.bean.RegistrationBean;
import org.iris.employeeDetails.bean.RegisterBean;


@Path("/registration")
public class RegistrationController {
	RegistrationServices registration = new RegistrationServices();
	@POST
    @Produces(MediaType.APPLICATION_JSON)
	public RegisterBean registerUser(RegistrationBean user)
	{
		 return registration.register(user);
	}

}
