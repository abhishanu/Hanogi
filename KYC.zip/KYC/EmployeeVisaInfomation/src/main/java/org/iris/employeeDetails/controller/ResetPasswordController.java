package org.iris.employeeDetails.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.PasswordService;
import org.iris.employeeDetails.bean.LoginResponse;
import org.iris.employeeDetails.bean.ResetPasswordBean;


@Path("/resetPassword")
public class ResetPasswordController {

@POST
@Produces(MediaType.APPLICATION_JSON)
public LoginResponse updatePassword(ResetPasswordBean resetPassword){
	/*
	 * update the registationTable 
	 */
	
	PasswordService passworService= new PasswordService();
	return passworService.resetPassword(resetPassword.getEmail(),resetPassword.getOldPassword(),resetPassword.getPassword());
	//System.out.println("reset"); 
	
}
	
}
