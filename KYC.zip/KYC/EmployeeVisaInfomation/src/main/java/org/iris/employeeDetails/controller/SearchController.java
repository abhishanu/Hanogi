package org.iris.employeeDetails.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.SessionService;
import org.iris.employeeDetails.DBservice.VisaService;
import org.iris.employeeDetails.bean.SessionBean;
import org.iris.employeeDetails.bean.VisaInfomation;

@Path("/search")
public class SearchController {
	VisaService visaService=new VisaService();
	SessionBean sessionbean = new SessionBean();
	SessionService sessionService = new SessionService();
	VisaInfomation visabean= new VisaInfomation();
	 @GET 
	    @Path("/{id}/{selectedCountry}/{sessionId}")
	    @Produces(MediaType.APPLICATION_JSON)
		public VisaInfomation getVisaRecordById(@PathParam("id") int id, @PathParam("selectedCountry") String selectedCountry,@PathParam("sessionId") String sessionId)
		{
		 if(sessionService.isSessionAlive(sessionId)){
			 
			 visabean= visaService.getVisa(id,selectedCountry);
			 String newSessionId= sessionService.generateToken();
			 sessionService.updateSession(newSessionId,sessionId);
			 sessionbean.setSessionId(newSessionId);
             sessionbean.setUser(visabean.getTravelerName());
             sessionbean.setValidSession(true);
             visabean.setSessionbean(sessionbean);
			 
		 }else{
			 sessionbean.setValidSession(false);
			  visabean.setSessionbean(sessionbean);
		 }
			return visabean;
		}

}
