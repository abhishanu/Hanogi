package org.iris.employeeDetails.controller;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.iris.employeeDetails.DBservice.SessionService;
import org.iris.employeeDetails.DBservice.VisaService;
import org.iris.employeeDetails.bean.SessionBean;
import org.iris.employeeDetails.bean.VisaInfomation;


@Path("/employee")
public class VisaController {

	VisaService visaService=new VisaService();
	SessionBean sessionbean = new SessionBean();
	SessionService sessionService = new SessionService();

	@GET
	@Path("/{id}/{countryToVisit}/{sessionId}")
	@Produces(MediaType.APPLICATION_JSON)
	public VisaInfomation getVisaRecordById(@PathParam("id") int id,@PathParam("countryToVisit") String countryToVisit,@PathParam("sessionId") String sessionId)
	{
		VisaInfomation visabean = new VisaInfomation();
		if(sessionService.isSessionAlive(sessionId)){

			visabean= visaService.getVisa(id,countryToVisit);
			String newsessionId= sessionService.generateToken();
			sessionService.updateSession(newsessionId,sessionId);
			sessionbean.setSessionId(newsessionId);
			sessionbean.setValidSession(true);
			sessionbean.setUser(sessionService.getUser(newsessionId));
			visabean.setSessionbean(sessionbean);

		}else{
			sessionbean.setValidSession(false);
			visabean.setSessionbean(sessionbean);
		}
		return visabean;
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public SessionBean addRecord(VisaInfomation visabean){
		String sessionId =visabean.getSessionbean().getSessionId();
		
		if(sessionService.isSessionAlive(sessionId)){
			//visaService.setToMail(sessionService.getUser(visabean.getSessionbean().getSessionId()));
			visaService.addRecord(visabean, sessionService);
			String newSessionId= sessionService.generateToken();
			sessionService.updateSession(newSessionId,sessionId);
			sessionbean.setSessionId(newSessionId);
			sessionbean.setUser(sessionService.getUser(newSessionId));	
			sessionbean.setValidSession(true);
		}else{
			sessionbean.setValidSession(false);
		}

		return sessionbean;
	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public void updateRecord(VisaInfomation visa)
	{
		visaService.updateRecord(visa,sessionService);

	}

}
