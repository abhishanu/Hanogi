
//app.controller("loginController",function($scope,$location,$routeProvider){

	var app = angular.module("app", ["ngRoute"]);
	
	app.config(function($routeProvider) {
		document.querySelector(".content").style.height = (window.innerHeight - 100)+"px";
	    $routeProvider
	    .when("/", {
	        templateUrl : "views/login.html"
	    })
	    .when("/register", {
	        templateUrl : "views/registration.html",
	        controller : "registrationCtrl"
	    })
	    .when("/newpassword", {
	        templateUrl : "views/password.html",
	        controller : "passwordCtrl"
	    })
	    .when("/visarecord", {
	        templateUrl : "views/visaRecord.html",
	        controller : "visaRecordCtrl"
	    })
	    .when("/success", {
	        templateUrl : "views/success.html",
	       // controller : "visaRecordCtrl"
	    })
	    .when("/error", {
	        templateUrl : "views/error.html",
	       // controller : "visaRecordCtrl"
	    })
	    .when("/gPassword", {
	        templateUrl : "views/gPassword.html",
	       // controller : "visaRecordCtrl"
	    }).when("/regSuccess", {
	        templateUrl : "views/regSuccess.html",
		       // controller : "visaRecordCtrl"
		    })
	    .when("/resetpassword", {
	        templateUrl : "views/resetPassword.html",
	        controller : "resetPasswordController"
	    })
	    .when("/regDuplicate", {
	        templateUrl : "views/regDuplicate.html",
	        //controller : "resetPasswordController"
	    }).when("/logout", {
	        templateUrl : "views/login.html",
	        controller : "logOutController"
	    })
	       .when("/search", {
	        templateUrl : "views/search.html",
	        controller : "searchCtrl"
	    });
	});
	
	/*app.controller("loginController", function ($scope) {
	    $scope.msg = "I love London";
	});*/
	/* app.controller("parisCtrl", function ($scope) {
	    $scope.msg = "I love Paris";
	}); */

//});
	
	

	
         
           