 //Controller Part
            app.controller("EmployController", function($scope, $http) {
         
               
                $scope.employee = [];
                $scope.employForm = {
                    id : "",
                   // countryName : "",
                   // population : "",
                   //id2:11
                        travelerName : "", 
                    	countryToVisit : ""
                    	/* clientName : "",
                    	clientAddress : "",
                    	clientsContactNo : "",
                    	clientContactPersonName : "", 
                    	projectDetails : "",
                    	projectType : "",
                    	travelDates : "",
                    	bdm : "",
                    	preSales : "",  
                    	pmo :  "",
                    	travelBillable : "",
                    	isBillable :"",
                    	airfare :"",
                    	hotel :"",
                    	car : "",
                    	meals : "",
                    	other : "",
                    	contactNumber : "",
            		 	mealPreferences : "",
            	 		seatPreferences : "",
            	 		anyOthers: "" */
                };
                

                //Now load the data from server
               // _refreshCountryData();
         
                //HTTP POST/PUT methods for add/edit country 
                // with the help of id, we are going to find out whether it is put or post operation
                
                $scope.submitEmploy = function() {
         
                    var method = "";
                    var url = "";
                    /* if ($scope.employForm.id == -1) {
                        //Id is absent in form data, it is create new country operation
                        method = "POST";
                        url = 'rest/employee';
                    } else {
                        //Id is present in form data, it is edit country operation
                        method = "PUT";
                        url = 'rest/employee';
                    } */
                    
                        //Id is absent in form data, it is create new country operation
                        method = "POST";
                        url = 'rest/employee';
                   
                    $http({
                        method : method,
                        url : url,
                        data : angular.toJson($scope.employForm),
                        headers : {
                            'Content-Type' : 'application/json'
                        }
                    }).then( _success, _error );
                };
         
                //HTTP DELETE- delete country by Id
                $scope.deleteEmploy = function(country) {
                    $http({
                        method : 'DELETE',
                        url : 'rest/employee/' + country.id
                    }).then(_success, _error);
                };
 
             // In case of edit, populate form fields and assign form.id with country id
                $scope.editEmploy = function(country) {
                  
                    $scope.employForm.countryName = country.countryName;
                    $scope.employForm.population = country.population;
                    $scope.employForm.id = country.id;
                };
         
                /* Private Methods */
                //HTTP GET- get all employee collection
                function _refreshCountryData() {
                    $http({
                        method : 'GET',
                        url : 'http://localhost:8080/AngularjsJAXRSCRUDExample/rest/employee'
                    }).then(function successCallback(response) {
                        $scope.employee = response.data;
                    }, function errorCallback(response) {
                        console.log(response.statusText);
                    });
                }
         
                function _success(response) {
                    _refreshCountryData();
                    _clearFormData()
                }
         
                function _error(response) {
                    console.log(response.statusText);
                }
         
                //Clear the form
                function _clearFormData() {
                    $scope.employForm.id = -1;
                    $scope.employForm.countryName = "";
                    $scope.employForm.population = "";
                
                };
            });