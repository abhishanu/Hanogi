/**
 * 
 */
angular.module('app').controller("logOutController", function($scope,$location, $rootScope,logoutService){

	if($rootScope.sessionId==""|| $rootScope.sessionId==undefined){
		 $location.path('/');
	}else{
		logoutService.logOutUser($rootScope.sessionId)
		.then(function(response){
			$rootScope.loggedIn=false;
			$rootScope.loggedInUser="";
			$rootScope.userId="";
		 $rootScope.validSession=false;
		 $location.path('/');
	 });
		
	}
});