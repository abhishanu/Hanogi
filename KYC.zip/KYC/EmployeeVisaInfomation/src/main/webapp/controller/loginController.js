/**
 * 
 */
 angular.module('app').controller("loginController", function($scope,$location, resetPasswordService,loginService,$rootScope,logoutService){
	 
	 /*
	  * 
	  */
	 $rootScope.formSubmitted=false;
	$scope.is_reset=resetPasswordService.getIs_reset();
	$scope.wrongPassword=false;
	$scope.wMessage="";
	$scope.rfound=true;
	$scope.loginService=false;
	 $scope.loginForm ={ 
			 user:"",
			 password:""		 
	 };
	 /*loginService.setLoggedIn(true);*/
	 	$rootScope.loggedIn=false;
		$rootScope.loggedInUser="";
		$rootScope.userId="";
		
		
		if($rootScope.sessionId==""|| $rootScope.sessionId==undefined){
			 $location.path('/');
		}else{
			logoutService.logOutUser($rootScope.sessionId)
			.then(function(response){
			 $rootScope.validSession=false;
			 $location.path('/');
		 });
			
		}
		
	 $scope.login =function(){
		 /*
		  * http call to back end using rest API 
		  */
		 
		 loginService.loginUser($scope.loginForm).then( _success, _error );

	 };
	 function _success(response){
	    	// alert("success: "+response);
	    	 data = response.data;
	    	 if(data.rFound){
	    	 loginService.setEmployId(data.id);
	    	 loginService.setIsAdmin(data.admin);
	    	 $rootScope.validSession=data.sessionbean.validSession
	    	 
	    	 if(data.wrongpassword){
	    		 $scope.wrongPassword=true;
	    		 $scope.wMessage=data.message;
	    		 $scope.loginForm.password="";
	    	 }else{
	    		 if($rootScope.validSession){
	    			 /*loginService.setLoggedIn(true);*/
	    			$rootScope.loggedIn=true;
	    			$rootScope.loggedInUserId = data.sessionbean.user;
		    		$rootScope.loggedInUser=data.sessionbean.user.split("@")[0];
		    		$rootScope.userId=data.id;
		    		$rootScope.sessionId=data.sessionbean.sessionId;
		    		resetPasswordService.setIs_reset(false);
		    		$location.path('/search'); 
		    	 }else{
		    		 $rootScope.loggedIn=false;
		    		 $scope.sMessage="Invalid Session"; 
		    	 }
	    	 //return response;
	    	 }
	    	 }else{
	    		 $scope.rfound=false;
	    		 $scope.wMessage=data.message;
	    		 $scope.loginForm.password="";
	    	 }
	    	 
	     }
	     function _error(response){
	    	// alert("error: "+response);
	    	 return response;
	     }
	     
	
 });
 