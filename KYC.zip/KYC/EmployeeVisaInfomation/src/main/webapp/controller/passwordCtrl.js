/**
 * 
 */
 angular.module('app').controller("passwordCtrl", function($scope,passwordService){
	$scope.pForm={email:""};
	 $scope.creatPassword =function(){
		 
		 passwordService.resetpassword($scope.pForm);
	 };
	 
 });