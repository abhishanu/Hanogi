/**
 * 
 */

angular.module('app').controller("registrationCtrl", function($scope, registrationService) {
	$scope.empty="";
	$scope.confirmPassword="";
	
	$scope.registrationForm={
			name:"",
			email:"",
			id:"",
			password:""
	};
	$scope.registerUser= function(){
		registrationService.registerUser($scope.registrationForm);	
		
	};
	
	
	/*app.controller('Login', function ($scope, LoginService, $state) {
	    $scope.Login = function () {
	        var sub = {
	            User_Name: $scope.User_Name,
	            User_Password: $scope.User_Password
	        };
	        var checkData = LoginService.Login(sub);
	        checkData.then(function (data) {
	            //want redirection
	            var url = '/Home/Index/';
	            $state.go(url);
	            }, function (error) {
	            })
	        };
	});*/
	/*
	 * user Name
	 * Fist Name
	 * last Name 
	 */
	/*
	 * restCall 
	 * 
	 */
	
	/*
	 * http request ..  get 1692
	 * $http(method:
	 * URL: 
	 * data: )
	 */
	
	
	/*
	 * succes/failure 
	 */
	
	/*
	 * on success/on failure 
	 */

	/*
	 * java controler 
	 * 
	 * @controller 
	 * 
	 * Method 
	 * GET /POST/UPDATE 
	 */
	
});