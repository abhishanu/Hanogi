/**
 * 
 */
angular.module('app').controller("resetPasswordController", function($scope,resetPasswordService,$rootScope,$location,logoutService){
	//$scope.isSuccess=false;
	$scope.empty="";
	$scope.confirmPassword="";
	$scope.resetpasswordForm={
		email : $rootScope.loggedInUserId,
		oldPassword:"",
			password:""
	};
	
	$scope.resetPassword=function(){
		
		resetPasswordService.reset($scope.resetpasswordForm).then(_success, _error);
	};
function _success(response){
		
	//$rootScope.isSuccess=true;
	/*logoutService.logOutUser($rootScope.sessionId)
	.then(function(respone){
		$location.path('/');
	});*/
	resetPasswordService.setIs_reset(true);
	$location.path('/');
	
	};
function _error(response){
	$scope.isSuccess=false;
};
});