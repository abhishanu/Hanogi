/**
 * 
 */
 angular.module('app').controller("searchCtrl", function($scope,$rootScope, $http,searchService,loginService){
	 $scope.admin=loginService.getIsAdmin();
	 if($scope.admin){
		 $scope.id ="";
	 }else{
		 $scope.id =loginService.getEmployId()
		 }
	 
	$scope.countries =["US", "UK", "Canada"];
	$scope.searchForm ={
			id:$scope.id,
			selectedCountry:""
	};
	$rootScope.id = $scope.id;
	$scope.searchRecord=function(){
		searchService.search($scope.searchForm);
	}
	
 });