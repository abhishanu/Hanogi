app.controller("visaRecordCtrl",function($scope,visaRecordService,$location,$rootScope){
	$scope.employee="";
	$scope.showRecord=false;
	$scope.isSubmit=false;
	$scope.billables=["Y","N"];
	$scope.Yes="Y";
	$scope.fairOption=["overseas", "domestic"];
	$scope.mealOption=["YES", "NO"];
	$scope.mealPref=["Veg", "Non-Veg"];
	$scope.seatPref=["window", "aisle"];
	$scope.countries =["US", "UK", "Canada"];
	$scope.cancelform=false;
	$rootScope.formSubmitted=false;
	$scope.Cancel = function () {
		$scope.cancelform=true;
		 $location.path('/search');
	};
	
	$scope.employForm ={id:"",
			 travelerName : "",
			 countryToVisit : "",
			 clientName: "",
			 clientAddress: "",
			 clientsContactNo: "",
			 clientContactPersonName: "",
			 projectDetails: "",
			 projectType: "",
			 fromDate:"",
			 toDate:"",
			 bdm: "",
			 preSales: "",
			 pmo: "",
			 travelBillable: "",
			 isBillable: "",
			 airfare: "",
			 hotel: "",
			 car: "",
			 meals: "",
			 other: "",
			 contactNumber: "",
			 mealPreferences: "",
			 seatPreferences: "",
			 anyOthers: ""};
	$scope.employForm =visaRecordService.getData();
	$scope.employForm.countryToVisit=visaRecordService.getCountry();
	$scope.employForm.fromDate =visaRecordService.getFromDate();
	$scope.employForm.toDate =visaRecordService.getToDate();
	$scope.submitRecord =function(){
	      visaRecordService.insertRecord($scope.employForm);
		 
	};
	
     
     $scope.editEmploy=function(){
    	 alert();
     };
		});