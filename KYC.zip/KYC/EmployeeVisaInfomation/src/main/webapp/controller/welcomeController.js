app.controller("welcomeController", function($scope, $http) {
	$scope.showRecord = false;
	$scope.isSubmit = false;
	$scope.billableOption = [ "Y", "N" ];
	$scope.employForm = {
		id : "",
		travelerName : "",
		countryToVisit : "",
		clientName : "",
		clientAddress : "",
		clientsContactNo : "",
		clientContactPersonName : "",
		projectDetails : "",
		projectType : "",
		travelDates : "",
		bdm : "",
		preSales : "",
		pmo : "",
		travelBillable : "",
		isBillable : "",
		airfare : "",
		hotel : "",
		car : "",
		meals : "",
		other : "",
		contactNumber : "",
		mealPreferences : "",
		seatPreferences : "",
		anyOthers : ""
	};

	$scope.getRecord = function() {
		if ($scope.showRecord) {
			method = "POST";
			url = 'rest/employee';

			$http({
				method : method,
				url : url,
				data : angular.toJson($scope.employForm),
				headers : {
					'Content-Type' : 'application/json'
				}
			}).then(_success, _error);
		} else {
			$http({
				method : 'GET',
				url : 'rest/employee/' + $scope.employForm.id
			}).then(function successCallback(response) {
				$scope.employee = response.data;
				$scope.showRecord = true;
				populateRecord();
			}, function errorCallback(response) {
				console.log(response.statusText);
			});
		}
	};

	$scope.editEmploy = function() {
		alert();
	};
	function populateRecord() {
		$scope.employForm.id = $scope.employee.id;
		$scope.employForm.travelerName = $scope.employee.travelerName;
		$scope.employForm.countryToVisit = $scope.employee.countryToVisit;
		$scope.employForm.clientName = $scope.employee.clientName;
		$scope.employForm.clientAddress = $scope.employee.clientAddress;
		$scope.employForm.clientsContactNo = $scope.employee.clientsContactNo;
		$scope.employForm.clientContactPersonName = $scope.employee.clientContactPersonName;
		$scope.employForm.projectDetails = $scope.employee.projectDetails;
		$scope.employForm.projectType = $scope.employee.projectType;
		$scope.employForm.travelDates = $scope.employee.travelDates;
		$scope.employForm.bdm = $scope.employee.bdm;
		$scope.employForm.preSales = $scope.employee.preSales;
		$scope.employForm.pmo = $scope.employee.pmo;
		$scope.employForm.travelBillable = $scope.employee.travelBillable;
		$scope.employForm.isBillable = $scope.employee.isBillable;
		$scope.employForm.airfare = $scope.employee.airfare;
		$scope.employForm.hotel = $scope.employee.hotel;
		$scope.employForm.car = $scope.employee.car;
		$scope.employForm.meals = $scope.employee.meals;
		$scope.employForm.other = $scope.employee.other;
		$scope.employForm.contactNumber = $scope.employee.contactNumber;
		$scope.employForm.mealPreferences = $scope.employee.mealPreferences;
		$scope.employForm.seatPreferences = $scope.employee.seatPreferences;
		$scope.employForm.anyOthers = $scope.employee.anyOthers;

	}
	function _success(response) {
		//_refreshCountryData();
		// _clearFormData()
		$scope.isSubmit = true;

	}

	function _error(response) {
		console.log(response.statusText);
	}
});