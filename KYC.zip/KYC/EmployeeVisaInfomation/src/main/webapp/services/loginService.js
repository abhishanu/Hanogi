/**
 * 
 */
angular.module('app').service('loginService', function($http,$location) {
	
	this.employId="";
	this.isAdmin=false;
	/*this.loggedIn=false;*/
	
	this.setEmployId =function(employId){
		this.employId=employId;
	};
	this.setIsAdmin=function(isAdmin){
		this.isAdmin=isAdmin;
	};
	this.getEmployId=function(){
		return this.employId;
	};
	this.getIsAdmin=function(){
		return this.isAdmin;
	};
	/*this.setLoggedIn=function(loggedIn){
		this.loggedIn=loggedIn;
	}
	this.getLoggedIn=function(){
		return this.loggedIn;
	}*/
	this.loginUser = function(loginForm) {
		
			method = "POST";
            url = 'rest/login';
       
       return  $http({
            method : method,
            url : url,
            data : angular.toJson(loginForm),
            headers : {
                'Content-Type' : 'application/json'
            }
        });	

     };
   /*
     function _success(response){
    	// alert("success: "+response);
    	 data = response.data;
    	 this.employId=data.id;
    	 this.isAdmin=data.admin;
    	 this.loggedIn=true;
    	 $location.path('/search'); 
    	 //return response;
    	 
     }
     function _error(response){
    	 this.loggedIn=false;
    	 alert("error: "+response);
    	 return response;
     }*/
});

/*app.service("LoginService", function ($http) {
    this.Login = function (sub) {
        var credentials = { User_Name: sub.User_Name, User_Password: sub.User_Password };
           $http.post('api/NCT_UsersLogin/', credentials).success(function (response) {  });
    }
});*/