/**
 * 
 */
angular.module('app').service('logoutService', function($http,$location) {

	this.logOutUser = function(sessionId) {
   
   return  $http({
        method : 'GET',
        url : 'rest/logout/' +sessionId
       
    });	

 };

});
