/**
 * 
 */
angular.module('app').service('passwordService', function($http,$location) {
   this.createNewpassword=function(passwordInfo){
	  return passwordInfo; 
   } ;
   this.resetpassword=function(passwordInfo){
	   
	   method = "POST";
	      url = 'rest/gPassword';
	 
	  $http({
	      method : method,
	      url : url,
	      data : angular.toJson(passwordInfo),
	      headers : {
	          'Content-Type' : 'application/json'
	      }
	  }).then( _success, _error );	
   };
   function _success(response){
		// alert("success: "+response);
		 $location.path('/gPassword'); 
		 //return response;
		 
	}
	function _error(response){
		// alert("error: "+response);
		 return response;
	}
});