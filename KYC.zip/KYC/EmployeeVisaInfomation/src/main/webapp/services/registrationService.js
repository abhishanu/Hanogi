/**
 * 
 */
angular.module('app').service('registrationService', function($http,$location,resetPasswordService) {
  this.registerUser=function(user){
	  
	  method = "POST";
      url = 'rest/registration';
 
  $http({
      method : method,
      url : url,
      data : angular.toJson(user),
      headers : {
          'Content-Type' : 'application/json'
      }
  }).then( _success, _error );	

};

function _success(response){
	data = response.data;
	if(data.rFound){
		resetPasswordService.setIs_reset(false);
		$location.path('/regDuplicate');
	
	}else{
		resetPasswordService.setIs_reset(false);
		 $location.path('/regSuccess'); 
	}
	
	 //return response;
	 
}
function _error(response){
	// alert("error: "+response);
	 return response;
}
});


