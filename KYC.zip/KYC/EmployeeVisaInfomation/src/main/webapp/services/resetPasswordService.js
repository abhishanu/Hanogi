/**
 * 
 */
angular.module('app').service("resetPasswordService",function($http,$location){
	this.is_reset=false;
	this.getIs_reset=function(){
		return this.is_reset;
	};
	
	this.setIs_reset=function(x){
		 this.is_reset=x;
	};
	this.reset=function(resetData){
		return $http({
			method:"POST",
			url:"rest/resetPassword",
			data:angular.toJson(resetData),
			header: {
				'Content-Type' : 'application/json'
			}
			
		});
	};
	
	
});