/**
 * 
 */
angular.module('app').service('searchService',function( $http,$location,visaRecordService,$rootScope){
	
	this.search= function(record){
		
		return $http({
            method : 'GET',
            url : 'rest/search/' + record.id+'/'+record.selectedCountry+'/'+$rootScope.sessionId
        }).then(function successCallback(response) {
        	 var recordrecieve = response.data;
        	 $rootScope.validSession=recordrecieve.sessionbean.validSession;
        	 
        	 if($rootScope.validSession){
        		 /*
        		  * set the session param
        		  */
	    		//$rootScope.loggedInUser=recordrecieve.sessionbean.user;
	    		$rootScope.userId=recordrecieve.id;
	    		$rootScope.sessionId=recordrecieve.sessionbean.sessionId;
	    		/*if(recordrecieve.travelerName==null || recordrecieve.travelerName==""){
	    			recordrecieve.travelerName=$rootScope.loggedInUser;
	    		}*/
	    		/*
	    		 * set the record from back end 
	    		 */
	    		
	    		visaRecordService.setData(recordrecieve);
	            visaRecordService.setFromDate(recordrecieve.fromDate);
	            visaRecordService.setToDate(recordrecieve.toDate);
	            visaRecordService.setCountry(record.selectedCountry);
	            /*
	             * redirect the page to Visa information page
	             */
	            $location.path('/visarecord'); 
        	 }else{
        		 $location.path('/');
        	 }
        }, function errorCallback(response) {
            console.log(response.statusText);
        });
	};
});