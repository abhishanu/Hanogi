/**
 * 
 */
angular.module('app').service('sessionService', function($rootScope) {
	
	$rootScope.loggedInUser="";
	$rootScope.sessionId="";
});