/**
 * 
 */
angular.module('app').service("visaRecordService", function($http,$location,$rootScope){
	this.isSuccess=true;
	this.employee="";
	this.visitedCountry="";
	this.fromDate="";
	this.toDate="";
	this.setFromDate=function(date){
		if(date!= null){
		this.fromDate=new Date(date);
		}else{
			this.fromDate="";
		}
		
	};
	
	this.setToDate=function(date){
		if(date!= null){
		this.toDate=new Date(date);
		}else{
			this.toDate="";
		}
		
	};
	
	this.getFromDate=function(){
		return this.fromDate;
	};
	this.getToDate=function(){
		return this.toDate;
	};
	this.getCountry=function(){
	return	this.visitedCountry;
	};
	this.setCountry =function(country){
	this.visitedCountry=country;
	};
	this.getData=function(){
		return this.employee;
	};
	this.setData =function(data){
		this.employee=data;
	};
	this.insertRecord=function(record){
			
			method = "POST";
            url = 'rest/employee';
       
        $http({
            method : method,
            url : url,
            data : angular.toJson(record),
            headers : {
                'Content-Type' : 'application/json'
            }
        }).then( _success, _error );	
		
     };
	
	
	this.updateRecord=function(record){
		
	};
	
	 function _success(response){
		
		//return response.data;
		 var recordrecieve = response.data;
    	 $rootScope.validSession=recordrecieve.validSession;
    	 
    	 if($rootScope.validSession){
    		 /*
    		  * set the session param
    		  */
    		//$rootScope.loggedInUser=recordrecieve.user;
    		$rootScope.sessionId=recordrecieve.sessionId;
    		/*
    		 * set the record from back end 
    		 */
          //  visaRecordService.setCountry(record.selectedCountry);
            /*
             * redirect the page to Visa information page
             */
    		$rootScope.formSubmitted=true;
		 $location.path('/search');
    	 }else{
    		 $location.path('/');
    	 }
		
	};
	
	function _error(response){
		console.log(response.statusText);
		$location.path('/error');
		//return response.data;
		
	};
	this.populateRecord=function(record){
   	 
   	/* $scope.employForm.id=$scope.employee.id;
   	 $scope.employForm.travelerName=$scope.employee.travelerName;
   	 $scope.employForm.countryToVisit=$scope.employee.countryToVisit;
   	 $scope.employForm.clientName=$scope.employee.clientName;
   	 $scope.employForm.clientAddress=$scope.employee.clientAddress;
   	 $scope.employForm.clientsContactNo=$scope.employee.clientsContactNo;
   	 $scope.employForm.clientContactPersonName=$scope.employee.clientContactPersonName;
   	 $scope.employForm.projectDetails=$scope.employee.projectDetails;
   	 $scope.employForm.projectType=$scope.employee.projectType;
   	 $scope.employForm.travelDates=$scope.employee.travelDates;
   	 $scope.employForm.bdm=$scope.employee.bdm;
   	 $scope.employForm.preSales=$scope.employee.preSales;
   	 $scope.employForm.pmo=$scope.employee.pmo;
   	 $scope.employForm.travelBillable=$scope.employee.travelBillable;
   	 $scope.employForm.isBillable=$scope.employee.isBillable;
   	 $scope.employForm.airfare=$scope.employee.airfare;
   	 $scope.employForm.hotel=$scope.employee.hotel;
   	 $scope.employForm.car=$scope.employee.car;
   	 $scope.employForm.meals=$scope.employee.meals;
   	 $scope.employForm.other=$scope.employee.other;
   	 $scope.employForm.contactNumber=$scope.employee.contactNumber;
   	 $scope.employForm.mealPreferences=$scope.employee.mealPreferences;
   	 $scope.employForm.seatPreferences=$scope.employee.seatPreferences;
   	 $scope.employForm.anyOthers=$scope.employee.anyOthers;*/
   	return record;
    }
});