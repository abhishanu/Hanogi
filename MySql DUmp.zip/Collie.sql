CREATE DATABASE  IF NOT EXISTS `collie_services` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `collie_services`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: collie_services
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `ri_login_details`
--

DROP TABLE IF EXISTS `ri_login_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ri_login_details` (
  `user_id` varchar(255) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `access_key` varchar(255) default NULL,
  `is_active` varchar(255) default NULL,
  `login_type_id` varchar(255) default NULL,
  `pass` varchar(255) default NULL,
  `pass_history` text,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ri_login_details`
--

LOCK TABLES `ri_login_details` WRITE;
/*!40000 ALTER TABLE `ri_login_details` DISABLE KEYS */;
INSERT INTO `ri_login_details` VALUES ('abhi',NULL,NULL,NULL,NULL,NULL,'1','4','$2a$10$pGzyw8JYymjS5/QC5eCOAec2Y6B2eRAum1iMFAtm4/YaTcuBIKF.e',NULL),('test',NULL,NULL,NULL,NULL,NULL,'1','4','123',NULL);
/*!40000 ALTER TABLE `ri_login_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ri_user_details`
--

DROP TABLE IF EXISTS `ri_user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ri_user_details` (
  `user_id` int(11) NOT NULL auto_increment,
  `aadharcard` varchar(255) default NULL,
  `address_id` varchar(255) default NULL,
  `dob` datetime default NULL,
  `email` varchar(255) default NULL,
  `firstname` varchar(255) default NULL,
  `gender` varchar(255) default NULL,
  `is_active` varchar(255) default NULL,
  `lastname` varchar(255) default NULL,
  `location` varchar(255) default NULL,
  `middlename` varchar(255) default NULL,
  `other_delievery_address` varchar(255) default NULL,
  `pancard` varchar(255) default NULL,
  `pandit_id` varchar(255) default NULL,
  `photo_id` varchar(255) default NULL,
  `primary_phone` varchar(255) default NULL,
  `secondary_phone` varchar(255) default NULL,
  `user_role_id` varchar(255) default NULL,
  `voterid` varchar(255) default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ri_user_details`
--

LOCK TABLES `ri_user_details` WRITE;
/*!40000 ALTER TABLE `ri_user_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `ri_user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL auto_increment,
  `role_name` varchar(255) default NULL,
  `role_desc` varchar(255) default NULL,
  PRIMARY KEY  (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ROLE_SUPER_ADMIN',NULL),(2,'ROLE_ADMIN',NULL),(3,'ROLE_AGENT',NULL),(4,'ROLE_USER',NULL),(5,'ROLE_PARTNER',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_menu`
--

DROP TABLE IF EXISTS `user_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_menu` (
  `user_menu_id` int(11) NOT NULL auto_increment,
  `user_menu` text,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `is_active` varchar(255) default NULL,
  `access_role_id` varchar(5) default '3',
  PRIMARY KEY  (`user_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_menu`
--

LOCK TABLES `user_menu` WRITE;
/*!40000 ALTER TABLE `user_menu` DISABLE KEYS */;
INSERT INTO `user_menu` VALUES (1,'Profile,24*7 Support,Logout','abhi',NULL,NULL,NULL,'1','3'),(2,'Manage Role,Create Account,Agents List','abhi',NULL,NULL,NULL,'1','3');
/*!40000 ALTER TABLE `user_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `user_id` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY  (`user_id`,`role_id`),
  KEY `FKh8ciramu9cc9q3qcqiv4ue8a6` (`role_id`),
  CONSTRAINT `FKh8ciramu9cc9q3qcqiv4ue8a6` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`),
  CONSTRAINT `FKpqad63038gqptwqxgtqix8j02` FOREIGN KEY (`user_id`) REFERENCES `ri_login_details` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES ('abhi',1),('test',1);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-06 17:35:23
