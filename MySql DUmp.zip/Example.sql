CREATE DATABASE  IF NOT EXISTS `example` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `example`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: example
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `id` int(11) default NULL,
  `name` varchar(20) default NULL,
  `authour` varchar(20) default NULL,
  `cityId` varchar(12) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (12,'Spring','AK','1024'),(13,'Spring','AK','1024'),(14,'Spring','Abhishek','1024'),(15,'MYSQL','abhi','1024'),(17,'Angular','Abhi','1024'),(20,'Android','Abhi','1024');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `id` int(11) default NULL,
  `name` varchar(20) default NULL,
  `authour` varchar(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (10,'Java','Oracle'),(10,'Java','Oracle');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `ID` int(11) NOT NULL default '0',
  `Name` char(35) NOT NULL default '',
  `CountryCode` char(3) NOT NULL default '',
  `District` char(20) NOT NULL default '',
  `Population` int(11) NOT NULL default '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1024,'Mumbai (Bombay)','IND','Maharashtra',10500000),(1025,'Delhi','IND','Delhi',7206704),(1026,'Calcutta [Kolkata]','IND','West Bengali',4399819),(1027,'Chennai (Madras)','IND','Tamil Nadu',3841396),(1028,'Hyderabad','IND','Andhra Pradesh',2964638),(1029,'Ahmedabad','IND','Gujarat',2876710),(1030,'Bangalore','IND','Karnataka',2660088),(1031,'Kanpur','IND','Uttar Pradesh',1874409),(1032,'Nagpur','IND','Maharashtra',1624752),(1033,'Lucknow','IND','Uttar Pradesh',1619115),(1034,'Pune','IND','Maharashtra',1566651),(1035,'Surat','IND','Gujarat',1498817),(1036,'Jaipur','IND','Rajasthan',1458483),(1037,'Indore','IND','Madhya Pradesh',1091674),(1038,'Bhopal','IND','Madhya Pradesh',1062771),(1039,'Ludhiana','IND','Punjab',1042740),(1040,'Vadodara (Baroda)','IND','Gujarat',1031346),(1041,'Kalyan','IND','Maharashtra',1014557),(1042,'Madurai','IND','Tamil Nadu',977856),(1043,'Haora (Howrah)','IND','West Bengali',950435),(1044,'Varanasi (Benares)','IND','Uttar Pradesh',929270),(1045,'Patna','IND','Bihar',917243),(1046,'Srinagar','IND','Jammu and Kashmir',892506),(1047,'Agra','IND','Uttar Pradesh',891790),(1048,'Coimbatore','IND','Tamil Nadu',816321),(1049,'Thane (Thana)','IND','Maharashtra',803389),(1050,'Allahabad','IND','Uttar Pradesh',792858),(1051,'Meerut','IND','Uttar Pradesh',753778),(1052,'Vishakhapatnam','IND','Andhra Pradesh',752037),(1053,'Jabalpur','IND','Madhya Pradesh',741927),(1054,'Amritsar','IND','Punjab',708835),(1055,'Faridabad','IND','Haryana',703592),(1056,'Vijayawada','IND','Andhra Pradesh',701827),(1057,'Gwalior','IND','Madhya Pradesh',690765),(1058,'Jodhpur','IND','Rajasthan',666279),(1059,'Nashik (Nasik)','IND','Maharashtra',656925),(1060,'Hubli-Dharwad','IND','Karnataka',648298),(1061,'Solapur (Sholapur)','IND','Maharashtra',604215),(1062,'Ranchi','IND','Jharkhand',599306),(1063,'Bareilly','IND','Uttar Pradesh',587211),(1064,'Guwahati (Gauhati)','IND','Assam',584342),(1065,'Shambajinagar (Aurangabad)','IND','Maharashtra',573272),(1066,'Cochin (Kochi)','IND','Kerala',564589),(1067,'Rajkot','IND','Gujarat',559407),(1068,'Kota','IND','Rajasthan',537371),(1069,'Thiruvananthapuram (Trivandrum','IND','Kerala',524006),(1070,'Pimpri-Chinchwad','IND','Maharashtra',517083),(1071,'Jalandhar (Jullundur)','IND','Punjab',509510),(1072,'Gorakhpur','IND','Uttar Pradesh',505566),(1073,'Chandigarh','IND','Chandigarh',504094),(1074,'Mysore','IND','Karnataka',480692),(1075,'Aligarh','IND','Uttar Pradesh',480520),(1076,'Guntur','IND','Andhra Pradesh',471051),(1077,'Jamshedpur','IND','Jharkhand',460577),(1078,'Ghaziabad','IND','Uttar Pradesh',454156),(1079,'Warangal','IND','Andhra Pradesh',447657),(1080,'Raipur','IND','Chhatisgarh',438639),(1081,'Moradabad','IND','Uttar Pradesh',429214),(1082,'Durgapur','IND','West Bengali',425836),(1083,'Amravati','IND','Maharashtra',421576),(1084,'Calicut (Kozhikode)','IND','Kerala',419831),(1085,'Bikaner','IND','Rajasthan',416289),(1086,'Bhubaneswar','IND','Orissa',411542),(1087,'Kolhapur','IND','Maharashtra',406370),(1088,'Kataka (Cuttack)','IND','Orissa',403418),(1089,'Ajmer','IND','Rajasthan',402700),(1090,'Bhavnagar','IND','Gujarat',402338),(1091,'Tiruchirapalli','IND','Tamil Nadu',387223),(1092,'Bhilai','IND','Chhatisgarh',386159),(1093,'Bhiwandi','IND','Maharashtra',379070),(1094,'Saharanpur','IND','Uttar Pradesh',374945),(1095,'Ulhasnagar','IND','Maharashtra',369077),(1096,'Salem','IND','Tamil Nadu',366712),(1097,'Ujjain','IND','Madhya Pradesh',362266),(1098,'Malegaon','IND','Maharashtra',342595),(1099,'Jamnagar','IND','Gujarat',341637),(1100,'Bokaro Steel City','IND','Jharkhand',333683),(1101,'Akola','IND','Maharashtra',328034),(1102,'Belgaum','IND','Karnataka',326399),(1103,'Rajahmundry','IND','Andhra Pradesh',324851),(1104,'Nellore','IND','Andhra Pradesh',316606),(1105,'Udaipur','IND','Rajasthan',308571),(1106,'New Bombay','IND','Maharashtra',307297),(1107,'Bhatpara','IND','West Bengali',304952),(1108,'Gulbarga','IND','Karnataka',304099),(1109,'New Delhi','IND','Delhi',301297),(1110,'Jhansi','IND','Uttar Pradesh',300850),(1111,'Gaya','IND','Bihar',291675),(1112,'Kakinada','IND','Andhra Pradesh',279980),(1113,'Dhule (Dhulia)','IND','Maharashtra',278317),(1114,'Panihati','IND','West Bengali',275990),(1115,'Nanded (Nander)','IND','Maharashtra',275083),(1116,'Mangalore','IND','Karnataka',273304),(1117,'Dehra Dun','IND','Uttaranchal',270159),(1118,'Kamarhati','IND','West Bengali',266889),(1119,'Davangere','IND','Karnataka',266082),(1120,'Asansol','IND','West Bengali',262188),(1121,'Bhagalpur','IND','Bihar',253225),(1122,'Bellary','IND','Karnataka',245391),(1123,'Barddhaman (Burdwan)','IND','West Bengali',245079),(1124,'Rampur','IND','Uttar Pradesh',243742),(1125,'Jalgaon','IND','Maharashtra',242193),(1126,'Muzaffarpur','IND','Bihar',241107),(1127,'Nizamabad','IND','Andhra Pradesh',241034),(1128,'Muzaffarnagar','IND','Uttar Pradesh',240609),(1129,'Patiala','IND','Punjab',238368),(1130,'Shahjahanpur','IND','Uttar Pradesh',237713),(1131,'Kurnool','IND','Andhra Pradesh',236800),(1132,'Tiruppur (Tirupper)','IND','Tamil Nadu',235661),(1133,'Rohtak','IND','Haryana',233400),(1134,'South Dum Dum','IND','West Bengali',232811),(1135,'Mathura','IND','Uttar Pradesh',226691),(1136,'Chandrapur','IND','Maharashtra',226105),(1137,'Barahanagar (Baranagar)','IND','West Bengali',224821),(1138,'Darbhanga','IND','Bihar',218391),(1139,'Siliguri (Shiliguri)','IND','West Bengali',216950),(1140,'Raurkela','IND','Orissa',215489),(1141,'Ambattur','IND','Tamil Nadu',215424),(1142,'Panipat','IND','Haryana',215218),(1143,'Firozabad','IND','Uttar Pradesh',215128),(1144,'Ichalkaranji','IND','Maharashtra',214950),(1145,'Jammu','IND','Jammu and Kashmir',214737),(1146,'Ramagundam','IND','Andhra Pradesh',214384),(1147,'Eluru','IND','Andhra Pradesh',212866),(1148,'Brahmapur','IND','Orissa',210418),(1149,'Alwar','IND','Rajasthan',205086),(1150,'Pondicherry','IND','Pondicherry',203065),(1151,'Thanjavur','IND','Tamil Nadu',202013),(1152,'Bihar Sharif','IND','Bihar',201323),(1153,'Tuticorin','IND','Tamil Nadu',199854),(1154,'Imphal','IND','Manipur',198535),(1155,'Latur','IND','Maharashtra',197408),(1156,'Sagar','IND','Madhya Pradesh',195346),(1157,'Farrukhabad-cum-Fatehgarh','IND','Uttar Pradesh',194567),(1158,'Sangli','IND','Maharashtra',193197),(1159,'Parbhani','IND','Maharashtra',190255),(1160,'Nagar Coil','IND','Tamil Nadu',190084),(1161,'Bijapur','IND','Karnataka',186939),(1162,'Kukatpalle','IND','Andhra Pradesh',185378),(1163,'Bally','IND','West Bengali',184474),(1164,'Bhilwara','IND','Rajasthan',183965),(1165,'Ratlam','IND','Madhya Pradesh',183375),(1166,'Avadi','IND','Tamil Nadu',183215),(1167,'Dindigul','IND','Tamil Nadu',182477),(1168,'Ahmadnagar','IND','Maharashtra',181339),(1169,'Bilaspur','IND','Chhatisgarh',179833),(1170,'Shimoga','IND','Karnataka',179258),(1171,'Kharagpur','IND','West Bengali',177989),(1172,'Mira Bhayandar','IND','Maharashtra',175372),(1173,'Vellore','IND','Tamil Nadu',175061),(1174,'Jalna','IND','Maharashtra',174985),(1175,'Burnpur','IND','West Bengali',174933),(1176,'Anantapur','IND','Andhra Pradesh',174924),(1177,'Allappuzha (Alleppey)','IND','Kerala',174666),(1178,'Tirupati','IND','Andhra Pradesh',174369),(1179,'Karnal','IND','Haryana',173751),(1180,'Burhanpur','IND','Madhya Pradesh',172710),(1181,'Hisar (Hissar)','IND','Haryana',172677),(1182,'Tiruvottiyur','IND','Tamil Nadu',172562),(1183,'Mirzapur-cum-Vindhyachal','IND','Uttar Pradesh',169336),(1184,'Secunderabad','IND','Andhra Pradesh',167461),(1185,'Nadiad','IND','Gujarat',167051),(1186,'Dewas','IND','Madhya Pradesh',164364),(1187,'Murwara (Katni)','IND','Madhya Pradesh',163431),(1188,'Ganganagar','IND','Rajasthan',161482),(1189,'Vizianagaram','IND','Andhra Pradesh',160359),(1190,'Erode','IND','Tamil Nadu',159232),(1191,'Machilipatnam (Masulipatam)','IND','Andhra Pradesh',159110),(1192,'Bhatinda (Bathinda)','IND','Punjab',159042),(1193,'Raichur','IND','Karnataka',157551),(1194,'Agartala','IND','Tripura',157358),(1195,'Arrah (Ara)','IND','Bihar',157082),(1196,'Satna','IND','Madhya Pradesh',156630),(1197,'Lalbahadur Nagar','IND','Andhra Pradesh',155500),(1198,'Aizawl','IND','Mizoram',155240),(1199,'Uluberia','IND','West Bengali',155172),(1200,'Katihar','IND','Bihar',154367),(1201,'Cuddalore','IND','Tamil Nadu',153086),(1202,'Hugli-Chinsurah','IND','West Bengali',151806),(1203,'Dhanbad','IND','Jharkhand',151789),(1204,'Raiganj','IND','West Bengali',151045),(1205,'Sambhal','IND','Uttar Pradesh',150869),(1206,'Durg','IND','Chhatisgarh',150645),(1207,'Munger (Monghyr)','IND','Bihar',150112),(1208,'Kanchipuram','IND','Tamil Nadu',150100),(1209,'North Dum Dum','IND','West Bengali',149965),(1210,'Karimnagar','IND','Andhra Pradesh',148583),(1211,'Bharatpur','IND','Rajasthan',148519),(1212,'Sikar','IND','Rajasthan',148272),(1213,'Hardwar (Haridwar)','IND','Uttaranchal',147305),(1214,'Dabgram','IND','West Bengali',147217),(1215,'Morena','IND','Madhya Pradesh',147124),(1216,'Noida','IND','Uttar Pradesh',146514),(1217,'Hapur','IND','Uttar Pradesh',146262),(1218,'Bhusawal','IND','Maharashtra',145143),(1219,'Khandwa','IND','Madhya Pradesh',145133),(1220,'Yamuna Nagar','IND','Haryana',144346),(1221,'Sonipat (Sonepat)','IND','Haryana',143922),(1222,'Tenali','IND','Andhra Pradesh',143726),(1223,'Raurkela Civil Township','IND','Orissa',140408),(1224,'Kollam (Quilon)','IND','Kerala',139852),(1225,'Kumbakonam','IND','Tamil Nadu',139483),(1226,'Ingraj Bazar (English Bazar)','IND','West Bengali',139204),(1227,'Timkur','IND','Karnataka',138903),(1228,'Amroha','IND','Uttar Pradesh',137061),(1229,'Serampore','IND','West Bengali',137028),(1230,'Chapra','IND','Bihar',136877),(1231,'Pali','IND','Rajasthan',136842),(1232,'Maunath Bhanjan','IND','Uttar Pradesh',136697),(1233,'Adoni','IND','Andhra Pradesh',136182),(1234,'Jaunpur','IND','Uttar Pradesh',136062),(1235,'Tirunelveli','IND','Tamil Nadu',135825),(1236,'Bahraich','IND','Uttar Pradesh',135400),(1237,'Gadag Betigeri','IND','Karnataka',134051),(1238,'Proddatur','IND','Andhra Pradesh',133914),(1239,'Chittoor','IND','Andhra Pradesh',133462),(1240,'Barrackpur','IND','West Bengali',133265),(1241,'Bharuch (Broach)','IND','Gujarat',133102),(1242,'Naihati','IND','West Bengali',132701),(1243,'Shillong','IND','Meghalaya',131719),(1244,'Sambalpur','IND','Orissa',131138),(1245,'Junagadh','IND','Gujarat',130484),(1246,'Rae Bareli','IND','Uttar Pradesh',129904),(1247,'Rewa','IND','Madhya Pradesh',128981),(1248,'Gurgaon','IND','Haryana',128608),(1249,'Khammam','IND','Andhra Pradesh',127992),(1250,'Bulandshahr','IND','Uttar Pradesh',127201),(1251,'Navsari','IND','Gujarat',126089),(1252,'Malkajgiri','IND','Andhra Pradesh',126066),(1253,'Midnapore (Medinipur)','IND','West Bengali',125498),(1254,'Miraj','IND','Maharashtra',125407),(1255,'Raj Nandgaon','IND','Chhatisgarh',125371),(1256,'Alandur','IND','Tamil Nadu',125244),(1257,'Puri','IND','Orissa',125199),(1258,'Navadwip','IND','West Bengali',125037),(1259,'Sirsa','IND','Haryana',125000),(1260,'Korba','IND','Chhatisgarh',124501),(1261,'Faizabad','IND','Uttar Pradesh',124437),(1262,'Etawah','IND','Uttar Pradesh',124072),(1263,'Pathankot','IND','Punjab',123930),(1264,'Gandhinagar','IND','Gujarat',123359),(1265,'Palghat (Palakkad)','IND','Kerala',123289),(1266,'Veraval','IND','Gujarat',123000),(1267,'Hoshiarpur','IND','Punjab',122705),(1268,'Ambala','IND','Haryana',122596),(1269,'Sitapur','IND','Uttar Pradesh',121842),(1270,'Bhiwani','IND','Haryana',121629),(1271,'Cuddapah','IND','Andhra Pradesh',121463),(1272,'Bhimavaram','IND','Andhra Pradesh',121314),(1273,'Krishnanagar','IND','West Bengali',121110),(1274,'Chandannagar','IND','West Bengali',120378),(1275,'Mandya','IND','Karnataka',120265),(1276,'Dibrugarh','IND','Assam',120127),(1277,'Nandyal','IND','Andhra Pradesh',119813),(1278,'Balurghat','IND','West Bengali',119796),(1279,'Neyveli','IND','Tamil Nadu',118080),(1280,'Fatehpur','IND','Uttar Pradesh',117675),(1281,'Mahbubnagar','IND','Andhra Pradesh',116833),(1282,'Budaun','IND','Uttar Pradesh',116695),(1283,'Porbandar','IND','Gujarat',116671),(1284,'Silchar','IND','Assam',115483),(1285,'Berhampore (Baharampur)','IND','West Bengali',115144),(1286,'Purnea (Purnia)','IND','Jharkhand',114912),(1287,'Bankura','IND','West Bengali',114876),(1288,'Rajapalaiyam','IND','Tamil Nadu',114202),(1289,'Titagarh','IND','West Bengali',114085),(1290,'Halisahar','IND','West Bengali',114028),(1291,'Hathras','IND','Uttar Pradesh',113285),(1292,'Bhir (Bid)','IND','Maharashtra',112434),(1293,'Pallavaram','IND','Tamil Nadu',111866),(1294,'Anand','IND','Gujarat',110266),(1295,'Mango','IND','Jharkhand',110024),(1296,'Santipur','IND','West Bengali',109956),(1297,'Bhind','IND','Madhya Pradesh',109755),(1298,'Gondiya','IND','Maharashtra',109470),(1299,'Tiruvannamalai','IND','Tamil Nadu',109196),(1300,'Yeotmal (Yavatmal)','IND','Maharashtra',108578),(1301,'Kulti-Barakar','IND','West Bengali',108518),(1302,'Moga','IND','Punjab',108304),(1303,'Shivapuri','IND','Madhya Pradesh',108277),(1304,'Bidar','IND','Karnataka',108016),(1305,'Guntakal','IND','Andhra Pradesh',107592),(1306,'Unnao','IND','Uttar Pradesh',107425),(1307,'Barasat','IND','West Bengali',107365),(1308,'Tambaram','IND','Tamil Nadu',107187),(1309,'Abohar','IND','Punjab',107163),(1310,'Pilibhit','IND','Uttar Pradesh',106605),(1311,'Valparai','IND','Tamil Nadu',106523),(1312,'Gonda','IND','Uttar Pradesh',106078),(1313,'Surendranagar','IND','Gujarat',105973),(1314,'Qutubullapur','IND','Andhra Pradesh',105380),(1315,'Beawar','IND','Rajasthan',105363),(1316,'Hindupur','IND','Andhra Pradesh',104651),(1317,'Gandhidham','IND','Gujarat',104585),(1318,'Haldwani-cum-Kathgodam','IND','Uttaranchal',104195),(1319,'Tellicherry (Thalassery)','IND','Kerala',103579),(1320,'Wardha','IND','Maharashtra',102985),(1321,'Rishra','IND','West Bengali',102649),(1322,'Bhuj','IND','Gujarat',102176),(1323,'Modinagar','IND','Uttar Pradesh',101660),(1324,'Gudivada','IND','Andhra Pradesh',101656),(1325,'Basirhat','IND','West Bengali',101409),(1326,'Uttarpara-Kotrung','IND','West Bengali',100867),(1327,'Ongole','IND','Andhra Pradesh',100836),(1328,'North Barrackpur','IND','West Bengali',100513),(1329,'Guna','IND','Madhya Pradesh',100490),(1330,'Haldia','IND','West Bengali',100347),(1331,'Habra','IND','West Bengali',100223),(1332,'Kanchrapara','IND','West Bengali',100194),(1333,'Tonk','IND','Rajasthan',100079),(1334,'Champdani','IND','West Bengali',98818),(1335,'Orai','IND','Uttar Pradesh',98640),(1336,'Pudukkottai','IND','Tamil Nadu',98619),(1337,'Sasaram','IND','Bihar',98220),(1338,'Hazaribag','IND','Jharkhand',97712),(1339,'Palayankottai','IND','Tamil Nadu',97662),(1340,'Banda','IND','Uttar Pradesh',97227),(1341,'Godhra','IND','Gujarat',96813),(1342,'Hospet','IND','Karnataka',96322),(1343,'Ashoknagar-Kalyangarh','IND','West Bengali',96315),(1344,'Achalpur','IND','Maharashtra',96216),(1345,'Patan','IND','Gujarat',96109),(1346,'Mandasor','IND','Madhya Pradesh',95758),(1347,'Damoh','IND','Madhya Pradesh',95661),(1348,'Satara','IND','Maharashtra',95133),(1349,'Meerut Cantonment','IND','Uttar Pradesh',94876),(1350,'Dehri','IND','Bihar',94526),(1351,'Delhi Cantonment','IND','Delhi',94326),(1352,'Chhindwara','IND','Madhya Pradesh',93731),(1353,'Bansberia','IND','West Bengali',93447),(1354,'Nagaon','IND','Assam',93350),(1355,'Kanpur Cantonment','IND','Uttar Pradesh',93109),(1356,'Vidisha','IND','Madhya Pradesh',92917),(1357,'Bettiah','IND','Bihar',92583),(1358,'Purulia','IND','Jharkhand',92574),(1359,'Hassan','IND','Karnataka',90803),(1360,'Ambala Sadar','IND','Haryana',90712),(1361,'Baidyabati','IND','West Bengali',90601),(1362,'Morvi','IND','Gujarat',90357),(1363,'Raigarh','IND','Chhatisgarh',89166),(1364,'Vejalpur','IND','Gujarat',89053);
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `ID` int(11) NOT NULL default '0',
  `Name` char(35) NOT NULL default ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1024,'Mumbai (Bombay)'),(1025,'Delhi'),(1026,'Calcutta [Kolkata]'),(1027,'Chennai (Madras)'),(1028,'Hyderabad'),(1029,'Ahmedabad'),(1030,'Bangalore'),(1031,'Kanpur'),(1032,'Nagpur'),(1033,'Lucknow'),(1034,'Pune'),(1035,'Surat'),(1036,'Jaipur'),(1037,'Indore'),(1038,'Bhopal'),(1039,'Ludhiana'),(1040,'Vadodara (Baroda)'),(1041,'Kalyan'),(1042,'Madurai'),(1043,'Haora (Howrah)'),(1044,'Varanasi (Benares)'),(1045,'Patna'),(1046,'Srinagar'),(1047,'Agra'),(1048,'Coimbatore'),(1049,'Thane (Thana)'),(1050,'Allahabad'),(1051,'Meerut'),(1052,'Vishakhapatnam'),(1053,'Jabalpur'),(1054,'Amritsar'),(1055,'Faridabad'),(1056,'Vijayawada'),(1057,'Gwalior'),(1058,'Jodhpur'),(1059,'Nashik (Nasik)'),(1060,'Hubli-Dharwad'),(1061,'Solapur (Sholapur)'),(1062,'Ranchi'),(1063,'Bareilly'),(1064,'Guwahati (Gauhati)'),(1065,'Shambajinagar (Aurangabad)'),(1066,'Cochin (Kochi)'),(1067,'Rajkot'),(1068,'Kota'),(1069,'Thiruvananthapuram (Trivandrum'),(1070,'Pimpri-Chinchwad'),(1071,'Jalandhar (Jullundur)'),(1072,'Gorakhpur'),(1073,'Chandigarh'),(1074,'Mysore'),(1075,'Aligarh'),(1076,'Guntur'),(1077,'Jamshedpur'),(1078,'Ghaziabad'),(1079,'Warangal'),(1080,'Raipur'),(1081,'Moradabad'),(1082,'Durgapur'),(1083,'Amravati'),(1084,'Calicut (Kozhikode)'),(1085,'Bikaner'),(1086,'Bhubaneswar'),(1087,'Kolhapur'),(1088,'Kataka (Cuttack)'),(1089,'Ajmer'),(1090,'Bhavnagar'),(1091,'Tiruchirapalli'),(1092,'Bhilai'),(1093,'Bhiwandi'),(1094,'Saharanpur'),(1095,'Ulhasnagar'),(1096,'Salem'),(1097,'Ujjain'),(1098,'Malegaon'),(1099,'Jamnagar'),(1100,'Bokaro Steel City'),(1101,'Akola'),(1102,'Belgaum'),(1103,'Rajahmundry'),(1104,'Nellore'),(1105,'Udaipur'),(1106,'New Bombay'),(1107,'Bhatpara'),(1108,'Gulbarga'),(1109,'New Delhi'),(1110,'Jhansi'),(1111,'Gaya'),(1112,'Kakinada'),(1113,'Dhule (Dhulia)'),(1114,'Panihati'),(1115,'Nanded (Nander)'),(1116,'Mangalore'),(1117,'Dehra Dun'),(1118,'Kamarhati'),(1119,'Davangere'),(1120,'Asansol'),(1121,'Bhagalpur'),(1122,'Bellary'),(1123,'Barddhaman (Burdwan)'),(1124,'Rampur'),(1125,'Jalgaon'),(1126,'Muzaffarpur'),(1127,'Nizamabad'),(1128,'Muzaffarnagar'),(1129,'Patiala'),(1130,'Shahjahanpur'),(1131,'Kurnool'),(1132,'Tiruppur (Tirupper)'),(1133,'Rohtak'),(1134,'South Dum Dum'),(1135,'Mathura'),(1136,'Chandrapur'),(1137,'Barahanagar (Baranagar)'),(1138,'Darbhanga'),(1139,'Siliguri (Shiliguri)'),(1140,'Raurkela'),(1141,'Ambattur'),(1142,'Panipat'),(1143,'Firozabad'),(1144,'Ichalkaranji'),(1145,'Jammu'),(1146,'Ramagundam'),(1147,'Eluru'),(1148,'Brahmapur'),(1149,'Alwar'),(1150,'Pondicherry'),(1151,'Thanjavur'),(1152,'Bihar Sharif'),(1153,'Tuticorin'),(1154,'Imphal'),(1155,'Latur'),(1156,'Sagar'),(1157,'Farrukhabad-cum-Fatehgarh'),(1158,'Sangli'),(1159,'Parbhani'),(1160,'Nagar Coil'),(1161,'Bijapur'),(1162,'Kukatpalle'),(1163,'Bally'),(1164,'Bhilwara'),(1165,'Ratlam'),(1166,'Avadi'),(1167,'Dindigul'),(1168,'Ahmadnagar'),(1169,'Bilaspur'),(1170,'Shimoga'),(1171,'Kharagpur'),(1172,'Mira Bhayandar'),(1173,'Vellore'),(1174,'Jalna'),(1175,'Burnpur'),(1176,'Anantapur'),(1177,'Allappuzha (Alleppey)'),(1178,'Tirupati'),(1179,'Karnal'),(1180,'Burhanpur'),(1181,'Hisar (Hissar)'),(1182,'Tiruvottiyur'),(1183,'Mirzapur-cum-Vindhyachal'),(1184,'Secunderabad'),(1185,'Nadiad'),(1186,'Dewas'),(1187,'Murwara (Katni)'),(1188,'Ganganagar'),(1189,'Vizianagaram'),(1190,'Erode'),(1191,'Machilipatnam (Masulipatam)'),(1192,'Bhatinda (Bathinda)'),(1193,'Raichur'),(1194,'Agartala'),(1195,'Arrah (Ara)'),(1196,'Satna'),(1197,'Lalbahadur Nagar'),(1198,'Aizawl'),(1199,'Uluberia'),(1200,'Katihar'),(1201,'Cuddalore'),(1202,'Hugli-Chinsurah'),(1203,'Dhanbad'),(1204,'Raiganj'),(1205,'Sambhal'),(1206,'Durg'),(1207,'Munger (Monghyr)'),(1208,'Kanchipuram'),(1209,'North Dum Dum'),(1210,'Karimnagar'),(1211,'Bharatpur'),(1212,'Sikar'),(1213,'Hardwar (Haridwar)'),(1214,'Dabgram'),(1215,'Morena'),(1216,'Noida'),(1217,'Hapur'),(1218,'Bhusawal'),(1219,'Khandwa'),(1220,'Yamuna Nagar'),(1221,'Sonipat (Sonepat)'),(1222,'Tenali'),(1223,'Raurkela Civil Township'),(1224,'Kollam (Quilon)'),(1225,'Kumbakonam'),(1226,'Ingraj Bazar (English Bazar)'),(1227,'Timkur'),(1228,'Amroha'),(1229,'Serampore'),(1230,'Chapra'),(1231,'Pali'),(1232,'Maunath Bhanjan'),(1233,'Adoni'),(1234,'Jaunpur'),(1235,'Tirunelveli'),(1236,'Bahraich'),(1237,'Gadag Betigeri'),(1238,'Proddatur'),(1239,'Chittoor'),(1240,'Barrackpur'),(1241,'Bharuch (Broach)'),(1242,'Naihati'),(1243,'Shillong'),(1244,'Sambalpur'),(1245,'Junagadh'),(1246,'Rae Bareli'),(1247,'Rewa'),(1248,'Gurgaon'),(1249,'Khammam'),(1250,'Bulandshahr'),(1251,'Navsari'),(1252,'Malkajgiri'),(1253,'Midnapore (Medinipur)'),(1254,'Miraj'),(1255,'Raj Nandgaon'),(1256,'Alandur'),(1257,'Puri'),(1258,'Navadwip'),(1259,'Sirsa'),(1260,'Korba'),(1261,'Faizabad'),(1262,'Etawah'),(1263,'Pathankot'),(1264,'Gandhinagar'),(1265,'Palghat (Palakkad)'),(1266,'Veraval'),(1267,'Hoshiarpur'),(1268,'Ambala'),(1269,'Sitapur'),(1270,'Bhiwani'),(1271,'Cuddapah'),(1272,'Bhimavaram'),(1273,'Krishnanagar'),(1274,'Chandannagar'),(1275,'Mandya'),(1276,'Dibrugarh'),(1277,'Nandyal'),(1278,'Balurghat'),(1279,'Neyveli'),(1280,'Fatehpur'),(1281,'Mahbubnagar'),(1282,'Budaun'),(1283,'Porbandar'),(1284,'Silchar'),(1285,'Berhampore (Baharampur)'),(1286,'Purnea (Purnia)'),(1287,'Bankura'),(1288,'Rajapalaiyam'),(1289,'Titagarh'),(1290,'Halisahar'),(1291,'Hathras'),(1292,'Bhir (Bid)'),(1293,'Pallavaram'),(1294,'Anand'),(1295,'Mango'),(1296,'Santipur'),(1297,'Bhind'),(1298,'Gondiya'),(1299,'Tiruvannamalai'),(1300,'Yeotmal (Yavatmal)'),(1301,'Kulti-Barakar'),(1302,'Moga'),(1303,'Shivapuri'),(1304,'Bidar'),(1305,'Guntakal'),(1306,'Unnao'),(1307,'Barasat'),(1308,'Tambaram'),(1309,'Abohar'),(1310,'Pilibhit'),(1311,'Valparai'),(1312,'Gonda'),(1313,'Surendranagar'),(1314,'Qutubullapur'),(1315,'Beawar'),(1316,'Hindupur'),(1317,'Gandhidham'),(1318,'Haldwani-cum-Kathgodam'),(1319,'Tellicherry (Thalassery)'),(1320,'Wardha'),(1321,'Rishra'),(1322,'Bhuj'),(1323,'Modinagar'),(1324,'Gudivada'),(1325,'Basirhat'),(1326,'Uttarpara-Kotrung'),(1327,'Ongole'),(1328,'North Barrackpur'),(1329,'Guna'),(1330,'Haldia'),(1331,'Habra'),(1332,'Kanchrapara'),(1333,'Tonk'),(1334,'Champdani'),(1335,'Orai'),(1336,'Pudukkottai'),(1337,'Sasaram'),(1338,'Hazaribag'),(1339,'Palayankottai'),(1340,'Banda'),(1341,'Godhra'),(1342,'Hospet'),(1343,'Ashoknagar-Kalyangarh'),(1344,'Achalpur'),(1345,'Patan'),(1346,'Mandasor'),(1347,'Damoh'),(1348,'Satara'),(1349,'Meerut Cantonment'),(1350,'Dehri'),(1351,'Delhi Cantonment'),(1352,'Chhindwara'),(1353,'Bansberia'),(1354,'Nagaon'),(1355,'Kanpur Cantonment'),(1356,'Vidisha'),(1357,'Bettiah'),(1358,'Purulia'),(1359,'Hassan'),(1360,'Ambala Sadar'),(1361,'Baidyabati'),(1362,'Morvi'),(1363,'Raigarh'),(1364,'Vejalpur');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL auto_increment,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email_address` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_text`
--

DROP TABLE IF EXISTS `my_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_text` (
  `abc` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_text`
--

LOCK TABLES `my_text` WRITE;
/*!40000 ALTER TABLE `my_text` DISABLE KEYS */;
INSERT INTO `my_text` VALUES ('[\"a\":10]'),('[\"id\":10,\"name\":abhi]');
/*!40000 ALTER TABLE `my_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `name` varchar(20) default NULL,
  `id` varchar(20) default NULL,
  `species` varchar(20) default NULL,
  `sex` char(1) default NULL,
  `birth` date default NULL,
  `death` date default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `User_ID` int(11) NOT NULL default '0',
  `User_Name` varchar(100) default NULL,
  `User_Password` varchar(100) default NULL,
  `User_Role` varchar(100) default NULL,
  `IS_ACTIVE` varchar(2) default NULL,
  `CREATED_BY` varchar(50) default NULL,
  `CREATED_ON` datetime default NULL,
  `UPDATED_BY` varchar(50) default NULL,
  `UPDATED_ON` datetime default NULL,
  PRIMARY KEY  (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-06 17:38:00
