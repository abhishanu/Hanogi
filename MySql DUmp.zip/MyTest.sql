CREATE DATABASE  IF NOT EXISTS `mytest` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mytest`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: mytest
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `all_games`
--

DROP TABLE IF EXISTS `all_games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `all_games` (
  `game_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `descr` varchar(255) default NULL,
  `game_name` varchar(255) default NULL,
  `points` int(11) default NULL,
  `page_url` varchar(255) default NULL,
  PRIMARY KEY  (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `all_games`
--

LOCK TABLES `all_games` WRITE;
/*!40000 ALTER TABLE `all_games` DISABLE KEYS */;
INSERT INTO `all_games` VALUES (1,'abhi','2019-04-04 17:30:35','abhi','2019-04-04 17:29:50','Select your team rankings','Team Rank.',250,'teamRank'),(2,'abhi','2019-04-04 17:30:35','abhi','2019-04-04 17:29:50','Choose one of the opening pair who score more in patnership.','Best Opening pair of match',25,NULL),(3,'abhi','2019-04-04 17:30:35','abhi','2019-04-04 17:29:50','Select 3 players from match who\'s total will more.','Players fight batsman',60,NULL),(4,'abhi','2019-04-04 17:30:35','abhi','2019-04-04 17:29:50','Select 2 bowlers who will conceed more runs in match.','Worst bowlers.',50,NULL),(5,'abhi','2019-04-04 17:30:35','abhi','2019-04-04 17:29:50','Choose team who will hit most sixes','Most Sixes.',40,NULL),(6,'abhi','2019-04-04 17:30:35','abhi','2019-04-04 17:29:50','Toss','Toss',20,NULL),(7,'abhi','2019-04-04 17:29:50','abhi','2019-04-04 17:29:50','Player who will be the top scorer','Top Scorer batsman.',60,NULL),(8,'abhi','2019-04-04 17:29:50','abhi','2019-04-04 17:29:50','Top scorer run slot winner will be in the range of 10 runs','Top match player score.',25,NULL),(9,'abhi','2019-04-04 17:29:50','abhi','2019-04-04 17:29:50','1st Inning score ,can change upto 1 time before 10 overs','1st Inning Score.',35,NULL);
/*!40000 ALTER TABLE `all_games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batsman_fight_game`
--

DROP TABLE IF EXISTS `batsman_fight_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batsman_fight_game` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `selected_players` text,
  `total_scored_runs` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batsman_fight_game`
--

LOCK TABLES `batsman_fight_game` WRITE;
/*!40000 ALTER TABLE `batsman_fight_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `batsman_fight_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (191);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inning_score`
--

DROP TABLE IF EXISTS `inning_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inning_score` (
  `entry_id` int(11) NOT NULL,
  `actual_runs` int(11) default NULL,
  `change_attempted` int(11) default NULL,
  `choosen_runs` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `user_id` int(11) default NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inning_score`
--

LOCK TABLES `inning_score` WRITE;
/*!40000 ALTER TABLE `inning_score` DISABLE KEYS */;
/*!40000 ALTER TABLE `inning_score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `pin` bigint(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'abhi','12345',0);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `most_sixes_game`
--

DROP TABLE IF EXISTS `most_sixes_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `most_sixes_game` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `team_selected` varchar(255) default NULL,
  `total_scored_runs` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `most_sixes_game`
--

LOCK TABLES `most_sixes_game` WRITE;
/*!40000 ALTER TABLE `most_sixes_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `most_sixes_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_pair`
--

DROP TABLE IF EXISTS `open_pair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_pair` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `selected_team` varchar(255) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_pair`
--

LOCK TABLES `open_pair` WRITE;
/*!40000 ALTER TABLE `open_pair` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_pair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_detail`
--

DROP TABLE IF EXISTS `player_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_detail` (
  `id` int(11) NOT NULL,
  `country` varchar(255) default NULL,
  `image_url` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `player_id` bigint(20) default NULL,
  `playing_role` varchar(255) default NULL,
  `ipl_team` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_detail`
--

LOCK TABLES `player_detail` WRITE;
/*!40000 ALTER TABLE `player_detail` DISABLE KEYS */;
INSERT INTO `player_detail` VALUES (50,'India','https://www.cricapi.com/playerpic/398438.jpg','Mayank Agarwal',398438,'BAT','KXIP'),(51,'India','https://www.cricapi.com/playerpic/528067.jpg','Murugan Ashwin',528067,'BALL','KXIP'),(52,'India','https://www.cricapi.com/playerpic/26421.jpg','Ravichandran Ashwin',26421,'ALL','KXIP'),(53,'West Indies','https://www.cricapi.com/playerpic/51880.jpg','Chris Gayle',51880,'BAT','KXIP'),(54,'Australia','https://www.cricapi.com/playerpic/5961.jpg','Moises Henriques',5961,'ALL','KXIP'),(55,'India','https://www.cricapi.com/playerpic/642525.jpg','Sarfaraz Khan',642525,'BAT','KXIP'),(56,'India','https://www.cricapi.com/playerpic/398506.jpg','Mandeep Singh',398506,'BAT','KXIP'),(57,'South Africa','https://www.cricapi.com/playerpic/321777.jpg','David Miller',321777,'BAT','KXIP'),(58,'India','https://www.cricapi.com/playerpic/481896.jpg','Mohammed Shami',481896,'BALL','KXIP'),(59,'Afghanistan','https://www.cricapi.com/playerpic/974109.jpg','Mujeeb Ur Rahman',974109,'BALL','KXIP'),(60,'India','https://www.cricapi.com/playerpic/398439.jpg','Karun Nair',398439,'BAT','KXIP'),(61,'West Indies','https://www.cricapi.com/playerpic/604302.jpg','Nicholas Pooran',604302,'WK','KXIP'),(62,'India','https://www.cricapi.com/playerpic/422108.jpg','Lokesh Rahul',422108,'BAT','KXIP'),(63,'India','https://www.cricapi.com/playerpic/591650.jpg','Ankit Rajpoot',591650,'BALL','KXIP'),(64,'Australia','https://www.cricapi.com/playerpic/459508.jpg','Andrew Tye',459508,'BALL','KXIP'),(65,'South Africa','https://www.cricapi.com/playerpic/375126.jpg','Hardus Viljoen',375126,'BALL','KXIP'),(66,'India','https://www.cricapi.com/playerpic/604534.jpg','Ankush Bains',604534,'WK','KXIP'),(67,'New Zealand','https://www.cricapi.com/playerpic/277912.jpg','Trent Boult',277912,'BALL','DC'),(68,'India','https://www.cricapi.com/playerpic/28235.jpg','Shikhar Dhawan',28235,'BAT','DC'),(69,'South Africa','https://www.cricapi.com/playerpic/45705.jpg','Colin Ingram',45705,'BAT','DC'),(70,'India','https://www.cricapi.com/playerpic/642519.jpg','Shreyas Iyer',642519,'BAT','DC'),(71,'India','https://www.cricapi.com/playerpic/31107.jpg','Amit Mishra',31107,'BALL','DC'),(72,'South Africa','https://www.cricapi.com/playerpic/439952.jpg','Chris Morris',439952,'ALL','DC'),(73,'New Zealand','https://www.cricapi.com/playerpic/232359.jpg','Colin Munro',232359,'BAT','DC'),(74,'India','https://www.cricapi.com/playerpic/931581.jpg','Rishabh Pant',931581,'WK','DC'),(75,'India','https://www.cricapi.com/playerpic/554691.jpg','Axar Patel',554691,'ALL','DC'),(76,'India','https://www.cricapi.com/playerpic/390481.jpg','Harshal Patel',390481,'BALL','DC'),(77,'South Africa','https://www.cricapi.com/playerpic/550215.jpg','Kagiso Rabada',550215,'BALL','DC'),(78,'India','https://www.cricapi.com/playerpic/236779.jpg','Ishant Sharma',236779,'BALL','DC'),(79,'India','https://www.cricapi.com/playerpic/853259.jpg','Nathu Singh',853259,'BALL','DC'),(80,'India','https://www.cricapi.com/playerpic/447587.jpg','Jayant Yadav',447587,'ALL','DC'),(81,'Australia','https://www.cricapi.com/playerpic/267192.jpg','Steven Smith',267192,'BAT','RR'),(82,'India','https://www.cricapi.com/playerpic/360911.jpg','Varun Aaron',360911,'BALL','RR'),(83,'India','https://www.cricapi.com/playerpic/27223.jpg','Stuart Binny',27223,'ALL','RR'),(84,'England','https://www.cricapi.com/playerpic/308967.jpg','Jos Buttler',308967,'WK','RR'),(85,'India','https://www.cricapi.com/playerpic/344580.jpg','Shreyas Gopal',344580,'BALL','RR'),(86,'India','https://www.cricapi.com/playerpic/424377.jpg','Krishnappa Gowtham',424377,'ALL','RR'),(87,'India','https://www.cricapi.com/playerpic/277955.jpg','Dhawal Kulkarni',277955,'BALL','RR'),(88,'India','https://www.cricapi.com/playerpic/853265.jpg','Mahipal Lomror',853265,'ALL','RR'),(89,'India','https://www.cricapi.com/playerpic/277916.jpg','Ajinkya Rahane',277916,'BAT','RR'),(90,'India','https://www.cricapi.com/playerpic/425943.jpg','Sanju Samson',425943,'WK','RR'),(91,'New Zealand','https://www.cricapi.com/playerpic/559066.jpg','Ish Sodhi',559066,'BALL','RR'),(92,'England','https://www.cricapi.com/playerpic/311158.jpg','Ben Stokes',311158,'ALL','RR'),(93,'West Indies','https://www.cricapi.com/playerpic/914567.jpg','Oshane Thomas',914567,'BALL','RR'),(94,'India','https://www.cricapi.com/playerpic/390484.jpg','Jaydev Unadkat',390484,'BALL','RR'),(95,'India','https://www.cricapi.com/playerpic/532856.jpg','Manan Vohra',532856,'BAT','RCB'),(96,'India','https://www.cricapi.com/playerpic/253802.jpg','Virat Kohli',253802,'BAT','RCB'),(97,'India','https://www.cricapi.com/playerpic/500360.jpg','Akshdeep Nath',500360,'BAT','RCB'),(98,'England','https://www.cricapi.com/playerpic/8917.jpg','Moeen Ali',8917,'ALL','RCB'),(99,'India','https://www.cricapi.com/playerpic/430246.jpg','Yuzvendra Chahal',430246,'BALL','RCB'),(100,'Australia','https://www.cricapi.com/playerpic/261354.jpg','Nathan Coulter-Nile',261354,'BALL','RCB'),(101,'New Zealand','https://www.cricapi.com/playerpic/55395.jpg','Colin de Grandhomme',55395,'ALL','RCB'),(102,'South Africa','https://www.cricapi.com/playerpic/44936.jpg','AB de Villiers',44936,'BAT','RCB'),(103,'India','https://www.cricapi.com/playerpic/537124.jpg','Gurkeerat Singh Mann',537124,'BAT','RCB'),(104,'West Indies','https://www.cricapi.com/playerpic/670025.jpg','Shimron Hetmyer',670025,'BAT','RCB'),(105,'South Africa','https://www.cricapi.com/playerpic/436757.jpg','Heinrich Klaasen',436757,'WK','RCB'),(106,'India','https://www.cricapi.com/playerpic/940973.jpg','Mohammed Siraj',940973,'BALL','RCB'),(107,'India','https://www.cricapi.com/playerpic/530773.jpg','Pawan Negi',530773,'ALL','RCB'),(108,'India','https://www.cricapi.com/playerpic/32242.jpg','Parthiv Patel',32242,'WK','RCB'),(109,'New Zealand','https://www.cricapi.com/playerpic/232364.jpg','Tim Southee',232364,'BALL','RCB'),(110,'Australia','https://www.cricapi.com/playerpic/325012.jpg','Marcus Stoinis',325012,'ALL','RCB'),(111,'India','https://www.cricapi.com/playerpic/719715.jpg','Washington Sundar',719715,'ALL','RCB'),(112,'India','https://www.cricapi.com/playerpic/376116.jpg','Umesh Yadav',376116,'BALL','RCB'),(113,'India','https://www.cricapi.com/playerpic/34102.jpg','Rohit Sharma',34102,'BAT','MI'),(114,'Australia','https://www.cricapi.com/playerpic/272477.jpg','Jason Behrendorff',272477,'BALL','MI'),(115,'India','https://www.cricapi.com/playerpic/625383.jpg','Jasprit Bumrah',625383,'BALL','MI'),(116,'Australia','https://www.cricapi.com/playerpic/230371.jpg','Ben Cutting',230371,'ALL','MI'),(117,'South Africa','https://www.cricapi.com/playerpic/379143.jpg','Quinton de Kock',379143,'WK','MI'),(118,'India','https://www.cricapi.com/playerpic/720471.jpg','Ishan Kishan',720471,'WK','MI'),(119,'India','https://www.cricapi.com/playerpic/422342.jpg','Siddhesh Lad',422342,'BAT','MI'),(120,'West Indies','https://www.cricapi.com/playerpic/431901.jpg','Evin Lewis',431901,'BAT','MI'),(121,'New Zealand','https://www.cricapi.com/playerpic/319439.jpg','Mitchell McClenaghan',319439,'BALL','MI'),(122,'Sri Lanka','https://www.cricapi.com/playerpic/49758.jpg','Lasith Malinga',49758,'BALL','MI'),(123,'New Zealand','https://www.cricapi.com/playerpic/450860.jpg','Adam Milne',450860,'BALL','MI'),(124,'India','https://www.cricapi.com/playerpic/625371.jpg','Hardik Pandya',625371,'ALL','MI'),(125,'India','https://www.cricapi.com/playerpic/471342.jpg','Krunal Pandya',471342,'ALL','MI'),(126,'West Indies','https://www.cricapi.com/playerpic/230559.jpg','Kieron Pollard',230559,'ALL','MI'),(127,'India','https://www.cricapi.com/playerpic/537126.jpg','Barinder Sran',537126,'BALL','MI'),(128,'India','https://www.cricapi.com/playerpic/333904.jpg','Aditya Tare',333904,'WK','MI'),(129,'India','https://www.cricapi.com/playerpic/446507.jpg','Suryakumar Yadav',446507,'BAT','MI'),(130,'India','https://www.cricapi.com/playerpic/36084.jpg','Yuvraj Singh',36084,'BAT','MI'),(131,'India','https://www.cricapi.com/playerpic/28081.jpg','MS Dhoni',28081,'WK','CSK'),(132,'England','https://www.cricapi.com/playerpic/297628.jpg','Sam Billings',297628,'BAT','CSK'),(133,'West Indies','https://www.cricapi.com/playerpic/51439.jpg','Dwayne Bravo',51439,'ALL','CSK'),(134,'India','https://www.cricapi.com/playerpic/447261.jpg','Deepak Chahar',447261,'BALL','CSK'),(135,'South Africa','https://www.cricapi.com/playerpic/44828.jpg','Faf du Plessis',44828,'BAT','CSK'),(136,'India','https://www.cricapi.com/playerpic/29264.jpg','Harbhajan Singh',29264,'BALL','CSK'),(137,'South Africa','https://www.cricapi.com/playerpic/40618.jpg','Imran Tahir',40618,'BALL','CSK'),(138,'India','https://www.cricapi.com/playerpic/234675.jpg','Ravindra Jadeja',234675,'ALL','CSK'),(139,'India','https://www.cricapi.com/playerpic/290716.jpg','Kedar Jadhav',290716,'BAT','CSK'),(140,'India','https://www.cricapi.com/playerpic/33335.jpg','Suresh Raina',33335,'BAT','CSK'),(141,'India','https://www.cricapi.com/playerpic/33141.jpg','Ambati Rayudu',33141,'BAT','CSK'),(142,'New Zealand','https://www.cricapi.com/playerpic/502714.jpg','Mitchell Santner',502714,'ALL','CSK'),(143,'India','https://www.cricapi.com/playerpic/30288.jpg','Karn Sharma',30288,'BALL','CSK'),(144,'India','https://www.cricapi.com/playerpic/537119.jpg','Mohit Sharma',537119,'BALL','CSK'),(145,'India','https://www.cricapi.com/playerpic/475281.jpg','Shardul Thakur',475281,'BALL','CSK'),(146,'India','https://www.cricapi.com/playerpic/237095.jpg','Murali Vijay',237095,'BAT','CSK'),(147,'Australia','https://www.cricapi.com/playerpic/8180.jpg','Shane Watson',8180,'BAT','CSK'),(148,'England','https://www.cricapi.com/playerpic/308251.jpg','David Willey',308251,'BALL','CSK'),(149,'Australia','https://www.cricapi.com/playerpic/219889.jpg','David Warner',219889,'BAT','SRH'),(150,'India','https://www.cricapi.com/playerpic/942645.jpg','Khaleel Ahmed',942645,'BALL','SRH'),(151,'England','https://www.cricapi.com/playerpic/297433.jpg','Jonny Bairstow',297433,'WK','SRH'),(152,'India','https://www.cricapi.com/playerpic/732291.jpg','Basil Thampi',732291,'BALL','SRH'),(153,'India','https://www.cricapi.com/playerpic/642531.jpg','Ricky Bhui',642531,'BAT','SRH'),(154,'India','https://www.cricapi.com/playerpic/302579.jpg','Shreevats Goswami',302579,'WK','SRH'),(155,'New Zealand','https://www.cricapi.com/playerpic/226492.jpg','Martin Guptill',226492,'BAT','SRH'),(156,'India','https://www.cricapi.com/playerpic/497121.jpg','Deepak Hooda',497121,'ALL','SRH'),(157,'India','https://www.cricapi.com/playerpic/326017.jpg','Siddarth Kaul',326017,'BALL','SRH'),(158,'India','https://www.cricapi.com/playerpic/326016.jpg','Bhuvneshwar Kumar',326016,'BALL','SRH'),(159,'Afghanistan','https://www.cricapi.com/playerpic/25913.jpg','Mohammad Nabi',25913,'ALL','SRH'),(160,'India','https://www.cricapi.com/playerpic/31872.jpg','Shahbaz Nadeem',31872,'BALL','SRH'),(161,'India','https://www.cricapi.com/playerpic/290630.jpg','Manish Pandey',290630,'BAT','SRH'),(162,'India','https://www.cricapi.com/playerpic/32498.jpg','Yusuf Pathan',32498,'BAT','SRH'),(163,'Afghanistan','https://www.cricapi.com/playerpic/793463.jpg','Rashid Khan',793463,'BALL','SRH'),(164,'India','https://www.cricapi.com/playerpic/279810.jpg','Wriddhiman Saha',279810,'WK','SRH'),(165,'India','https://www.cricapi.com/playerpic/438362.jpg','Sandeep Sharma',438362,'BALL','SRH'),(166,'India','https://www.cricapi.com/playerpic/477021.jpg','Vijay Shankar',477021,'ALL','SRH'),(167,'Bangladesh','https://www.cricapi.com/playerpic/56143.jpg','Shakib Al Hasan',56143,'ALL','SRH'),(168,'New Zealand','https://www.cricapi.com/playerpic/277906.jpg','Kane Williamson',277906,'BAT','SRH'),(169,'India','https://www.cricapi.com/playerpic/30045.jpg','Dinesh Karthik',30045,'WK','KKR'),(170,'West Indies','https://www.cricapi.com/playerpic/457249.jpg','Carlos Brathwaite',457249,'ALL','KKR'),(171,'India','https://www.cricapi.com/playerpic/32966.jpg','Piyush Chawla',32966,'BALL','KKR'),(172,'England','https://www.cricapi.com/playerpic/12454.jpg','Joe Denly',12454,'ALL','KKR'),(173,'England','https://www.cricapi.com/playerpic/244639.jpg','Harry Gurney',244639,'BALL','KKR'),(174,'India','https://www.cricapi.com/playerpic/559235.jpg','Kuldeep Yadav',559235,'BALL','KKR'),(175,'Australia','https://www.cricapi.com/playerpic/326637.jpg','Chris Lynn',326637,'BAT','KKR'),(176,'India','https://www.cricapi.com/playerpic/279862.jpg','Shrikant Mundhe',279862,'ALL','KKR'),(177,'India','https://www.cricapi.com/playerpic/554700.jpg','Nikhil Naik',554700,'WK','KKR'),(178,'West Indies','https://www.cricapi.com/playerpic/230558.jpg','Sunil Narine',230558,'ALL','KKR'),(179,'India','https://www.cricapi.com/playerpic/917159.jpg','Prasidh Krishna',917159,'BALL','KKR'),(180,'India','https://www.cricapi.com/playerpic/604527.jpg','Nitish Rana',604527,'BAT','KKR'),(181,'West Indies','https://www.cricapi.com/playerpic/276298.jpg','Andre Russell',276298,'ALL','KKR'),(182,'India','https://www.cricapi.com/playerpic/35582.jpg','Robin Uthappa',35582,'BAT','KKR'),(183,'India','https://www.cricapi.com/playerpic/802575.jpg','T Natarajan',802575,'BALL','KKR'),(184,'India','https://www.cricapi.com/playerpic/1070183.jpg','Abhishek Sharma',1070183,'BAT','KKR'),(185,'Australia','https://www.cricapi.com/playerpic/533042.jpg','Billy Stanlake',533042,'BALL','KKR'),(186,'India','https://www.cricapi.com/playerpic/1070168.jpg','Prithvi Shaw',1070168,'BAT','KKR'),(187,'India','https://www.cricapi.com/playerpic/237199.jpg','Jalaj Saxena',237199,'BAT','KKR'),(188,'West Indies','https://www.cricapi.com/playerpic/914541.jpg','Sherfane Rutherford',914541,'BAT','KKR'),(189,'West Indies','https://www.cricapi.com/playerpic/677081.jpg','Keemo Paul',677081,'ALL','KKR'),(190,'India','','Manjot Kalra',1079842,'ALL',''),(191,'Nepal','https://www.cricapi.com/playerpic/960361.jpg','Sandeep Lamichhane',960361,'BALL','DC'),(192,'India','https://www.cricapi.com/playerpic/694211.jpg','Avesh Khan',694211,'BALL','DC'),(193,'West Indies','https://www.cricapi.com/playerpic/669855.jpg','Jofra Archer',669855,'BALL','RR'),(194,'India','https://www.cricapi.com/playerpic/1126227.jpg','Aryaman Birla',1126227,'BAT',NULL),(195,'India','https://www.cricapi.com/playerpic/500135.jpg','Prashant Chopra',500135,'BAT',NULL),(196,'England','https://www.cricapi.com/playerpic/403902.jpg','Liam Livingstone',403902,'BAT',NULL),(197,'India','','S Midhun',1131619,'BAT',NULL),(198,'India','https://www.cricapi.com/playerpic/1079434.jpg','Riyan Parag',1079434,'BAT',NULL),(199,'India','https://www.cricapi.com/playerpic/377534.jpg','Shashank Singh',377534,'BAT',NULL),(200,'India','https://www.cricapi.com/playerpic/554701.jpg','Shubham Ranjane',554701,'BAT',NULL),(201,'India','https://www.cricapi.com/playerpic/446763.jpg','Rahul Tripathi',446763,'BAT','RR'),(202,'Australia','https://www.cricapi.com/playerpic/500268.jpg','Ashton Turner',500268,'BAT','RR'),(203,'India','https://www.cricapi.com/playerpic/714451.jpg','Shivam Dubey',714451,'ALL','RCB');
/*!40000 ALTER TABLE `player_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_rank`
--

DROP TABLE IF EXISTS `team_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_rank` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `is_active` bit(1) default NULL,
  `saved_team_order` text,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_rank`
--

LOCK TABLES `team_rank` WRITE;
/*!40000 ALTER TABLE `team_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top_scorer_batsman_game`
--

DROP TABLE IF EXISTS `top_scorer_batsman_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top_scorer_batsman_game` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `player_selected` varchar(255) default NULL,
  `total_scored_runs` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_scorer_batsman_game`
--

LOCK TABLES `top_scorer_batsman_game` WRITE;
/*!40000 ALTER TABLE `top_scorer_batsman_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `top_scorer_batsman_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `toss`
--

DROP TABLE IF EXISTS `toss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toss` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `selected_team` varchar(255) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toss`
--

LOCK TABLES `toss` WRITE;
/*!40000 ALTER TABLE `toss` DISABLE KEYS */;
/*!40000 ALTER TABLE `toss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_game_details`
--

DROP TABLE IF EXISTS `user_game_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_game_details` (
  `details_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `average_points` double NOT NULL,
  `game_id` int(11) default NULL,
  `team_order` text,
  `total_points` bigint(20) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`details_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_game_details`
--

LOCK TABLES `user_game_details` WRITE;
/*!40000 ALTER TABLE `user_game_details` DISABLE KEYS */;
INSERT INTO `user_game_details` VALUES (190,NULL,NULL,NULL,NULL,0,NULL,'[{teamName=CSK, flag=cskFlag, id=1}, {teamName=MI, flag=miFlag, id=4}, {teamName=SRH, flag=srhFlag, id=8}, {teamName=KKR, flag=kkrFlag, id=7}, {teamName=RCB, flag=rcbFlag, id=2}, {teamName=RR, flag=rrFlag, id=6}, {teamName=XIPU, flag=kxpFlag, id=5}, {teamName=DC, flag=dcFlag, id=3}]',0,1);
/*!40000 ALTER TABLE `user_game_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worst_bowler_game`
--

DROP TABLE IF EXISTS `worst_bowler_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worst_bowler_game` (
  `entry_id` int(11) NOT NULL,
  `created_by` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `updated_by` varchar(255) default NULL,
  `updated_on` datetime default NULL,
  `change_attempted` int(11) default NULL,
  `game_id` bigint(20) default NULL,
  `is_active` bit(1) default NULL,
  `selected_players` text,
  `total_conceeded_runs` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worst_bowler_game`
--

LOCK TABLES `worst_bowler_game` WRITE;
/*!40000 ALTER TABLE `worst_bowler_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `worst_bowler_game` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-06 17:37:29
