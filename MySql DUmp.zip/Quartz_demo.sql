CREATE DATABASE  IF NOT EXISTS `quartz_demo_db` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `quartz_demo_db`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: quartz_demo_db
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `qrtzblob_triggers`
--

DROP TABLE IF EXISTS `qrtzblob_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzblob_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY  (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtzblob_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtztriggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzblob_triggers`
--

LOCK TABLES `qrtzblob_triggers` WRITE;
/*!40000 ALTER TABLE `qrtzblob_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtzblob_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzcron_triggers`
--

DROP TABLE IF EXISTS `qrtzcron_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzcron_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `CRON_EXPRESSION` varchar(120) NOT NULL,
  `TIME_ZONE_ID` varchar(80) default NULL,
  PRIMARY KEY  (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtzcron_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtztriggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzcron_triggers`
--

LOCK TABLES `qrtzcron_triggers` WRITE;
/*!40000 ALTER TABLE `qrtzcron_triggers` DISABLE KEYS */;
INSERT INTO `qrtzcron_triggers` VALUES ('quartz-demo-app','Sample Cron','DEFAULT','0/10 * * ? * *','Asia/Calcutta'),('quartz-demo-app','Sample Cron2','DEFAULT','0 0/3 * ? * *','Asia/Calcutta');
/*!40000 ALTER TABLE `qrtzcron_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzfired_triggers`
--

DROP TABLE IF EXISTS `qrtzfired_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzfired_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `ENTRY_ID` varchar(140) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `FIRED_TIME` bigint(19) NOT NULL,
  `SCHED_TIME` bigint(19) NOT NULL,
  `PRIORITY` int(11) NOT NULL,
  `STATE` varchar(16) NOT NULL,
  `JOB_NAME` varchar(200) default NULL,
  `JOB_GROUP` varchar(200) default NULL,
  `IS_NONCONCURRENT` tinyint(1) default NULL,
  `REQUESTS_RECOVERY` tinyint(1) default NULL,
  PRIMARY KEY  (`SCHED_NAME`,`ENTRY_ID`),
  KEY `IDX_QRTZ_FT_TRIG_INST_NAME` (`SCHED_NAME`,`INSTANCE_NAME`),
  KEY `IDX_QRTZ_FT_INST_JOB_REQ_RCVRY` (`SCHED_NAME`,`INSTANCE_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_FT_J_G` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_T_G` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_FT_TG` (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzfired_triggers`
--

LOCK TABLES `qrtzfired_triggers` WRITE;
/*!40000 ALTER TABLE `qrtzfired_triggers` DISABLE KEYS */;
INSERT INTO `qrtzfired_triggers` VALUES ('quartz-demo-app','1705a8db-fe7b-4d78-ba8e-319855b56eb21547040949703','Sample Cron','DEFAULT','1705a8db-fe7b-4d78-ba8e-319855b56eb2',1547040980002,1547040980000,0,'EXECUTING','Sample Cron','Test_Cron',1,0),('quartz-demo-app','1705a8db-fe7b-4d78-ba8e-319855b56eb21547040949704','Sample Cron2','DEFAULT','1705a8db-fe7b-4d78-ba8e-319855b56eb2',1547041140001,1547041140000,0,'EXECUTING','Sample Cron2','Test_Cron2',1,0);
/*!40000 ALTER TABLE `qrtzfired_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzjob_details`
--

DROP TABLE IF EXISTS `qrtzjob_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzjob_details` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) default NULL,
  `JOB_CLASS_NAME` varchar(250) NOT NULL,
  `IS_DURABLE` tinyint(1) NOT NULL,
  `IS_NONCONCURRENT` tinyint(1) NOT NULL,
  `IS_UPDATE_DATA` tinyint(1) NOT NULL,
  `REQUESTS_RECOVERY` tinyint(1) NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY  (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_J_REQ_RECOVERY` (`SCHED_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_J_GRP` (`SCHED_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzjob_details`
--

LOCK TABLES `qrtzjob_details` WRITE;
/*!40000 ALTER TABLE `qrtzjob_details` DISABLE KEYS */;
INSERT INTO `qrtzjob_details` VALUES ('quartz-demo-app','Sample Cron','Test_Cron',NULL,'com.iris.test.QuartzDemo.jobs.SampleCronJob',0,1,0,0,'#\r\n#Tue Dec 18 18:24:21 IST 2018\r\nSample\\ CronTest_Cron=com.iris.test.QuartzDemo.jobs.SampleCronJob\r\n'),('quartz-demo-app','Sample Cron2','Test_Cron2',NULL,'com.iris.test.QuartzDemo.jobs.SampleCronJob',0,1,0,0,'#\r\n#Tue Dec 18 18:34:39 IST 2018\r\nSample\\ Cron2Test_Cron2=com.iris.test.QuartzDemo.jobs.SampleCronJob\r\n');
/*!40000 ALTER TABLE `qrtzjob_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzlocks`
--

DROP TABLE IF EXISTS `qrtzlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzlocks` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `LOCK_NAME` varchar(40) NOT NULL,
  PRIMARY KEY  (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzlocks`
--

LOCK TABLES `qrtzlocks` WRITE;
/*!40000 ALTER TABLE `qrtzlocks` DISABLE KEYS */;
INSERT INTO `qrtzlocks` VALUES ('quartz-demo-app','STATE_ACCESS'),('quartz-demo-app','TRIGGER_ACCESS');
/*!40000 ALTER TABLE `qrtzlocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzpaused_trigger_grps`
--

DROP TABLE IF EXISTS `qrtzpaused_trigger_grps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzpaused_trigger_grps` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  PRIMARY KEY  (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzpaused_trigger_grps`
--

LOCK TABLES `qrtzpaused_trigger_grps` WRITE;
/*!40000 ALTER TABLE `qrtzpaused_trigger_grps` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtzpaused_trigger_grps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzscheduler_state`
--

DROP TABLE IF EXISTS `qrtzscheduler_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzscheduler_state` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `INSTANCE_NAME` varchar(200) NOT NULL,
  `LAST_CHECKIN_TIME` bigint(19) NOT NULL,
  `CHECKIN_INTERVAL` bigint(19) NOT NULL,
  PRIMARY KEY  (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzscheduler_state`
--

LOCK TABLES `qrtzscheduler_state` WRITE;
/*!40000 ALTER TABLE `qrtzscheduler_state` DISABLE KEYS */;
INSERT INTO `qrtzscheduler_state` VALUES ('quartz-demo-app','1705a8db-fe7b-4d78-ba8e-319855b56eb2',1547041250345,7500);
/*!40000 ALTER TABLE `qrtzscheduler_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzsimple_triggers`
--

DROP TABLE IF EXISTS `qrtzsimple_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzsimple_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(10) NOT NULL,
  PRIMARY KEY  (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtzsimple_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtztriggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzsimple_triggers`
--

LOCK TABLES `qrtzsimple_triggers` WRITE;
/*!40000 ALTER TABLE `qrtzsimple_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtzsimple_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtzsimprop_triggers`
--

DROP TABLE IF EXISTS `qrtzsimprop_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtzsimprop_triggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `STR_PROP_1` varchar(512) default NULL,
  `STR_PROP_2` varchar(512) default NULL,
  `STR_PROP_3` varchar(512) default NULL,
  `INT_PROP_1` int(11) default NULL,
  `INT_PROP_2` int(11) default NULL,
  `LONG_PROP_1` bigint(20) default NULL,
  `LONG_PROP_2` bigint(20) default NULL,
  `DEC_PROP_1` decimal(13,4) default NULL,
  `DEC_PROP_2` decimal(13,4) default NULL,
  `BOOL_PROP_1` tinyint(1) default NULL,
  `BOOL_PROP_2` tinyint(1) default NULL,
  `TIME_ZONE_ID` varchar(80) default NULL,
  PRIMARY KEY  (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtzsimprop_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtztriggers` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtzsimprop_triggers`
--

LOCK TABLES `qrtzsimprop_triggers` WRITE;
/*!40000 ALTER TABLE `qrtzsimprop_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `qrtzsimprop_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qrtztriggers`
--

DROP TABLE IF EXISTS `qrtztriggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrtztriggers` (
  `SCHED_NAME` varchar(120) NOT NULL,
  `TRIGGER_NAME` varchar(200) NOT NULL,
  `TRIGGER_GROUP` varchar(200) NOT NULL,
  `JOB_NAME` varchar(200) NOT NULL,
  `JOB_GROUP` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(250) default NULL,
  `NEXT_FIRE_TIME` bigint(19) default NULL,
  `PREV_FIRE_TIME` bigint(19) default NULL,
  `PRIORITY` int(11) default NULL,
  `TRIGGER_STATE` varchar(16) NOT NULL,
  `TRIGGER_TYPE` varchar(8) NOT NULL,
  `START_TIME` bigint(19) NOT NULL,
  `END_TIME` bigint(19) default NULL,
  `CALENDAR_NAME` varchar(200) default NULL,
  `MISFIRE_INSTR` smallint(2) default NULL,
  `JOB_DATA` blob,
  PRIMARY KEY  (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_J` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_C` (`SCHED_NAME`,`CALENDAR_NAME`),
  KEY `IDX_QRTZ_T_G` (`SCHED_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_STATE` (`SCHED_NAME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_STATE` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_G_STATE` (`SCHED_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NEXT_FIRE_TIME` (`SCHED_NAME`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST` (`SCHED_NAME`,`TRIGGER_STATE`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE_GRP` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  CONSTRAINT `qrtztriggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtzjob_details` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qrtztriggers`
--

LOCK TABLES `qrtztriggers` WRITE;
/*!40000 ALTER TABLE `qrtztriggers` DISABLE KEYS */;
INSERT INTO `qrtztriggers` VALUES ('quartz-demo-app','Sample Cron','DEFAULT','Sample Cron','Test_Cron',NULL,1547040990000,1547040980000,0,'BLOCKED','CRON',1545137646000,0,NULL,1,''),('quartz-demo-app','Sample Cron2','DEFAULT','Sample Cron2','Test_Cron2',NULL,1547041320000,1547041140000,0,'BLOCKED','CRON',1545138279000,0,NULL,1,'');
/*!40000 ALTER TABLE `qrtztriggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduler_job_info`
--

DROP TABLE IF EXISTS `scheduler_job_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduler_job_info` (
  `id` bigint(20) NOT NULL auto_increment,
  `cron_expression` varchar(255) default NULL,
  `cron_job` bit(1) default NULL,
  `job_class` varchar(255) default NULL,
  `job_group` varchar(255) default NULL,
  `job_name` varchar(255) default NULL,
  `repeat_time` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduler_job_info`
--

LOCK TABLES `scheduler_job_info` WRITE;
/*!40000 ALTER TABLE `scheduler_job_info` DISABLE KEYS */;
INSERT INTO `scheduler_job_info` VALUES (4,NULL,'\0','com.helixz.quartz.demo.jobs.SimpleJob','Test_Job','Simple Job',600000),(2,'0 0/2 * ? * *','','com.iris.test.QuartzDemo.jobs.SampleCronJob','Test_Cron','Sample Cron',NULL),(1,'0 0/3 * ? * *','','com.iris.test.QuartzDemo.jobs.SampleCronJob','Test_Cron2','Sample Cron2',NULL);
/*!40000 ALTER TABLE `scheduler_job_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-06 17:37:13
