
/* Drop Tables */

DROP TABLE IF EXISTS ACCOUNT_GROUP_MAPPING;
DROP TABLE IF EXISTS DIVISON_ACCOUNT_MAPPING;
DROP TABLE IF EXISTS ACCOUNT;
DROP TABLE IF EXISTS BRANCH;
DROP TABLE IF EXISTS EMPLOYEE_EMAILID_MAPPING;
DROP TABLE IF EXISTS EMPLOYEE_HIRERACHY;
DROP TABLE IF EXISTS EMPLOYEE_ROLE_MAPPING;
DROP TABLE IF EXISTS EMPLOYEE_WORK_UNIT_MAPPING;
DROP TABLE IF EXISTS EMPLOYEE;
DROP TABLE IF EXISTS LEGAL_ENTITY;
DROP TABLE IF EXISTS ADDRESS;
DROP TABLE IF EXISTS GROUP_TEAM_MAPPING;
DROP TABLE IF EXISTS BUSINESS_GROUP;
DROP TABLE IF EXISTS BU_DIVISON_MAPPING;
DROP TABLE IF EXISTS BUSINESS_UNIT;
DROP TABLE IF EXISTS DISTRICT_CITY_MAPPING;
DROP TABLE IF EXISTS GEO_LOCATION;
DROP TABLE IF EXISTS CITY;
DROP TABLE IF EXISTS CLIENT_EMAILID_MAPPING;
DROP TABLE IF EXISTS CLIENT_EMPLOYEE_MAPPING;
DROP TABLE IF EXISTS CLIENT_HIRERACHY;
DROP TABLE IF EXISTS CLIENT_ROLE_MAPPING;
DROP TABLE IF EXISTS CLIENT_WORK_UNIT_MAPPING;
DROP TABLE IF EXISTS CLIENT;
DROP TABLE IF EXISTS CONTINENT_COUNTRY_MAPPING;
DROP TABLE IF EXISTS CONTINENT;
DROP TABLE IF EXISTS COUNTRY_DISTRICT_MAPPING;
DROP TABLE IF EXISTS COUNTRY;
DROP TABLE IF EXISTS DISTRICT;
DROP TABLE IF EXISTS DIVISION;
DROP TABLE IF EXISTS WORK_UNIT_EMAILID_MAPPING;
DROP TABLE IF EXISTS EMAILID;
DROP TABLE IF EXISTS EMAILID_TYPE;
DROP TABLE IF EXISTS ENTITY_TYPE;
DROP TABLE IF EXISTS ROLE;
DROP TABLE IF EXISTS TEAM;
DROP TABLE IF EXISTS WORK_UNITS_TYPES;
DROP TABLE IF EXISTS EMAIL_HEADER;
DROP TABLE IF EXISTS EMAIL_METADATA;
DROP TABLE IF EXISTS AGGREGATED_TONE;
DROP TABLE IF EXISTS CALCULATED_TONE;
DROP TABLE IF EXISTS INDIVIDUAL_TONE;
DROP TABLE IF EXISTS TONE;
DROP TABLE IF EXISTS CLIENT_EMAILID_MAPPING;
DROP TABLE IF EXISTS CLIENT_EMPLOYEE_MAPPING;
DROP TABLE IF EXISTS CLIENT_HIRERACHY;
DROP TABLE IF EXISTS CLIENT_ROLE_MAPPING;
DROP TABLE IF EXISTS CLIENT_WORK_UNIT_MAPPING;
DROP TABLE IF EXISTS CLIENT;



/* Create Tables */

-- Master table for all the Accounts inside a division
CREATE TABLE ACCOUNT
(
	-- It represents the Account Id within a division
	ACCOUNT_ID int NOT NULL,
	-- The  Acoount name
	ACCOUNT_NAME varchar(30) NOT NULL UNIQUE,
	-- The shortcode for the account
	ACCOUNT_CODE varchar(15) NOT NULL UNIQUE,
	-- The description of the account
	ACCOUNT_DESC varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (ACCOUNT_ID)
) WITHOUT OIDS;


CREATE TABLE ACCOUNT_GROUP_MAPPING
(
	-- It represents the Group Id within a account
	GROUP_ID int NOT NULL,
	-- It represents the Account Id within a division
	ACCOUNT_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- This table contains the address details of the actors client/employee/legal entity
CREATE TABLE ADDRESS
(
	-- This is Address id for the address details
	ADDRESS_ID int NOT NULL,
	-- The location details relevant to this address
	LOCATION_ID int NOT NULL,
	-- This contains the address (Building, Street, Locality etc)
	ADDRESS_DETAILS varchar(200) NOT NULL,
	-- The ZIP code of the address
	ZIP_CODE varchar(15) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (ADDRESS_ID)
) WITHOUT OIDS;


-- This table captures the details of all the branches of  legal entity to which the Client/Employee belongs
CREATE TABLE BRANCH
(
	-- This represents the brach office of the legal entity  & is the primary key 
	BRANCH_ID int NOT NULL,
	-- The legal entity to which the branch belongs
	LEGAL_ENTITY_ID int NOT NULL,
	-- The  address to which the legal entity belongs
	ADDRESS_ID int NOT NULL,
	-- The name of the branch
	BRANCH_NAME varchar(100) NOT NULL,
	-- Branch Code
	BRANCH_CODE varchar(15) NOT NULL,
	-- Description about the about
	DESCRITPTION varchar(200),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (BRANCH_ID)
) WITHOUT OIDS;


-- Master table for all the Group inside a Account
CREATE TABLE BUSINESS_GROUP
(
	-- It represents the Group Id within a account
	GROUP_ID int NOT NULL,
	-- The  Group name
	GROUP_NAME varchar(30) NOT NULL UNIQUE,
	-- The shortcode for the Group
	GROUP_CODE varchar(15) NOT NULL UNIQUE,
	-- The description of the group
	GROUP_DESC varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (GROUP_ID)
) WITHOUT OIDS;


-- Master table for all the department for Client/Employee/Legal Entity
CREATE TABLE BUSINESS_UNIT
(
	-- The businees unit 
	BUSINESS_UNIT_ID int NOT NULL,
	-- The name of the business unit
	BUSINESS_UNIT_NAME varchar(20) NOT NULL UNIQUE,
	-- The shortcode for the business unit
	BUSINESS_UNIT_CODE varchar(10) NOT NULL UNIQUE,
	-- The description of the business unit
	BUSINESS_UNIT_DESC varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (BUSINESS_UNIT_ID)
) WITHOUT OIDS;


CREATE TABLE BU_DIVISON_MAPPING
(
	-- The businees unit 
	BUSINESS_UNIT_ID int NOT NULL,
	-- The Divison in the businees unit 
	DIVISION_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- Master table to hold the data for all the city
CREATE TABLE CITY
(
	-- The id for the City
	CITY_ID int NOT NULL,
	-- City Name
	CITY_NAME varchar(20) NOT NULL,
	-- Small Code for the City
	CITY_CODE varchar(10) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CITY_ID)
) WITHOUT OIDS;

-- This table describes the attributes corresponding to the Client.
CREATE TABLE CLIENT
(
	-- ClientId used for internal purpose by the Batch Process
	CLIENT_ID int NOT NULL,
	-- This denotes the first name of the actor
	FIRST_NAME varchar(20) NOT NULL,
	-- Last name of the actor
	LAST_NAME varchar(20) NOT NULL,
	-- Middle name of the actor
	MIDDLE_NAME varchar(20),
	-- The legal entity/office/subsidary in which actor works
	LEGAL_ENTITY_ID int NOT NULL,
	-- The branch office in which the actor works
	WORK_LOCATION_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CLIENT_ID)
) WITHOUT OIDS;


-- Mapping table to represent the mapping of an client to its email ids
CREATE TABLE CLIENT_EMAILID_MAPPING
(
	-- This represents the email id of the actor
	EMAIL_ID varchar(30) NOT NULL,
	-- ClientId used for internal purpose by the Batch Process
	CLIENT_ID int NOT NULL,
	-- Whether to enable the email id for tone analysis
	ANALYSE_TONE char NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- Mapping table for Clients to Employee
CREATE TABLE CLIENT_EMPLOYEE_MAPPING
(
	-- ClientId used for internal purpose by the Batch Process
	CLIENT_ID int NOT NULL,
	-- Employee Id used for internal purpose by the Batch Process
	EMPLOYEE_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CLIENT_ID, EMPLOYEE_ID)
) WITHOUT OIDS;


-- This table will contains the Client Hirerachy to capture the org tree
CREATE TABLE CLIENT_HIRERACHY
(
	-- The id for the hierarchy relationship
	HIERARCHY_ID int NOT NULL,
	-- The employee id of the employee
	CLIENT_ID int NOT NULL,
	-- The employee id of the person to which this person reports
	REPORTS_TO_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (HIERARCHY_ID)
) WITHOUT OIDS;


-- Mapping table for the Client & its Role
CREATE TABLE CLIENT_ROLE_MAPPING
(
	-- ClientId used for internal purpose by the Batch Process
	CLIENT_ID int NOT NULL,
	-- The role id of the role assigned
	ROLE_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CLIENT_ID, ROLE_ID)
) WITHOUT OIDS;


-- This table maps the employee to the work unit at the lowest level. An employee can belong to multiple work uints
CREATE TABLE CLIENT_WORK_UNIT_MAPPING
(
	-- ClientId used for internal purpose by the Batch Process
	CLIENT_ID int NOT NULL,
	-- Type of work unit to which employee belongs - It will be the lowest level in his hirerachy. 
	WORK_UNIT_TYPE_ID int NOT NULL,
	-- The id of the work unit
	WORK_UNIT_ID int,
	-- Whether the employee is owner of this work unit 
	IS_OWNER char NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CLIENT_ID)
) WITHOUT OIDS;


-- Master table to hold the data for all the continents
CREATE TABLE CONTINENT
(
	-- Continent ID
	CONTINENT_ID varchar(20) NOT NULL,
	-- Continent Name
	CONTINENT_NAME varchar(20) NOT NULL,
	-- Small Code for the Continent
	CONTINENT_CODE varchar(10) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CONTINENT_ID)
) WITHOUT OIDS;


CREATE TABLE CONTINENT_COUNTRY_MAPPING
(
	-- Continent ID
	CONTINENT_ID varchar(20) NOT NULL,
	-- The id for the Country
	COUNTRY_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- Master table to hold the data for all the countries
CREATE TABLE COUNTRY
(
	-- The id for the Country
	COUNTRY_ID int NOT NULL,
	-- Country Name
	COUNTRY_NAME varchar(20) NOT NULL,
	-- Small Code for the Country
	COUNTRY_CODE varchar(10) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (COUNTRY_ID)
) WITHOUT OIDS;


-- Country District Mapping table
CREATE TABLE COUNTRY_DISTRICT_MAPPING
(
	-- The id for the Country
	COUNTRY_ID int NOT NULL,
	-- The id for the District
	DISTRICT_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- Master table to hold the data for all the district
CREATE TABLE DISTRICT
(
	-- The id for the District
	DISTRICT_ID int NOT NULL,
	-- District Name
	DISTRICT_NAME varchar(20) NOT NULL,
	-- Small Code for the District
	DISTRICT_CODE varchar(10) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (DISTRICT_ID)
) WITHOUT OIDS;


-- Mapping table for District to City
CREATE TABLE DISTRICT_CITY_MAPPING
(
	-- The id for the District
	DISTRICT_ID int NOT NULL,
	-- The id for the City
	CITY_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- Master table for all the Divisons in the legal entity
CREATE TABLE DIVISION
(
	-- The Divison in the businees unit 
	DIVISION_ID int NOT NULL,
	-- The  divison name in the business unit
	DIVISION_NAME varchar(30) NOT NULL UNIQUE,
	-- The shortcode for the division
	DIVISION_CODE varchar(15) NOT NULL UNIQUE,
	-- The description of the business unit
	DIVISION_DESC varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (DIVISION_ID)
) WITHOUT OIDS;


CREATE TABLE DIVISON_ACCOUNT_MAPPING
(
	-- The Divison in the businees unit 
	DIVISION_ID int NOT NULL,
	-- It represents the Account Id within a division
	ACCOUNT_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- Master table for the email data. This will contain the email id for Clients/Employees/DL's(At various levels)/ Support Emails etc
CREATE TABLE EMAILID
(
	-- This represents the email id of the actor
	EMAIL_ID varchar(30) NOT NULL,
	-- The domain type of the email id ( Internal or External)
	EMAILID_DOMAIN_TYPE varchar(20) NOT NULL,
	-- The type of Email id 
	EMAILID_TYPE_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMAIL_ID)
) WITHOUT OIDS;


-- Master table to define the various types of email id that can exits - INDIVIDUAL, WORK UNIT DL, SUPPORT DL etc
CREATE TABLE EMAILID_TYPE
(
	-- Id for the Email Type
	EMAILID_TYPE_ID int NOT NULL,
	-- The name of the Email type
	TYPE_NAME varchar(20) NOT NULL,
	-- Description of the email type
	TYPE_DESCRIPTION varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMAILID_TYPE_ID)
) WITHOUT OIDS;


-- This table describes the attributes corresponding to the Employee. This employee will belong to the orgainization for whom the Email Suite will be enabled
CREATE TABLE EMPLOYEE
(
	-- Employee Id used for internal purpose by the Batch Process
	EMPLOYEE_ID int NOT NULL,
	-- This denotes the first name of the client
	FIRST_NAME varchar(20) NOT NULL,
	-- Last name of the client
	LAST_NAME varchar(20) NOT NULL,
	-- Middle name of the client
	MIDDLE_NAME varchar(20),
	-- The legal entity/office/subsidary in which employee works
	LEGAL_ENTITY_ID int NOT NULL,
	-- The branch office in which the client works
	WORK_LOCATION_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMPLOYEE_ID)
) WITHOUT OIDS;


-- Mapping table to represent the mapping of an employee to its email ids
CREATE TABLE EMPLOYEE_EMAILID_MAPPING
(
	-- This represents the email id of the actor
	EMAIL_ID varchar(30) NOT NULL,
	-- Employee Id used for internal purpose by the Batch Process
	EMPLOYEE_ID int NOT NULL,
	-- Whether to enable the email id for tone analysis
	ANALYSE_TONE char NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- This table will contains the Employee Hirerachy to capture the org tree
CREATE TABLE EMPLOYEE_HIRERACHY
(
	-- The id for the hierarchy relationship
	HIERARCHY_ID int NOT NULL,
	-- The employee id of the employee
	EMPLOYEE_ID int NOT NULL,
	-- The employee id of the person to which this person reports
	REPORTS_TO_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (HIERARCHY_ID)
) WITHOUT OIDS;


CREATE TABLE EMPLOYEE_ROLE_MAPPING
(
	-- Employee Id used for internal purpose by the Batch Process
	EMPLOYEE_ID int NOT NULL,
	-- The role id of the role assigned
	ROLE_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMPLOYEE_ID, ROLE_ID)
) WITHOUT OIDS;


-- This table maps the employee to the work unit at the lowest level. An employee can belong to multiple work uints
CREATE TABLE EMPLOYEE_WORK_UNIT_MAPPING
(
	-- Employee Id used for internal purpose by the Batch Process
	EMPLOYEE_ID int NOT NULL,
	-- Type of work unit to which employee belongs - It will be the lowest level in his hirerachy. 
	WORK_UNIT_TYPE_ID int NOT NULL,
	-- The id of the work unit
	WORK_UNIT_ID int,
	-- Whether the employee is owner of this work unit 
	IS_OWNER char NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMPLOYEE_ID)
) WITHOUT OIDS;


-- Master table that describes the different type of legal entities Internal/ External(Client)
CREATE TABLE ENTITY_TYPE
(
	-- The ID for the entity type
	TYPE_ID int NOT NULL,
	-- The type name of the entity
	TYPE_NAME varchar(15) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (TYPE_ID)
) WITHOUT OIDS;


-- This table captures the location details of any actor (Client/Legal Entity/Employee) in the entire system
CREATE TABLE GEO_LOCATION
(
	-- This is the Id for the location and is primary key for the Table 
	LOCATION_ID int NOT NULL,
	-- Describes the continent Id for the location
	CONTINENT_ID varchar(20) NOT NULL,
	-- The country Id for the location
	COUNTRY_ID int NOT NULL,
	-- The disctrict to which it belongs
	DISTRICT_ID int NOT NULL,
	-- Describes the city_id 
	CITY_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (LOCATION_ID)
) WITHOUT OIDS;


CREATE TABLE GROUP_TEAM_MAPPING
(
	-- It represents the Team Id within a group
	TEAM_ID int NOT NULL,
	-- It represents the Group Id within a account
	GROUP_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


-- This table captures the details of the legal entity to which the Client/Employee belongs
CREATE TABLE LEGAL_ENTITY
(
	-- This represents the legal entity id & is the primary key 
	LEGAL_ENTITY_ID int NOT NULL,
	-- The  address to which the legal entity belongs
	ADDRESS_ID int NOT NULL,
	-- This represents the type of the legal entity whether internal or client legal entity
	TYPE_ID int NOT NULL,
	-- The name of the legal entity
	ENTITY_NAME varchar(100) NOT NULL,
	-- Entity Code
	ENTITY_CODE varchar(15) NOT NULL,
	-- Description about the about
	DESCRITPTION varchar(200),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (LEGAL_ENTITY_ID)
) WITHOUT OIDS;


-- Master table for all the roles of Client/Employee/Legal Entity
CREATE TABLE ROLE
(
	-- The role id of the role assigned
	ROLE_ID int NOT NULL,
	-- The name of the role 
	ROLE_NAME varchar(20) NOT NULL UNIQUE,
	-- The shortcode for the role 
	ROLE_CODE varchar(10) NOT NULL UNIQUE,
	-- The description of the role 
	ROLE_DESC varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (ROLE_ID)
) WITHOUT OIDS;


-- Master table for all the Team inside a Group
CREATE TABLE TEAM
(
	-- It represents the Team Id within a group
	TEAM_ID int NOT NULL,
	-- The  Team name
	TEAM_NAME varchar(30) NOT NULL UNIQUE,
	-- The shortcode for the Team
	TEAM_CODE varchar(15) NOT NULL UNIQUE,
	-- The description of the team
	TEAM_DESC varchar(50),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (TEAM_ID)
) WITHOUT OIDS;


-- Master table for the work units in a legal entity - BU, Division, Accounts etc
CREATE TABLE WORK_UNITS_TYPES
(
	-- The id for the work unit
	WORK_UNIT_TYPE_ID int NOT NULL,
	-- Work Unit Name
	WORK_UNIT_TYPE_NAME varchar(20) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (WORK_UNIT_TYPE_ID)
) WITHOUT OIDS;


-- Mapping table to represent the mapping of an work units to its email ids
CREATE TABLE WORK_UNIT_EMAILID_MAPPING
(
	-- This represents the email id of the actor
	EMAIL_ID varchar(30) NOT NULL,
	-- The id for the work unit
	WORK_UNIT_TYPE_ID int NOT NULL,
	-- The id of the work unit
	WORK_UNIT_ID int NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp
) WITHOUT OIDS;


/* Tables for Email Tone **/
-- Aggregated tone details
CREATE TABLE AGGREGATED_TONE
(
	-- Aggregated Tone id
	AGGREGATED_TONE_ID int NOT NULL,
	-- The JSON message for the tone details of the email
	AGGREGATED_TONE text NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (AGGREGATED_TONE_ID)
) WITHOUT OIDS;


-- Calculated tone of the item
CREATE TABLE CALCULATED_TONE
(
	-- Calculated Tone Id
	CALCULATED_TONE_ID int NOT NULL,
	-- The JSON message for the tone details of the email
	CALCULATED_TONE text NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (CALCULATED_TONE_ID)
) WITHOUT OIDS;


-- The table will capture all the  header data  for the email
CREATE TABLE EMAIL_HEADER
(
	-- The Email Meta data Id to which this header belongs
	EMAIL_METADATA_ID int NOT NULL,
	-- The date on which the email is sent or received
	EMAIL_DATE date NOT NULL,
	-- Subject of the email
	SUBJECT varchar(200) NOT NULL,
	-- Importance of the email
	IMPORTANCE varchar(20),
	-- Message ID of the email as generated by the Exchange server
	MESSAGE_ID varchar(300),
	-- The Message ID of the email on whose reply the mail has been sent
	IN_REPLY_TO varchar(300),
	-- The IP of the sender 
	SENDER_IP varchar(20) NOT NULL,
	-- The content language of the email
	CONTENT_LANGUAGE varchar(50) NOT NULL,
	-- CC Email id list (JSON)
	CC_EMAIL_ID text,
	-- TO Email id List(JSON)
	TO_EMAIL_ID text NOT NULL,
	-- Message id of reference mails
	REFERENCE_MESSAGE_ID text,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMAIL_METADATA_ID)
) WITHOUT OIDS;


-- This table will contain all the metadata details related to email & email tone
CREATE TABLE EMAIL_METADATA
(
	-- Represents the ID for the EMAIL details
	EMAIL_METADATA_ID int NOT NULL,
	-- The Aggregated tone of the email
	AGGREGATED_TONE_ID int NOT NULL,
	-- The calculated tone of the email 
	CALCULATED_TONE_ID int NOT NULL,
	-- The tone id for every line in the email
	INDVIDUAL_TONE_ID int NOT NULL,
	-- Direction of Email (Sent or Received)
	EMAIL_DIRECTION varchar(50),
	-- Email id from whom the email has been received
	FROM_EMAIL_ID varchar(30),
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (EMAIL_METADATA_ID)
) WITHOUT OIDS;


-- Individual tone of the item
CREATE TABLE INDIVIDUAL_TONE
(
	-- Individual Tone Id
	INDIVIDUAL_TONE_ID int NOT NULL,
	-- The JSON message for the tone details of the email
	INDIVIDUAL_TONE text NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (INDIVIDUAL_TONE_ID)
) WITHOUT OIDS;


-- Master table to contain all the types of tone
CREATE TABLE TONE
(
	-- Id for the tone
	TONE_ID int NOT NULL,
	-- Name of the Tone
	TONE_NAME varchar(100) NOT NULL UNIQUE,
	-- Description of the tone
	TONE_DESC varchar(200) NOT NULL,
	-- The name/Id of the person who has created the record
	CREATED_BY varchar(50),
	-- This field will specifiy whether the record is active or not. The default value is Y
	STATUS char(1) DEFAULT 'Y',
	-- The version of this record and will be integer value starting from 1 to N
	VERSION_NUM int,
	-- The date & time when the record has been updated in the system
	UPDATED_ON timestamp,
	-- The name/Id of the item that has updated this record
	UPDATED_BY varchar(50),
	-- Date & Time at which this record is created for the first time in the system
	CREATED_ON timestamp,
	PRIMARY KEY (TONE_ID)
) WITHOUT OIDS;





/* Create Foreign Keys */

ALTER TABLE ACCOUNT_GROUP_MAPPING
	ADD FOREIGN KEY (ACCOUNT_ID)
	REFERENCES ACCOUNT (ACCOUNT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE DIVISON_ACCOUNT_MAPPING
	ADD FOREIGN KEY (ACCOUNT_ID)
	REFERENCES ACCOUNT (ACCOUNT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE BRANCH
	ADD FOREIGN KEY (ADDRESS_ID)
	REFERENCES ADDRESS (ADDRESS_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE LEGAL_ENTITY
	ADD FOREIGN KEY (ADDRESS_ID)
	REFERENCES ADDRESS (ADDRESS_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE ACCOUNT_GROUP_MAPPING
	ADD FOREIGN KEY (GROUP_ID)
	REFERENCES BUSINESS_GROUP (GROUP_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE GROUP_TEAM_MAPPING
	ADD FOREIGN KEY (GROUP_ID)
	REFERENCES BUSINESS_GROUP (GROUP_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE BU_DIVISON_MAPPING
	ADD FOREIGN KEY (BUSINESS_UNIT_ID)
	REFERENCES BUSINESS_UNIT (BUSINESS_UNIT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE DISTRICT_CITY_MAPPING
	ADD FOREIGN KEY (CITY_ID)
	REFERENCES CITY (CITY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE GEO_LOCATION
	ADD FOREIGN KEY (CITY_ID)
	REFERENCES CITY (CITY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CONTINENT_COUNTRY_MAPPING
	ADD FOREIGN KEY (CONTINENT_ID)
	REFERENCES CONTINENT (CONTINENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE GEO_LOCATION
	ADD FOREIGN KEY (CONTINENT_ID)
	REFERENCES CONTINENT (CONTINENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CONTINENT_COUNTRY_MAPPING
	ADD FOREIGN KEY (COUNTRY_ID)
	REFERENCES COUNTRY (COUNTRY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE COUNTRY_DISTRICT_MAPPING
	ADD FOREIGN KEY (COUNTRY_ID)
	REFERENCES COUNTRY (COUNTRY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE GEO_LOCATION
	ADD FOREIGN KEY (COUNTRY_ID)
	REFERENCES COUNTRY (COUNTRY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE COUNTRY_DISTRICT_MAPPING
	ADD FOREIGN KEY (DISTRICT_ID)
	REFERENCES DISTRICT (DISTRICT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE DISTRICT_CITY_MAPPING
	ADD FOREIGN KEY (DISTRICT_ID)
	REFERENCES DISTRICT (DISTRICT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE GEO_LOCATION
	ADD FOREIGN KEY (DISTRICT_ID)
	REFERENCES DISTRICT (DISTRICT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE BU_DIVISON_MAPPING
	ADD FOREIGN KEY (DIVISION_ID)
	REFERENCES DIVISION (DIVISION_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE DIVISON_ACCOUNT_MAPPING
	ADD FOREIGN KEY (DIVISION_ID)
	REFERENCES DIVISION (DIVISION_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_EMAILID_MAPPING
	ADD FOREIGN KEY (EMAIL_ID)
	REFERENCES EMAILID (EMAIL_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE WORK_UNIT_EMAILID_MAPPING
	ADD FOREIGN KEY (EMAIL_ID)
	REFERENCES EMAILID (EMAIL_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMAILID
	ADD FOREIGN KEY (EMAILID_TYPE_ID)
	REFERENCES EMAILID_TYPE (EMAILID_TYPE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_EMAILID_MAPPING
	ADD FOREIGN KEY (EMPLOYEE_ID)
	REFERENCES EMPLOYEE (EMPLOYEE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_HIRERACHY
	ADD FOREIGN KEY (EMPLOYEE_ID)
	REFERENCES EMPLOYEE (EMPLOYEE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_HIRERACHY
	ADD FOREIGN KEY (REPORTS_TO_ID)
	REFERENCES EMPLOYEE (EMPLOYEE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_ROLE_MAPPING
	ADD FOREIGN KEY (EMPLOYEE_ID)
	REFERENCES EMPLOYEE (EMPLOYEE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_WORK_UNIT_MAPPING
	ADD FOREIGN KEY (EMPLOYEE_ID)
	REFERENCES EMPLOYEE (EMPLOYEE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE LEGAL_ENTITY
	ADD FOREIGN KEY (TYPE_ID)
	REFERENCES ENTITY_TYPE (TYPE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE ADDRESS
	ADD FOREIGN KEY (LOCATION_ID)
	REFERENCES GEO_LOCATION (LOCATION_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE BRANCH
	ADD FOREIGN KEY (LEGAL_ENTITY_ID)
	REFERENCES LEGAL_ENTITY (LEGAL_ENTITY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE
	ADD FOREIGN KEY (LEGAL_ENTITY_ID)
	REFERENCES LEGAL_ENTITY (LEGAL_ENTITY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_ROLE_MAPPING
	ADD FOREIGN KEY (ROLE_ID)
	REFERENCES ROLE (ROLE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE GROUP_TEAM_MAPPING
	ADD FOREIGN KEY (TEAM_ID)
	REFERENCES TEAM (TEAM_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMPLOYEE_WORK_UNIT_MAPPING
	ADD FOREIGN KEY (WORK_UNIT_TYPE_ID)
	REFERENCES WORK_UNITS_TYPES (WORK_UNIT_TYPE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE WORK_UNIT_EMAILID_MAPPING
	ADD FOREIGN KEY (WORK_UNIT_TYPE_ID)
	REFERENCES WORK_UNITS_TYPES (WORK_UNIT_TYPE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;




/* Create Foreign Keys for Email Tone */

ALTER TABLE EMAIL_METADATA
	ADD FOREIGN KEY (AGGREGATED_TONE_ID)
	REFERENCES AGGREGATED_TONE (AGGREGATED_TONE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMAIL_METADATA
	ADD FOREIGN KEY (CALCULATED_TONE_ID)
	REFERENCES CALCULATED_TONE (CALCULATED_TONE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMAIL_HEADER
	ADD FOREIGN KEY (EMAIL_METADATA_ID)
	REFERENCES EMAIL_METADATA (EMAIL_METADATA_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE EMAIL_METADATA
	ADD FOREIGN KEY (INDVIDUAL_TONE_ID)
	REFERENCES INDIVIDUAL_TONE (INDIVIDUAL_TONE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;

ALTER TABLE CLIENT_EMAILID_MAPPING
	ADD FOREIGN KEY (CLIENT_ID)
	REFERENCES CLIENT (CLIENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_EMPLOYEE_MAPPING
	ADD FOREIGN KEY (CLIENT_ID)
	REFERENCES CLIENT (CLIENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_HIRERACHY
	ADD FOREIGN KEY (CLIENT_ID)
	REFERENCES CLIENT (CLIENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_HIRERACHY
	ADD FOREIGN KEY (REPORTS_TO_ID)
	REFERENCES CLIENT (CLIENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_ROLE_MAPPING
	ADD FOREIGN KEY (CLIENT_ID)
	REFERENCES CLIENT (CLIENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_WORK_UNIT_MAPPING
	ADD FOREIGN KEY (CLIENT_ID)
	REFERENCES CLIENT (CLIENT_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT
	ADD FOREIGN KEY (LEGAL_ENTITY_ID)
	REFERENCES LEGAL_ENTITY (LEGAL_ENTITY_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_ROLE_MAPPING
	ADD FOREIGN KEY (ROLE_ID)
	REFERENCES ROLE (ROLE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE CLIENT_WORK_UNIT_MAPPING
	ADD FOREIGN KEY (WORK_UNIT_TYPE_ID)
	REFERENCES WORK_UNITS_TYPES (WORK_UNIT_TYPE_ID)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;




/* Comments */

COMMENT ON TABLE ACCOUNT IS 'Master table for all the Accounts inside a division';
COMMENT ON COLUMN ACCOUNT.ACCOUNT_ID IS 'It represents the Account Id within a division';
COMMENT ON COLUMN ACCOUNT.ACCOUNT_NAME IS 'The  Acoount name';
COMMENT ON COLUMN ACCOUNT.ACCOUNT_CODE IS 'The shortcode for the account';
COMMENT ON COLUMN ACCOUNT.ACCOUNT_DESC IS 'The description of the account';
COMMENT ON COLUMN ACCOUNT.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN ACCOUNT.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN ACCOUNT.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN ACCOUNT.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN ACCOUNT.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN ACCOUNT.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.GROUP_ID IS 'It represents the Group Id within a account';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.ACCOUNT_ID IS 'It represents the Account Id within a division';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN ACCOUNT_GROUP_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE ADDRESS IS 'This table contains the address details of the actors client/employee/legal entity';
COMMENT ON COLUMN ADDRESS.ADDRESS_ID IS 'This is Address id for the address details';
COMMENT ON COLUMN ADDRESS.LOCATION_ID IS 'The location details relevant to this address';
COMMENT ON COLUMN ADDRESS.ADDRESS_DETAILS IS 'This contains the address (Building, Street, Locality etc)';
COMMENT ON COLUMN ADDRESS.ZIP_CODE IS 'The ZIP code of the address';
COMMENT ON COLUMN ADDRESS.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN ADDRESS.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN ADDRESS.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN ADDRESS.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN ADDRESS.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN ADDRESS.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE BRANCH IS 'This table captures the details of all the branches of  legal entity to which the Client/Employee belongs';
COMMENT ON COLUMN BRANCH.BRANCH_ID IS 'This represents the brach office of the legal entity  & is the primary key ';
COMMENT ON COLUMN BRANCH.LEGAL_ENTITY_ID IS 'The legal entity to which the branch belongs';
COMMENT ON COLUMN BRANCH.ADDRESS_ID IS 'The  address to which the legal entity belongs';
COMMENT ON COLUMN BRANCH.BRANCH_NAME IS 'The name of the branch';
COMMENT ON COLUMN BRANCH.BRANCH_CODE IS 'Branch Code';
COMMENT ON COLUMN BRANCH.DESCRITPTION IS 'Description about the about';
COMMENT ON COLUMN BRANCH.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN BRANCH.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN BRANCH.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN BRANCH.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN BRANCH.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN BRANCH.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE BUSINESS_GROUP IS 'Master table for all the Group inside a Account';
COMMENT ON COLUMN BUSINESS_GROUP.GROUP_ID IS 'It represents the Group Id within a account';
COMMENT ON COLUMN BUSINESS_GROUP.GROUP_NAME IS 'The  Group name';
COMMENT ON COLUMN BUSINESS_GROUP.GROUP_CODE IS 'The shortcode for the Group';
COMMENT ON COLUMN BUSINESS_GROUP.GROUP_DESC IS 'The description of the group';
COMMENT ON COLUMN BUSINESS_GROUP.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN BUSINESS_GROUP.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN BUSINESS_GROUP.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN BUSINESS_GROUP.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN BUSINESS_GROUP.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN BUSINESS_GROUP.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE BUSINESS_UNIT IS 'Master table for all the department for Client/Employee/Legal Entity';
COMMENT ON COLUMN BUSINESS_UNIT.BUSINESS_UNIT_ID IS 'The businees unit ';
COMMENT ON COLUMN BUSINESS_UNIT.BUSINESS_UNIT_NAME IS 'The name of the business unit';
COMMENT ON COLUMN BUSINESS_UNIT.BUSINESS_UNIT_CODE IS 'The shortcode for the business unit';
COMMENT ON COLUMN BUSINESS_UNIT.BUSINESS_UNIT_DESC IS 'The description of the business unit';
COMMENT ON COLUMN BUSINESS_UNIT.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN BUSINESS_UNIT.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN BUSINESS_UNIT.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN BUSINESS_UNIT.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN BUSINESS_UNIT.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN BUSINESS_UNIT.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON COLUMN BU_DIVISON_MAPPING.BUSINESS_UNIT_ID IS 'The businees unit ';
COMMENT ON COLUMN BU_DIVISON_MAPPING.DIVISION_ID IS 'The Divison in the businees unit ';
COMMENT ON COLUMN BU_DIVISON_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN BU_DIVISON_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN BU_DIVISON_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN BU_DIVISON_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN BU_DIVISON_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN BU_DIVISON_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CITY IS 'Master table to hold the data for all the city';
COMMENT ON COLUMN CITY.CITY_ID IS 'The id for the City';
COMMENT ON COLUMN CITY.CITY_NAME IS 'City Name';
COMMENT ON COLUMN CITY.CITY_CODE IS 'Small Code for the City';
COMMENT ON COLUMN CITY.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CITY.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CITY.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CITY.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CITY.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CITY.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CONTINENT IS 'Master table to hold the data for all the continents';
COMMENT ON COLUMN CONTINENT.CONTINENT_ID IS 'Continent ID';
COMMENT ON COLUMN CONTINENT.CONTINENT_NAME IS 'Continent Name';
COMMENT ON COLUMN CONTINENT.CONTINENT_CODE IS 'Small Code for the Continent';
COMMENT ON COLUMN CONTINENT.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CONTINENT.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CONTINENT.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CONTINENT.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CONTINENT.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CONTINENT.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.CONTINENT_ID IS 'Continent ID';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.COUNTRY_ID IS 'The id for the Country';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CONTINENT_COUNTRY_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE COUNTRY IS 'Master table to hold the data for all the countries';
COMMENT ON COLUMN COUNTRY.COUNTRY_ID IS 'The id for the Country';
COMMENT ON COLUMN COUNTRY.COUNTRY_NAME IS 'Country Name';
COMMENT ON COLUMN COUNTRY.COUNTRY_CODE IS 'Small Code for the Country';
COMMENT ON COLUMN COUNTRY.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN COUNTRY.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN COUNTRY.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN COUNTRY.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN COUNTRY.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN COUNTRY.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE COUNTRY_DISTRICT_MAPPING IS 'Country District Mapping table';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.COUNTRY_ID IS 'The id for the Country';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.DISTRICT_ID IS 'The id for the District';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN COUNTRY_DISTRICT_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE DISTRICT IS 'Master table to hold the data for all the district';
COMMENT ON COLUMN DISTRICT.DISTRICT_ID IS 'The id for the District';
COMMENT ON COLUMN DISTRICT.DISTRICT_NAME IS 'District Name';
COMMENT ON COLUMN DISTRICT.DISTRICT_CODE IS 'Small Code for the District';
COMMENT ON COLUMN DISTRICT.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN DISTRICT.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN DISTRICT.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN DISTRICT.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN DISTRICT.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN DISTRICT.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE DISTRICT_CITY_MAPPING IS 'Mapping table for District to City';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.DISTRICT_ID IS 'The id for the District';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.CITY_ID IS 'The id for the City';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN DISTRICT_CITY_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE DIVISION IS 'Master table for all the Divisons in the legal entity';
COMMENT ON COLUMN DIVISION.DIVISION_ID IS 'The Divison in the businees unit ';
COMMENT ON COLUMN DIVISION.DIVISION_NAME IS 'The  divison name in the business unit';
COMMENT ON COLUMN DIVISION.DIVISION_CODE IS 'The shortcode for the division';
COMMENT ON COLUMN DIVISION.DIVISION_DESC IS 'The description of the business unit';
COMMENT ON COLUMN DIVISION.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN DIVISION.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN DIVISION.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN DIVISION.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN DIVISION.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN DIVISION.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.DIVISION_ID IS 'The Divison in the businees unit ';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.ACCOUNT_ID IS 'It represents the Account Id within a division';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN DIVISON_ACCOUNT_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMAILID IS 'Master table for the email data. This will contain the email id for Clients/Employees/DL''s(At various levels)/ Support Emails etc';
COMMENT ON COLUMN EMAILID.EMAIL_ID IS 'This represents the email id of the actor';
COMMENT ON COLUMN EMAILID.EMAILID_DOMAIN_TYPE IS 'The domain type of the email id ( Internal or External)';
COMMENT ON COLUMN EMAILID.EMAILID_TYPE_ID IS 'The type of Email id ';
COMMENT ON COLUMN EMAILID.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMAILID.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMAILID.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMAILID.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMAILID.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMAILID.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMAILID_TYPE IS 'Master table to define the various types of email id that can exits - INDIVIDUAL, WORK UNIT DL, SUPPORT DL etc';
COMMENT ON COLUMN EMAILID_TYPE.EMAILID_TYPE_ID IS 'Id for the Email Type';
COMMENT ON COLUMN EMAILID_TYPE.TYPE_NAME IS 'The name of the Email type';
COMMENT ON COLUMN EMAILID_TYPE.TYPE_DESCRIPTION IS 'Description of the email type';
COMMENT ON COLUMN EMAILID_TYPE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMAILID_TYPE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMAILID_TYPE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMAILID_TYPE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMAILID_TYPE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMAILID_TYPE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMPLOYEE IS 'This table describes the attributes corresponding to the Employee. This employee will belong to the orgainization for whom the Email Suite will be enabled';
COMMENT ON COLUMN EMPLOYEE.EMPLOYEE_ID IS 'Employee Id used for internal purpose by the Batch Process';
COMMENT ON COLUMN EMPLOYEE.FIRST_NAME IS 'This denotes the first name of the client';
COMMENT ON COLUMN EMPLOYEE.LAST_NAME IS 'Last name of the client';
COMMENT ON COLUMN EMPLOYEE.MIDDLE_NAME IS 'Middle name of the client';
COMMENT ON COLUMN EMPLOYEE.LEGAL_ENTITY_ID IS 'The legal entity/office/subsidary in which employee works';
COMMENT ON COLUMN EMPLOYEE.WORK_LOCATION_ID IS 'The branch office in which the client works';
COMMENT ON COLUMN EMPLOYEE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMPLOYEE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMPLOYEE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMPLOYEE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMPLOYEE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMPLOYEE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMPLOYEE_EMAILID_MAPPING IS 'Mapping table to represent the mapping of an employee to its email ids';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.EMAIL_ID IS 'This represents the email id of the actor';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.EMPLOYEE_ID IS 'Employee Id used for internal purpose by the Batch Process';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.ANALYSE_TONE IS 'Whether to enable the email id for tone analysis';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMPLOYEE_EMAILID_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMPLOYEE_HIRERACHY IS 'This table will contains the Employee Hirerachy to capture the org tree';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.HIERARCHY_ID IS 'The id for the hierarchy relationship';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.EMPLOYEE_ID IS 'The employee id of the employee';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.REPORTS_TO_ID IS 'The employee id of the person to which this person reports';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMPLOYEE_HIRERACHY.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.EMPLOYEE_ID IS 'Employee Id used for internal purpose by the Batch Process';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.ROLE_ID IS 'The role id of the role assigned';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMPLOYEE_ROLE_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMPLOYEE_WORK_UNIT_MAPPING IS 'This table maps the employee to the work unit at the lowest level. An employee can belong to multiple work uints';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.EMPLOYEE_ID IS 'Employee Id used for internal purpose by the Batch Process';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.WORK_UNIT_TYPE_ID IS 'Type of work unit to which employee belongs - It will be the lowest level in his hirerachy. ';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.WORK_UNIT_ID IS 'The id of the work unit';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.IS_OWNER IS 'Whether the employee is owner of this work unit ';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMPLOYEE_WORK_UNIT_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE ENTITY_TYPE IS 'Master table that describes the different type of legal entities Internal/ External(Client)';
COMMENT ON COLUMN ENTITY_TYPE.TYPE_ID IS 'The ID for the entity type';
COMMENT ON COLUMN ENTITY_TYPE.TYPE_NAME IS 'The type name of the entity';
COMMENT ON COLUMN ENTITY_TYPE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN ENTITY_TYPE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN ENTITY_TYPE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN ENTITY_TYPE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN ENTITY_TYPE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN ENTITY_TYPE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE GEO_LOCATION IS 'This table captures the location details of any actor (Client/Legal Entity/Employee) in the entire system';
COMMENT ON COLUMN GEO_LOCATION.LOCATION_ID IS 'This is the Id for the location and is primary key for the Table ';
COMMENT ON COLUMN GEO_LOCATION.CONTINENT_ID IS 'Describes the continent Id for the location';
COMMENT ON COLUMN GEO_LOCATION.COUNTRY_ID IS 'The country Id for the location';
COMMENT ON COLUMN GEO_LOCATION.DISTRICT_ID IS 'The disctrict to which it belongs';
COMMENT ON COLUMN GEO_LOCATION.CITY_ID IS 'Describes the city_id ';
COMMENT ON COLUMN GEO_LOCATION.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN GEO_LOCATION.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN GEO_LOCATION.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN GEO_LOCATION.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN GEO_LOCATION.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN GEO_LOCATION.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.TEAM_ID IS 'It represents the Team Id within a group';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.GROUP_ID IS 'It represents the Group Id within a account';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN GROUP_TEAM_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE LEGAL_ENTITY IS 'This table captures the details of the legal entity to which the Client/Employee belongs';
COMMENT ON COLUMN LEGAL_ENTITY.LEGAL_ENTITY_ID IS 'This represents the legal entity id & is the primary key ';
COMMENT ON COLUMN LEGAL_ENTITY.ADDRESS_ID IS 'The  address to which the legal entity belongs';
COMMENT ON COLUMN LEGAL_ENTITY.TYPE_ID IS 'This represents the type of the legal entity whether internal or client legal entity';
COMMENT ON COLUMN LEGAL_ENTITY.ENTITY_NAME IS 'The name of the legal entity';
COMMENT ON COLUMN LEGAL_ENTITY.ENTITY_CODE IS 'Entity Code';
COMMENT ON COLUMN LEGAL_ENTITY.DESCRITPTION IS 'Description about the about';
COMMENT ON COLUMN LEGAL_ENTITY.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN LEGAL_ENTITY.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN LEGAL_ENTITY.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN LEGAL_ENTITY.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN LEGAL_ENTITY.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN LEGAL_ENTITY.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE ROLE IS 'Master table for all the roles of Client/Employee/Legal Entity';
COMMENT ON COLUMN ROLE.ROLE_ID IS 'The role id of the role assigned';
COMMENT ON COLUMN ROLE.ROLE_NAME IS 'The name of the role ';
COMMENT ON COLUMN ROLE.ROLE_CODE IS 'The shortcode for the role ';
COMMENT ON COLUMN ROLE.ROLE_DESC IS 'The description of the role ';
COMMENT ON COLUMN ROLE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN ROLE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN ROLE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN ROLE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN ROLE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN ROLE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE TEAM IS 'Master table for all the Team inside a Group';
COMMENT ON COLUMN TEAM.TEAM_ID IS 'It represents the Team Id within a group';
COMMENT ON COLUMN TEAM.TEAM_NAME IS 'The  Team name';
COMMENT ON COLUMN TEAM.TEAM_CODE IS 'The shortcode for the Team';
COMMENT ON COLUMN TEAM.TEAM_DESC IS 'The description of the team';
COMMENT ON COLUMN TEAM.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN TEAM.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN TEAM.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN TEAM.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN TEAM.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN TEAM.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE WORK_UNITS_TYPES IS 'Master table for the work units in a legal entity - BU, Division, Accounts etc';
COMMENT ON COLUMN WORK_UNITS_TYPES.WORK_UNIT_TYPE_ID IS 'The id for the work unit';
COMMENT ON COLUMN WORK_UNITS_TYPES.WORK_UNIT_TYPE_NAME IS 'Work Unit Name';
COMMENT ON COLUMN WORK_UNITS_TYPES.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN WORK_UNITS_TYPES.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN WORK_UNITS_TYPES.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN WORK_UNITS_TYPES.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN WORK_UNITS_TYPES.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN WORK_UNITS_TYPES.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE WORK_UNIT_EMAILID_MAPPING IS 'Mapping table to represent the mapping of an work units to its email ids';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.EMAIL_ID IS 'This represents the email id of the actor';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.WORK_UNIT_TYPE_ID IS 'The id for the work unit';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.WORK_UNIT_ID IS 'The id of the work unit';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN WORK_UNIT_EMAILID_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CLIENT IS 'This table describes the attributes corresponding to the Client.';
COMMENT ON COLUMN CLIENT.CLIENT_ID IS 'ClientId used for internal purpose by the Batch Process';
COMMENT ON COLUMN CLIENT.FIRST_NAME IS 'This denotes the first name of the actor';
COMMENT ON COLUMN CLIENT.LAST_NAME IS 'Last name of the actor';
COMMENT ON COLUMN CLIENT.MIDDLE_NAME IS 'Middle name of the actor';
COMMENT ON COLUMN CLIENT.LEGAL_ENTITY_ID IS 'The legal entity/office/subsidary in which actor works';
COMMENT ON COLUMN CLIENT.WORK_LOCATION_ID IS 'The branch office in which the actor works';
COMMENT ON COLUMN CLIENT.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CLIENT.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CLIENT.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CLIENT.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CLIENT.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CLIENT.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CLIENT_EMAILID_MAPPING IS 'Mapping table to represent the mapping of an client to its email ids';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.EMAIL_ID IS 'This represents the email id of the actor';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.CLIENT_ID IS 'ClientId used for internal purpose by the Batch Process';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.ANALYSE_TONE IS 'Whether to enable the email id for tone analysis';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CLIENT_EMAILID_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CLIENT_EMPLOYEE_MAPPING IS 'Mapping table for Clients to Employee';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.CLIENT_ID IS 'ClientId used for internal purpose by the Batch Process';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.EMPLOYEE_ID IS 'Employee Id used for internal purpose by the Batch Process';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CLIENT_EMPLOYEE_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CLIENT_HIRERACHY IS 'This table will contains the Client Hirerachy to capture the org tree';
COMMENT ON COLUMN CLIENT_HIRERACHY.HIERARCHY_ID IS 'The id for the hierarchy relationship';
COMMENT ON COLUMN CLIENT_HIRERACHY.CLIENT_ID IS 'The employee id of the employee';
COMMENT ON COLUMN CLIENT_HIRERACHY.REPORTS_TO_ID IS 'The employee id of the person to which this person reports';
COMMENT ON COLUMN CLIENT_HIRERACHY.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CLIENT_HIRERACHY.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CLIENT_HIRERACHY.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CLIENT_HIRERACHY.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CLIENT_HIRERACHY.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CLIENT_HIRERACHY.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CLIENT_ROLE_MAPPING IS 'Mapping table for the Client & its Role';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.CLIENT_ID IS 'ClientId used for internal purpose by the Batch Process';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.ROLE_ID IS 'The role id of the role assigned';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CLIENT_ROLE_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CLIENT_WORK_UNIT_MAPPING IS 'This table maps the employee to the work unit at the lowest level. An employee can belong to multiple work uints';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.CLIENT_ID IS 'ClientId used for internal purpose by the Batch Process';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.WORK_UNIT_TYPE_ID IS 'Type of work unit to which employee belongs - It will be the lowest level in his hirerachy. ';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.WORK_UNIT_ID IS 'The id of the work unit';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.IS_OWNER IS 'Whether the employee is owner of this work unit ';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CLIENT_WORK_UNIT_MAPPING.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';


/** For Email Tone ***/


/* Comments */

COMMENT ON TABLE AGGREGATED_TONE IS 'Aggregated tone details';
COMMENT ON COLUMN AGGREGATED_TONE.AGGREGATED_TONE_ID IS 'Aggregated Tone id';
COMMENT ON COLUMN AGGREGATED_TONE.AGGREGATED_TONE IS 'The JSON message for the tone details of the email';
COMMENT ON COLUMN AGGREGATED_TONE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN AGGREGATED_TONE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN AGGREGATED_TONE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN AGGREGATED_TONE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN AGGREGATED_TONE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN AGGREGATED_TONE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE CALCULATED_TONE IS 'Calculated tone of the item';
COMMENT ON COLUMN CALCULATED_TONE.CALCULATED_TONE_ID IS 'Calculated Tone Id';
COMMENT ON COLUMN CALCULATED_TONE.CALCULATED_TONE IS 'The JSON message for the tone details of the email';
COMMENT ON COLUMN CALCULATED_TONE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN CALCULATED_TONE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN CALCULATED_TONE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN CALCULATED_TONE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN CALCULATED_TONE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN CALCULATED_TONE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMAIL_HEADER IS 'The table will capture all the  header data  for the email';
COMMENT ON COLUMN EMAIL_HEADER.EMAIL_METADATA_ID IS 'The Email Meta data Id to which this header belongs';
COMMENT ON COLUMN EMAIL_HEADER.EMAIL_DATE IS 'The date on which the email is sent or received';
COMMENT ON COLUMN EMAIL_HEADER.SUBJECT IS 'Subject of the email';
COMMENT ON COLUMN EMAIL_HEADER.IMPORTANCE IS 'Importance of the email';
COMMENT ON COLUMN EMAIL_HEADER.MESSAGE_ID IS 'Message ID of the email as generated by the Exchange server';
COMMENT ON COLUMN EMAIL_HEADER.IN_REPLY_TO IS 'The Message ID of the email on whose reply the mail has been sent';
COMMENT ON COLUMN EMAIL_HEADER.SENDER_IP IS 'The IP of the sender ';
COMMENT ON COLUMN EMAIL_HEADER.CONTENT_LANGUAGE IS 'The content language of the email';
COMMENT ON COLUMN EMAIL_HEADER.CC_EMAIL_ID IS 'CC Email id list (JSON)';
COMMENT ON COLUMN EMAIL_HEADER.TO_EMAIL_ID IS 'TO Email id List(JSON)';
COMMENT ON COLUMN EMAIL_HEADER.REFERENCE_MESSAGE_ID IS 'Message id of reference mails';
COMMENT ON COLUMN EMAIL_HEADER.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMAIL_HEADER.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMAIL_HEADER.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMAIL_HEADER.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMAIL_HEADER.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMAIL_HEADER.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE EMAIL_METADATA IS 'This table will contain all the metadata details related to email & email tone';
COMMENT ON COLUMN EMAIL_METADATA.EMAIL_METADATA_ID IS 'Represents the ID for the EMAIL details';
COMMENT ON COLUMN EMAIL_METADATA.AGGREGATED_TONE_ID IS 'The Aggregated tone of the email';
COMMENT ON COLUMN EMAIL_METADATA.CALCULATED_TONE_ID IS 'The calculated tone of the email ';
COMMENT ON COLUMN EMAIL_METADATA.INDVIDUAL_TONE_ID IS 'The tone id for every line in the email';
COMMENT ON COLUMN EMAIL_METADATA.EMAIL_DIRECTION IS 'Direction of Email (Sent or Received)';
COMMENT ON COLUMN EMAIL_METADATA.FROM_EMAIL_ID IS 'Email id from whom the email has been received';
COMMENT ON COLUMN EMAIL_METADATA.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN EMAIL_METADATA.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN EMAIL_METADATA.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN EMAIL_METADATA.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN EMAIL_METADATA.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN EMAIL_METADATA.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE INDIVIDUAL_TONE IS 'Individual tone of the item';
COMMENT ON COLUMN INDIVIDUAL_TONE.INDIVIDUAL_TONE_ID IS 'Individual Tone Id';
COMMENT ON COLUMN INDIVIDUAL_TONE.INDIVIDUAL_TONE IS 'The JSON message for the tone details of the email';
COMMENT ON COLUMN INDIVIDUAL_TONE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN INDIVIDUAL_TONE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN INDIVIDUAL_TONE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN INDIVIDUAL_TONE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN INDIVIDUAL_TONE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN INDIVIDUAL_TONE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';
COMMENT ON TABLE TONE IS 'Master table to contain all the types of tone';
COMMENT ON COLUMN TONE.TONE_ID IS 'Id for the tone';
COMMENT ON COLUMN TONE.TONE_NAME IS 'Name of the Tone';
COMMENT ON COLUMN TONE.TONE_DESC IS 'Description of the tone';
COMMENT ON COLUMN TONE.CREATED_BY IS 'The name/Id of the person who has created the record';
COMMENT ON COLUMN TONE.STATUS IS 'This field will specifiy whether the record is active or not. The default value is Y';
COMMENT ON COLUMN TONE.VERSION_NUM IS 'The version of this record and will be integer value starting from 1 to N';
COMMENT ON COLUMN TONE.UPDATED_ON IS 'The date & time when the record has been updated in the system';
COMMENT ON COLUMN TONE.UPDATED_BY IS 'The name/Id of the item that has updated this record';
COMMENT ON COLUMN TONE.CREATED_ON IS 'Date & Time at which this record is created for the first time in the system';







