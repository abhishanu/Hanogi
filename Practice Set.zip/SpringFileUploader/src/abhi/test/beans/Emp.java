package abhi.test.beans;

public class Emp {

}
