package com.iris.test.QuartzDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.iris.test.QuartzDemo.service.SchedulerService;

@Component
public class SchedulerStartUpHandler implements ApplicationRunner {

	@Autowired
	private SchedulerService schedulerService;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		try {
			schedulerService.startAllSchedulers();
		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
		}
	}
}
