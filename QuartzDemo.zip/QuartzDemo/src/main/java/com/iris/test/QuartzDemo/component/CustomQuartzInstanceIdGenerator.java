package com.iris.test.QuartzDemo.component;

import java.util.UUID;

import org.quartz.SchedulerException;
import org.quartz.spi.InstanceIdGenerator;

public class CustomQuartzInstanceIdGenerator implements InstanceIdGenerator {

	@Override
	public String generateInstanceId() throws SchedulerException {
		try {
			return UUID.randomUUID().toString();
		} catch (Exception e) {
			throw new SchedulerException("Couldn't generate UUID because:" + e.getMessage());
		}
	}
}
