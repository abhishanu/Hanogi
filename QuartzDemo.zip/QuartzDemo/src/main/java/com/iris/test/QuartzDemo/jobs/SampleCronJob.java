package com.iris.test.QuartzDemo.jobs;

import java.util.stream.IntStream;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

@DisallowConcurrentExecution
public class SampleCronJob extends QuartzJobBean {
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		// IntStream.range(0, 10).forEach(i -> {
		// try {
		// System.out.println("Cron:" + i);
		// Thread.sleep(1000);
		// } catch (InterruptedException e) {
		// }
		// });

		System.out.println("Cron Job triggerd:"+context.getJobDetail().getKey());
	}
}
