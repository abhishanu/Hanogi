package com.iris.test.QuartzDemo.jobs;

import java.util.stream.IntStream;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

public class SimpleJob extends QuartzJobBean {
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		IntStream.range(0, 5).forEach(i -> {
			try {
				System.out.println("Sample:" + i);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		});
	}
}
