package com.restApp.religiousIndia.utilities.exception;

public class CartNotSavedException extends Exception {
	public CartNotSavedException(String msg) {
		super(msg);
	}

}
