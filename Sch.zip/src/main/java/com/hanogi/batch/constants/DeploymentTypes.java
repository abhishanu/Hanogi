package com.hanogi.batch.constants;

public enum DeploymentTypes {
	
	OnPremise,
	
	OnCloud,
	
	Hybrid

}
