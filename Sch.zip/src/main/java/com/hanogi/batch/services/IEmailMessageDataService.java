package com.hanogi.batch.services;

public interface IEmailMessageDataService {

//	public Boolean insertMessageToDB(EmailMessageData emailMessageData);

}
