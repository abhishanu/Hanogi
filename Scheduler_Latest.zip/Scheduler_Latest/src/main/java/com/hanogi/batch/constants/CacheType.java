package com.hanogi.batch.constants;

public enum CacheType {
	HistroicalCache, ConcurrentCache
}
