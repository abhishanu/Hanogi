package com.hanogi.batch.constants;

public enum EmailDirection {
	
	Sent,
	
	Received

}
