package com.hanogi.batch.exceptions;

/**
 * @author abhishek.gupta02
 */

public class SchedulingException extends Exception {
	public SchedulingException(String message) {
		super(message);
	}
}
