package com.security.SecurityTest.model.roleName;

public enum RoleName {
	ROLE_USER, ROLE_ADMIN
}