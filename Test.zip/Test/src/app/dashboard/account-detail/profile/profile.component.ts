import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../services/request.service';
import { CommonService } from '../../../services/common.service';

@Component({
    selector: 'profile',
    templateUrl: './profile.component.html'
  })
  export class ProfileComponent implements OnInit {
    editEmailFalg:boolean=false;
    gender:any;
    editContactFalg:boolean=false;
    editNameFalg:boolean=false;
    fullName:string='';

    userProfile:any=[];
    constructor(private _requestService: RequestService,private _commonService: CommonService) {

     }

    ngOnInit() {
        if(this._commonService.checkAlreadyLoggedIn()){
            this.getUserDetails();
        }else{
            this._commonService.redirectToLogin();
        }
    }

    getUserDetails(){
        this.userProfile=this._commonService.userDetails;
            if(this.userProfile[0]===undefined){
                this._requestService.fetchAuthData('myProfile').subscribe(data => {

                    const result = data.json().response;
                    
                    this._commonService.userDetails=result;
                    this.userProfile=result;
                    this._commonService.userName=result.firstName;
                    this.fullName=this.userProfile.firstName+' '+this.userProfile.middleName+' '+this.userProfile.lastName;
                    this._requestService.fetchData("getUserRole/"+this.userProfile.userRoleDetails).subscribe(
                        data=>{
                            this.userProfile.userRoleDetails=data.json().response;
                        },
                        err=>{}
                    );
                  }, err => {
                    this._commonService.showHttpErrorMsg();
                  });
            }
    }

    private updateProfile(){
        console.log(this.fullName+":"+this.userProfile.userId+":"+this.userProfile.primaryPhone);
    }

  }