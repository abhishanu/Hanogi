import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent {

  constructor(private _commonService: CommonService) { }

  ngOnInit() {
    if (this._commonService.checkAlreadyLoggedIn()) {
      this._commonService.updateBreadCrumb([]);
      this._commonService.dashbordTab = "account";
      this._commonService.dashbordSubCatTab="cards"; 
      this._commonService.dashboardUpdate({
        type: "orders",
        currentMenu: "temple-history"
      });
    }
    else{
      this._commonService.redirectToLogin();
    }   
    
  }

}
