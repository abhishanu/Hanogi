import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
@Component({
  selector: 'left-nav',
  templateUrl: './left.nav.html'
})
export class LeftNavComponent {
  menuList: any = [];
  constructor(private _commonService: CommonService) {

  }

  ngOnInit() {
    
    this.menuList = [{
      "menuName": "Orders & Returns","menuType":"orders", "subMenus": [
        { "name": "Temple Donations History", "url": "temple-history" },
        { "name": "Pooja Services", "url": "pooja-service" },
        { "name": "Religious Tours", "url": "religious-tour" },
        { "name": "Pandit Bookings", "url": "pandit-booking" },
        { "name": "Others", "url": "others" }]
    },
    {
      "menuName": "Credits", "menuType":"credit","subMenus": [
        { "name": "Coupons", "url": "coupons" },
        { "name": "Reward Points", "url": "reward-points" },
        { "name": "Cashback", "url": "cashback" },
        { "name": "Refer & Earn", "url": "refer-earn" },
        { "name": "Wallet", "url": "wallet" }]
    },
    {
      "menuName": "Account","menuType":"account", "subMenus": [
        { "name": "Profile", "url": "profile" },
        { "name": "User Wishlist", "url": "wishlist" },
        { "name": "Change Password", "url": "change-pwd" },
        { "name": "Addresses", "url": "account-address" },
        { "name": "Saved Cards", "url": "cards" }]
    }];

  }
  
  setCurrent($event, url,type) {
    document.querySelector(".left-menu .sub-menu li.active") ? document.querySelector(".left-menu .sub-menu li.active").classList.remove("active") : "";
    $event.target.parentElement.classList.add("active");  
     this._commonService.dashbordTab = type;  
    this._commonService.dashboardUpdate({
      type:type,
      currentMenu:url
    })
  }
}
