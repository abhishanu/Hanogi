import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'account-detail',
  templateUrl: './account-detail.component.html'
})
export class AccountDetailComponent implements OnInit {

  constructor(private _commonService: CommonService) { }

  ngOnInit() {
    this._commonService.dashbordTab = "account";
  }

}
