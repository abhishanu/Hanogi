import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../../services/request.service';
import { CommonService } from '../../../../services/common.service';

@Component({
  selector: 'add-new-address',
  templateUrl: './add-new-address.component.html'
})
export class NewAddressComponent implements OnInit {
  params: any = {};
  userAddresses:Array<any>;
  states:any;
  city:any='';
  selectedState:any='Delhi';
  addressLine1:any='';
  addressLine2:any='';
  pincode:any='';
  contactNo:any='';
  landmark:any='';
  constructor(private _requestService: RequestService,private _commonService: CommonService) { }

    ngOnInit() {
       this.states=this._requestService.fetchData("getAllStates").subscribe(
         data=>{
           this.states=data.json();
          },
         err=>{
          
         }
       );
    }

    private saveNewAddress(){
      this.params = {
        "requestType": "addNewAddress",
        "requestParam": {
          "city": this.city,
          "state": this.selectedState,
          "addressDesc": this.addressLine1+","+this.addressLine2,
          "pincode": this.pincode,
          "contactNo": this.contactNo
        }
      }
      this._requestService.postAuthData("addNewAddress",this.params).subscribe(
        data=>{
          this._commonService.showAlert({
            type: "success", msg: data.json().response
          });
        },
        err=>{
          this._commonService.showHttpErrorMsg();
        }
      );
    }
}