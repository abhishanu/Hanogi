import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../services/request.service';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'account-address',
  templateUrl: './address.component.html'
})
export class AddressComponent implements OnInit {
  
  userAddresses:Array<any>;

  constructor(private router: Router,private _requestService: RequestService,private _commonService: CommonService) { }

    ngOnInit() {
      this._requestService.fetchAuthData("getUserOtherAddresses").subscribe(
        data=>{
          const dataItem=data.json();
          this.userAddresses=dataItem.response;
          this.getUserDeliveryDetails();
        },
        err=>{
          this._commonService.showHttpErrorMsg();
        }
      );
    }

    addNewAddress(){
      this.router.navigate(['address/add-new-address']);
    }

    private getUserDeliveryDetails(){
      this._requestService.fetchAuthData("getUserDeliveryAddress").subscribe(
        data=>{
          const dataItem=data.json();
          if(dataItem.status=="OK"){
            this.userAddresses.unshift(dataItem.response);
          }
        },
        err=>{
          this._commonService.showHttpErrorMsg();
        }
      );
    }

    private deleteAddress(address){
      this._requestService.fetchAuthData("deleteAddressFromList/"+address.Address.id).subscribe(
        data=>{
          let index = this.userAddresses.indexOf(address);
          this.userAddresses.splice(index, 1);
          this._commonService.showAlert({
            type: "success", msg: data.json().response
          });
        },
        err=>{
          this._commonService.showHttpErrorMsg();
        }
      );
    }

    private editAddress(address){
     
    }

  }
