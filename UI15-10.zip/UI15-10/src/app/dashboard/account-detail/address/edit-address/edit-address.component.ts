import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../../services/request.service';
import { CommonService } from '../../../../services/common.service';
import { Router } from '@angular/router';

export class EditComponent implements OnInit {

    constructor(private router: Router,private _requestService: RequestService,private _commonService: CommonService) {}

    ngOnInit() {}
}

