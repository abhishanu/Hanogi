import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../services/request.service';
import { CommonService } from '../../../services/common.service';

@Component({
    selector: 'cards',
    templateUrl: './cards.component.html'
  })
  export class CardsComponent implements OnInit {
    totalCard:Array<any>=[{},{},{}];
    month:number=1;
    year:any=2023;
    constructor(private _requestService: RequestService,private _commonService: CommonService){}

    ngOnInit(){

      }
  }