import { Component, OnInit } from '@angular/core';
import { RequestService } from '../../../services/request.service';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'change-pwd',
  templateUrl: './change-pwd.component.html'
})
export class ChangePwdComponent implements OnInit {
  params: any = {};
  type:String="password";
  showPwd:Boolean=false;

  newPwd:any="";
  oldPwd:any="";
  cnfPwd:any="";
  constructor(private _requestService: RequestService,private _commonService: CommonService) { }

  ngOnInit() {
    if (!this._commonService.checkAlreadyLoggedIn()) {
      this._commonService.redirectToLogin();
    } 
  }

  changePwd(){
    if(this.oldPwd!=="" && this.newPwd!=""){
      this.params = {
        "requestType": "resetPwd",
        "requestParam": {
          "oldPwd": this.oldPwd,
          "newPwd": this.newPwd
        }
      }
      this._requestService.postAuthData("resetPassword",this.params).subscribe(
        data=>{
          const dataBody=data.json();
  
          if(dataBody.status==="OK"){
            this._commonService.showAlert({
              type: "success", msg: dataBody.response
            });
            this.newPwd="";
            this.oldPwd="";
            this.cnfPwd="";
          }else{
            this._commonService.showAlert({
              type: "danger", msg: dataBody.response
            });
          }
        },
        err=>{
          this._commonService.showHttpErrorMsg();
        }
      );
    }
    else{
      
    }
  }

  showPassword(){
    this.showPwd=!this.showPwd;
    if(this.showPwd){
      this.type="text";
    }else{
      this.type="password";
    }
  }

}
