import { Component } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { RequestService } from '../../services/request.service';
 
@Component({
  selector: 'book-pandit',
  templateUrl: './book-pandit.html'
})

export class BookPanditComponent {
  toppandit:Array<any>;
  constructor(private _commonService: CommonService, private _requestService: RequestService) {}
  ngOnInit() {
    this._requestService.fetchData("getTopPanditsInCity/"+this._commonService.currentCity).subscribe(
      data=>{
        const dataItem=data.json();

        if (dataItem.status==="OK") {
          this.toppandit=dataItem.response;
        }
        else{
           this.toppandit=[];
        }
      },
      err=>{
        this._commonService.showHttpErrorMsg();
      }
    );
     this.toppandit = [];
  }  
}