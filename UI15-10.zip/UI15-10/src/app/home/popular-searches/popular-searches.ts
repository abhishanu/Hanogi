import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'popular-searches',
  templateUrl: './popular-searches.component.html'
})
export class PopularSearchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
