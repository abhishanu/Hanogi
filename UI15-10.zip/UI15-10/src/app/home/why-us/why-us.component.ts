import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'why-us',
  templateUrl: './why-us.component.html'
})
export class WhyUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
