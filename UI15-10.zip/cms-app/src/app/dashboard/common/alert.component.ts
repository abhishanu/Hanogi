import { Component, OnInit , Input ,Output , EventEmitter} from '@angular/core';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'alert',
  templateUrl: './alert.component.html'
})
export class AlertComponent implements OnInit {
@Input() isShow:boolean;
@Input() alertType:String;
@Input() alertMsg:String;
@Output() change = new EventEmitter();
autoHide:boolean=true;
constructor(private dataService: DataService ){
}
ngOnInit(){
  
}
ngAfterViewInit(){
  
}
closeAlert(){
this.change.emit();
}

}
