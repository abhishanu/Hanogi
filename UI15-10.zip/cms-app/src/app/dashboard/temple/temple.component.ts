import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent} from '@angular/common/http';
import { DataService } from '../../services/data.service';
import { AlertComponent } from '../common/alert.component';

@Component({
  selector: 'addtemple',
  templateUrl: './temple.component.html'
})

export class TempleComponent implements OnInit {
  param: any={};

  addTempleDetails:any ={  
   "templeId":"",
   "templeDesc":"",
   "templeTiming":["15:00","16:00"],
   "address":{  
      "address":"",
      "city":"",
      "dist":"",
      "addressContactNo":"",
      "state":""
   },
   "imagePath":"",
   "templeName":"Ramendra",
   "aartiTiming":['03:00','05:00'],
   "contactNo":""
}

  templeName:any='';
  templeDesc:any='';
  contactNo:any='';
  state:any;
  city:any='';
  dist:any='';
  addressContactNo:any ='';
  selectedState:any='';
  addressLine1:any='';
  addressLine2:any='';
  templeAddress:any;
  templeTimingOpen:any ='';
  templeTimingClose:any ='';
  aartiTimingStart:any ='';
  aartiTimingEnd:any ='';
  allCities: any;
  templeImages:any;
  urls:any= new Array<string>();
  selectedFiles: FileList;
  currentFileUpload: File;
  fileName:any = '';
  addTempleUrl:any= '';
  mainImageId: any= '';
  isSuccessMsg= ''
  isErrotMsg= ''
  constructor(private dataService : DataService){}

  ngOnInit(){
    this.dataService.fetchData("getAllCities").subscribe(data =>{
        this.allCities = data.json();
    })
    if(this.dataService.isTempleListEdit){
        this.dataService.fetchData(`getUnVerifiedTemple/${this.dataService.isTempleListEdit}`).subscribe(data=>{
          this.addTempleDetails=data.json().response;
          this.dataService.isTempleListEdit= '';
        })

    }
    if(this.dataService.currentUserRole=="admin" || this.dataService.currentUserRole=="userAdmin"){
      this.addTempleUrl = "saveTempleAsVerified"
    }else{
       this.addTempleUrl = "saveTempleDetails"
    }
  }
  onAlertChanged(alert){
    if(alert==="success"){
      this.isSuccessMsg= '';
    }else{
      this.isErrotMsg = '';
    }
  }
  onSelectFile($event) {
    this.urls = [];
    let files = $event.target.files;
    if (files) {
      for (let file of files) {
        let reader = new FileReader();
        reader.onload = (e: any) => {
          this.urls.push(e.target.result);
        }
        reader.readAsDataURL(file);
      }
    }
    this.selectedFiles = $event.target.files;
    this.addTempleDetails.imagePath= $event.target.files[0].name;
  }
  addTempleData(f){
    console.log(this.addTempleDetails);
    this.currentFileUpload = this.selectedFiles[0];
    let formdata: FormData = new FormData();
    formdata.append('file',this.currentFileUpload);
    //  const obj={'addressDetail':this.addressLine1+" "+this.addressLine2,
    //         'city': this.city,
    //         'state': this.state,
    //         'dist': this.dist,
    //         "addressContactNo":this.addressContactNo};
    //         const address=JSON.stringify(obj)


  this.dataService.postclientData("saveImage",formdata)
    .subscribe(data =>{
          if(data["status"] ==="OK"){
              //this.mainImageId = data["response"].imageId;
              this.addTempleDetails.mainImageId = data["response"].imageId
              console.log(this.addTempleDetails);
              // this.param = {
              //     "requestType": "saveTempleDetails",
              //     "requestParam": {
              //         "templeName":[this.templeName],
              //         "contactNo": [this.contactNo],
              //         "templeDesc" : [this.templeDesc],
              //         "templeTiming": [this.templeTimingOpen,this.templeTimingClose],
              //         "aartiTiming": [this.aartiTimingStart,this.aartiTimingEnd],
              //         "templeAddress"  : [address ],
              //         "mainImageId" : [this.mainImageId]
              //     }
              //   }

                this.dataService.postData(this.addTempleUrl,this.param)
                  .subscribe(response => {
                    if(response.status===200){
                      this.isSuccessMsg = "Temple saved sucessfully"
                    }
                  },error=>{
                      this.isErrotMsg = "Error";
                  })  
          }
    },
    (error :  Response)=>{
      console.log(error);
    })

  
  }
}
