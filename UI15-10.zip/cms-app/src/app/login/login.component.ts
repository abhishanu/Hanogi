import { Component, OnInit } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit  {
    params: any;
    model: any = {};
    constructor(private router: Router, private _DataService: DataService) {

    }
  ngOnInit() {}

  onSubmit() {
    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.model))
    this.userSignIn(); 
  }
  userSignIn() {
    this.params = {
      "requestType": "login",
      "requestParam": this.model
    };
    
      this._DataService.postAuthData("login", this.params).subscribe(
        data => {
          if(data){
            this._DataService.login(data);
            //this.userProfile();
            //this.closePopup();
            this.router.navigate(['dashboard']);
          }
          else{
              //this._CommonService.showAlert({
             //      type: "danger", msg: 'Username or password is incorrect'
             // });
          }
        },
        err =>  {
          console.log(err);
          //this.closePopup();
          //this._CommonService.showHttpErrorMsg();
        }
      );
  }
 
}
