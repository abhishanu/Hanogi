import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TempleComponent } from './dashboard/temple/temple.component';
import { TempleListComponent } from './dashboard/temple-list/temple-list.component';
import { ManageRoleComponent } from './dashboard/manage-role/manage-role.component';
import { AddPanditComponent } from './dashboard/add-pandit/add-pandit.component';

const routes: Routes = [
    { path: '', pathMatch: 'full', component: LoginComponent },
    { path: 'login', pathMatch: 'full', component: LoginComponent },
    { path: 'dashboard', component: DashboardComponent,
    children: [
        { path: 'addtemple', component: TempleComponent},
        { path: 'templelist', component: TempleListComponent},
        { path: 'manage-role', component: ManageRoleComponent},
        { path: 'addpandit', component: AddPanditComponent}

        
        
        ]
     },
];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }

export const routedComponents = [LoginComponent,DashboardComponent,TempleComponent];