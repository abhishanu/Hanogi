
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { AppRoutingModule, routedComponents } from './app-routing.module';
import { Http, HttpModule } from '@angular/http';
import { DataService } from './services/data.service';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './dashboard/header/header.component';
import { SidebarComponent } from './dashboard/sidebar/sidebar.component';
import { TempleComponent } from './dashboard/temple/temple.component';
import { TempleListComponent } from './dashboard/temple-list/temple-list.component';
import { AddPanditComponent } from './dashboard/add-pandit/add-pandit.component';
import { ManageRoleComponent } from './dashboard/manage-role/manage-role.component';
import { AlertComponent } from './dashboard/common/alert.component';
import { AuthConfig, AuthHttp } from 'angular2-jwt';
import { HttpClientModule } from "@angular/common/http";

export function authHttpServiceFactory(http: Http) {
  return new AuthHttp(new AuthConfig({
    headerPrefix: 'Bearer',
    tokenName: 'access_token',
    globalHeaders: [{'Content-Type': 'application/json'}],
    noJwtError: false,
    noTokenScheme: true,
    tokenGetter: (() => localStorage.getItem('access_token'))
  }), http);
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    SidebarComponent,
    TempleComponent,
    TempleListComponent,
    ManageRoleComponent,
    AddPanditComponent,
    routedComponents,
    AlertComponent
  ],
  imports: [
    HttpModule ,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [{provide: AuthHttp, useFactory: authHttpServiceFactory, deps: [Http]},
    DataService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
