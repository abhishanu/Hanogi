import { Component, OnInit } from '@angular/core';
import {HttpClient, HttpRequest, HttpEvent} from '@angular/common/http';
import { DataService } from '../../services/data.service';


@Component({
  selector: 'addpandit',
  templateUrl: './add-pandit.component.html'
})
export class AddPanditComponent implements OnInit {

  constructor(private dataService : DataService){

  }
  ngOnInit(){
  }


}
