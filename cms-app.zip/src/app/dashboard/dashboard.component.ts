import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { HeaderComponent} from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { TempleComponent} from './temple/temple.component';
import { TempleListComponent} from './temple-list/temple-list.component';
import { ManageRoleComponent } from './manage-role/manage-role.component';
import { AddPanditComponent } from './add-pandit/add-pandit.component';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent  {
 
}
