import { Component, OnInit } from '@angular/core';
import { Router, Route, ActivatedRoute } from '@angular/router';
import { DataService } from'../../services/data.service';
@Component({
  selector: 'manage-role',
  templateUrl: './manage-role.component.html'
})
export class ManageRoleComponent implements OnInit {
  searchResults:any;
  searchQuery:any;
  allUserRoles:any;
  param:any={}
  newRoleId:any=''
  userId:any='';
  isSuccessMsg= ''
  isErrorMsg= ''

  constructor(private dataService : DataService ){
  }
  ngOnInit(){
    this.dataService.fetchData("getAllRoles").subscribe(data =>{
      this.dataService.allUserRoles=data.json().response;
    })
  }
  searchUsers(searchForm){
    this.dataService.fetchData(`getUserDetail?id=${this.searchQuery}`).subscribe(data =>{
      this.searchResults= data.json().response;
    })
  }
  hideAlert(param){
      setTimeout(function() {
       param = '';
   }.bind(this), 3000);
  }
  selectedRole($event){
    this.newRoleId=$event.target.value;
  }
  updateUserRole(userId){
    this.param= {
      "requestType":"updateUserRole",
      "requestParam":{
        "userId":userId,
        "newRoleId": this.newRoleId
        }
      }
   this.dataService.postData("updateUserRole",this.param).subscribe(data=>{
        this.isSuccessMsg = data.json().response;
        this.hideAlert(this.isSuccessMsg)
   },error =>{
      this.isErrorMsg=error;
      this.hideAlert(this.isErrorMsg)
   })


  }
}
