package frnds.collie.services.collie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollieApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollieApplication.class, args);
	}

}

