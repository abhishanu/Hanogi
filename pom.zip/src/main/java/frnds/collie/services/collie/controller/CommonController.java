package frnds.collie.services.collie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import frnds.collie.services.collie.response.Response;
import frnds.collie.services.collie.security.configs.CurrentUser;
import frnds.collie.services.collie.security.configs.UserPrincipal;
import frnds.collie.services.collie.services.UserServices;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@Api(value = "Common System Services")
public class CommonController {

	@Autowired
	UserServices userServices;

	@PostAuthorize("isAnonymous() or isAuthenticated()")
	@GetMapping("/getUserMenu")
	@ApiOperation(value = "Get User Menu List on the base of login role.Default User_Role", response = String.class, consumes = "Expected Access token(OPTIONAL)")
	public Response getMenuList(@CurrentUser UserPrincipal currentUser) {
		if (currentUser != null) {
			String userId = currentUser.getUserId();
			return userServices.getUserMenu(userId);

		} else {
			return userServices.getUserMenu("3");
		}
	}
}
