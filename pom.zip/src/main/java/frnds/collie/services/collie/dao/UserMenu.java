package frnds.collie.services.collie.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import frnds.collie.services.collie.utilities.AuditFields;

@Entity
@Table(name = "User_Menu")
public class UserMenu extends AuditFields<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "User_Menu_Id")
	private Integer menuId;

	public Integer getMenuId() {
		return menuId;
	}

	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}

	public String getUserMenu() {
		return userMenu;
	}

	public void setUserMenu(String userMenu) {
		this.userMenu = userMenu;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	@Column(name = "User_Menu", columnDefinition = "TEXT")
	private String userMenu;

	@Column(name = "Is_Active")
	private String isActive;

}
