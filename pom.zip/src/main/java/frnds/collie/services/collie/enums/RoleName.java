package frnds.collie.services.collie.enums;

public enum RoleName {
	ROLE_USER, ROLE_ADMIN,ROLE_PANDIT,ROLE_TEMPLE,ROLE_SUPER_ADMIN
}
