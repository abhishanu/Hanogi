package frnds.collie.services.collie.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import frnds.collie.services.collie.dao.UserDetailsImpl;

@Repository
public interface UserDetailsRepositry extends CrudRepository<UserDetailsImpl, String> {

	Optional<UserDetailsImpl> findByUserName(String userName);
}
