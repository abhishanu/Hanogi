package frnds.collie.services.collie.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import frnds.collie.services.collie.dao.UserMenu;

@Repository
public interface UserMenuRepositry extends CrudRepository<UserMenu, Integer> {

}
