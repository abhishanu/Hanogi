package frnds.collie.services.collie.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import frnds.collie.services.collie.dao.UserRoles;

@Repository
public interface UserRolesRepositry extends CrudRepository<UserRoles, String> {

}
