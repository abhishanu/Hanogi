package frnds.collie.services.collie.response;

public enum ResponseStatus {
	OK, ERROR, BAD_REQUEST, INTERNAL_SERVER_ERROR, INVALID, NO_DATA_FOUND, UNAUTHORIZED
}
