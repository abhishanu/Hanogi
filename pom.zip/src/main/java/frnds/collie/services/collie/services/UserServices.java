package frnds.collie.services.collie.services;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import frnds.collie.services.collie.dao.UserDetailsImpl;
import frnds.collie.services.collie.dao.UserMenu;
import frnds.collie.services.collie.dao.UserRoles;
import frnds.collie.services.collie.repo.UserDetailsRepositry;
import frnds.collie.services.collie.repo.UserMenuRepositry;
import frnds.collie.services.collie.repo.UserRolesRepositry;
import frnds.collie.services.collie.response.Response;
import frnds.collie.services.collie.response.ResponseStatus;

@Service
public class UserServices {

	@Autowired
	private UserDetailsRepositry userDetailsRepositry;

	@Autowired
	private UserMenuRepositry menuRepositry;

	@Autowired
	private UserRolesRepositry userRolesRepositry;

	public void saveUserDetails(String userName) {
		UserDetailsImpl userDetails = new UserDetailsImpl();

		userDetails.setUserName(userName);
		userDetails.setFirstName("Abhi");
		userDetailsRepositry.save(userDetails);

	}

	public Response getUserMenu(String userId) {
		UserRoles userRole = userRolesRepositry.findOne(userId);
		
		if (userRole != null) {
			userRole.getRoleId();
		}
		Integer menuId=1;
		Response response = new Response();
		UserMenu userMenu = menuRepositry.findOne(menuId);

		if (userMenu != null) {
			String menu = userMenu.getUserMenu();

			response.setStatus(ResponseStatus.OK);
			response.setResponse(Arrays.asList(menu.split(",")));
			return response;

		} else {
			response.setStatus(ResponseStatus.NO_DATA_FOUND);
			response.setResponse(null);
			return response;
		}

	}

}
