package com.restApp.religiousIndia.common;

public enum TypeOfAvailability {
	PHONE, PERSONAL, VIDEO, MAIL_CHAT
}
