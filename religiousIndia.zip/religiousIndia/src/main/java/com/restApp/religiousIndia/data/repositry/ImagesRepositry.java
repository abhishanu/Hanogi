package com.restApp.religiousIndia.data.repositry;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.Image;

public interface ImagesRepositry extends CrudRepository<Image, String> {

	public static final String latest_Images = "select * from ri_image having is_active=?1 order by updated_on  desc limit 10";

	@Query(value = latest_Images, nativeQuery = true)
	public List<Image> getLatestUploadedImages(String isActive);
	
	public static final String Image_Id_from_Path="select Image_Id from RI_IMAGE where image_path =?1";
	@Query(value = Image_Id_from_Path, nativeQuery = true)
	public String getImageIdFromPath(String imagePath);
	
	
}
