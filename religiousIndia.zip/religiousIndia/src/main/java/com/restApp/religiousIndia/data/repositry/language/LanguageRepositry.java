package com.restApp.religiousIndia.data.repositry.language;

import org.springframework.data.jpa.repository.JpaRepository;

import com.restApp.religiousIndia.data.entities.language.Languages;

public interface LanguageRepositry extends JpaRepository<Languages, Integer> {

}
