package com.restApp.religiousIndia.data.repositry.login;

import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.login.LoginTypes;

public interface LoginTypesRepositry extends CrudRepository<LoginTypes, String> {

}
