package com.restApp.religiousIndia.data.repositry.pandit.availability;

import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.pandit.availability.PanditDailyAvailibility;

public interface PanditDailyAvailibilityRepositry extends CrudRepository<PanditDailyAvailibility, Integer> {

}
