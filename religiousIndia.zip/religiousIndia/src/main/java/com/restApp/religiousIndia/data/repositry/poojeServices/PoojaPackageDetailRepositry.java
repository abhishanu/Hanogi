package com.restApp.religiousIndia.data.repositry.poojeServices;

import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.pooja.PoojaPackageDetail;

public interface PoojaPackageDetailRepositry extends CrudRepository<PoojaPackageDetail, String> {

}
