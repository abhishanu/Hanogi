package com.restApp.religiousIndia.data.repositry.poojeServices;

import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.pooja.PoojaPackageFeature;

public interface PoojaPackageFeatureRepositrt extends CrudRepository<PoojaPackageFeature, String> {

}
