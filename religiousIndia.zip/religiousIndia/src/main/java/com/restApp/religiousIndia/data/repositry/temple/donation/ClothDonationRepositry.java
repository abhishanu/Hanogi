package com.restApp.religiousIndia.data.repositry.temple.donation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.temple.donation.ClothesDonation;

public interface ClothDonationRepositry extends CrudRepository<ClothesDonation, Integer> {
	ArrayList<ClothesDonation> findByTempleId(String templeId);

	/*
	 * public static final String Search_donation_Query =
	 * "SELECT * from ri_temple_donation_clothes where donation_sub_category_name Like '% ?1%' OR ENDDATE=?2 OR Temple_id=?3"
	 * ;
	 * 
	 * @Query(value = Search_donation_Query, nativeQuery = true)
	 * List<ClothesDonation> searchDonationResult(String donationName, String
	 * endDate, String templeId);
	 */

	public static final String Update_Donation_State = "update ri_temple_donation_clothes set is_active='0' where ENDDATE < CURDATE()";

	@Query(value = Update_Donation_State, nativeQuery = true)
	public void updateDonationState();

	List<ClothesDonation> findByDonationSubCategoryNameLikeOrEndDateOrTempleId(String donationName, Date endDate,
			String templeId);
}
