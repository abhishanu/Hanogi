package com.restApp.religiousIndia.data.repositry.temple.donation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.temple.donation.GirlChildMarriageDonation;

public interface GirlChildMarriageDonationRepositry extends CrudRepository<GirlChildMarriageDonation, Integer> {
	ArrayList<GirlChildMarriageDonation> findByTempleId(String templeId);
	
	public static final String Update_Donation_State = "update ri_temple_donation_girl_child_marriage set is_active='0' where ENDDATE < CURDATE()";

	@Query(value = Update_Donation_State, nativeQuery = true)
	public void updateDonationState();


	List<GirlChildMarriageDonation> findByDonationSubCategoryNameLikeOrEndDateOrTempleId(String donationName,
			Date endDate, String templeId);
}
