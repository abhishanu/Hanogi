package com.restApp.religiousIndia.data.repositry.temple.donation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.temple.donation.MedicineDonation;
import com.restApp.religiousIndia.data.entities.temple.donation.TempleNeedsDonation;

public interface MedicineDonationRepositry extends CrudRepository<MedicineDonation, Integer> {
	ArrayList<MedicineDonation> findByTempleId(String templeId);

	public static final String Update_Donation_State = "update ri_temple_donation_medicine set is_active='0' where ENDDATE < CURDATE()";

	@Query(value = Update_Donation_State, nativeQuery = true)
	public void updateDonationState();

	List<MedicineDonation> findByDonationSubCategoryNameLikeOrEndDateOrTempleId(String categoryName, Date endDate,
			String templeId);
}
