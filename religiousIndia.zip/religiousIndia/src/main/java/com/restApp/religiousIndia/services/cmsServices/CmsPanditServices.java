package com.restApp.religiousIndia.services.cmsServices;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restApp.religiousIndia.common.PanditCategoryId;
import com.restApp.religiousIndia.data.entities.Address;
import com.restApp.religiousIndia.data.entities.Image;
import com.restApp.religiousIndia.data.entities.language.PanditLanguage;
import com.restApp.religiousIndia.data.entities.pandit.CmsPanditDetails;
import com.restApp.religiousIndia.data.entities.pandit.PanditDetails;
import com.restApp.religiousIndia.data.entities.pandit.availability.PanditDailyAvailibility;
import com.restApp.religiousIndia.data.entities.users.UserDetailsImpl;
import com.restApp.religiousIndia.data.repositry.AddresssRepositry;
import com.restApp.religiousIndia.data.repositry.language.PanditLanguageRepositry;
import com.restApp.religiousIndia.data.repositry.pandit.CMSPanditDetailsRepositry;
import com.restApp.religiousIndia.data.repositry.pandit.PanditDetailsRepositry;
import com.restApp.religiousIndia.data.repositry.pandit.availability.PanditDailyAvailibilityRepositry;
import com.restApp.religiousIndia.data.repositry.poojeServices.PoojaServicesListRepositry;
import com.restApp.religiousIndia.data.repositry.users.UserDetailsRepositry;
import com.restApp.religiousIndia.request.filter.PostRequestWithObject;
import com.restApp.religiousIndia.response.Response;
import com.restApp.religiousIndia.response.status.ResponseStatus;
import com.restApp.religiousIndia.services.imageServices.RetriveImageService;
import com.restApp.religiousIndia.services.users.LoginService;

@Service
public class CmsPanditServices {
	private static Logger logger = Logger.getLogger(CmsPanditServices.class);

	@Autowired
	private CMSPanditDetailsRepositry cmsPanditDetailsRepositry;

	@Autowired
	private LoginService loginService;

	@Autowired
	private PanditDetailsRepositry panditDetailsRepositry;

	@Autowired
	private PanditDailyAvailibilityRepositry panditDailyAvailibilityRepositry;

	@Autowired
	private PoojaServicesListRepositry poojaServicesListRepositry;

	@Autowired
	private UserDetailsRepositry userDetailsRepositry;

	@Autowired
	private RetriveImageService imageService;

	@Autowired
	private AddresssRepositry addressRepo;

	@Autowired
	private PanditLanguageRepositry languageRepositry;

	@Transactional
	public Response saveNewPanditDetails(PostRequestWithObject request) {
		logger.info("saveNewPanditDetails method");
		Response response = new Response();

		if (request != null) {
			if (request.getRequestType() != null) {
				if (request.getRequestType().equalsIgnoreCase("saveNewPanditDetails")) {
					Map<String, Object> requestMap = request.getRequestParam();
					if (requestMap != null) {
						try {
							if (requestMap.size() != 0) {
								Boolean isNewUser = (Boolean) requestMap.get("isNewUser");

								if (isNewUser != null) {
									CmsPanditDetails cmsPanditDetails = new CmsPanditDetails();
									if (isNewUser) {
										cmsPanditDetails.setIsNewUser("1");
										Map<String, String> signUpDetails = (Map<String, String>) requestMap
												.get("signUpDetails");

										Response userSignUp = userSignUp(signUpDetails);

										if (userSignUp != null) {
											if (userSignUp.getStatus().equals(ResponseStatus.OK)) {
												Integer isSignedUp = (Integer) userSignUp.getResponse();

												if (isSignedUp != null) {
													cmsPanditDetails.setUserId(isSignedUp);
													response = createCmsPanditDetail(requestMap, cmsPanditDetails);
													return response;
												} else {
													response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
													response.setResponse("Error while crating user");
													return response;
												}

											} else {
												return userSignUp;
											}
										} else {
											response.setStatus(ResponseStatus.ERROR);
											response.setResponse("User details not saved due to some error");
											return response;
										}

									} else {
										cmsPanditDetails.setIsNewUser("0");
										String userId = (String) requestMap.get("userId");
										if (userId != null) {
											cmsPanditDetails.setUserId(new Integer(userId));
											response = createCmsPanditDetail(requestMap, cmsPanditDetails);
											return response;
										} else {
											response.setStatus(ResponseStatus.INVALID);
											response.setResponse("Please provide pandit userId");
											return response;
										}

									}
								} else {
									response.setStatus(ResponseStatus.BAD_REQUEST);
									response.setResponse(
											"please provide detail that is user is new one or already has an account as normal user");
								}

							} else {
								response.setStatus(ResponseStatus.BAD_REQUEST);
								response.setResponse("Request param required.");
								return response;
							}
						} catch (Exception e) {
							response.setStatus(ResponseStatus.BAD_REQUEST);
							response.setResponse("Request is not as expected");
							return response;
						}
					} else {
						response.setStatus(ResponseStatus.BAD_REQUEST);
						response.setResponse("Request param cant't be blank");
					}
				} else {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("Request type not matched");
				}
			} else {
				response.setStatus(ResponseStatus.BAD_REQUEST);
				response.setResponse("Request type cant't be blank");
			}
		} else {
			response.setStatus(ResponseStatus.BAD_REQUEST);
			response.setResponse("Request can't be blank.");
		}
		return response;
	}

	@Transactional
	public Response saveNewPanditDetailsAsVerified(PostRequestWithObject request) {
		logger.info("/saveNewPanditDetailsAsVerified method");
		Response response = new Response();

		if (request != null) {
			if (request.getRequestType() != null) {
				if (request.getRequestType().equalsIgnoreCase("saveNewPanditDetailsAsVerified")) {
					Map<String, Object> requestMap = request.getRequestParam();
					if (requestMap != null) {
						try {
							if (requestMap.size() != 0) {
								Boolean isNewUser = (Boolean) requestMap.get("isNewUser");

								if (isNewUser != null) {
									CmsPanditDetails cmsPanditDetails = new CmsPanditDetails();
									if (isNewUser) {

										cmsPanditDetails.setIsNewUser("1");

										Map<String, String> signUpDetails = (Map<String, String>) requestMap
												.get("signUpDetails");

										Response userSignUp = userSignUp(signUpDetails);

										if (userSignUp != null) {
											if (userSignUp.getStatus().equals(ResponseStatus.OK)) {
												Integer isSignedUp = (Integer) userSignUp.getResponse();

												if (isSignedUp != null) {
													cmsPanditDetails.setUserId(isSignedUp);
													response = createCmsPanditDetailForVerified(requestMap,
															cmsPanditDetails);
													if (response.getStatus().equals(ResponseStatus.OK)) {
														String cmsPanditId = (String) response.getResponse();

														response = savePanditAsVerfied(cmsPanditId);
													} else {
														response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
														response.setResponse("Something went wrong");
														return response;
													}
												} else {
													response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
													response.setResponse("Error while crating user");
													return response;
												}

											} else {
												return userSignUp;
											}
										} else {
											response.setStatus(ResponseStatus.ERROR);
											response.setResponse("User details not saved due to some error");
											return response;
										}

									} else {
										cmsPanditDetails.setIsNewUser("0");
										String userId = (String) requestMap.get("userId");
										if (userId != null) {
											cmsPanditDetails.setUserId(new Integer(userId));
											response = createCmsPanditDetailForVerified(requestMap, cmsPanditDetails);
											if (response.getStatus().equals(ResponseStatus.OK)) {
												String cmsPanditId = (String) response.getResponse();

												response = savePanditAsVerfied(cmsPanditId);
											} else {
												response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
												response.setResponse("Something went wrong");
												return response;
											}

										} else {
											response.setStatus(ResponseStatus.INVALID);
											response.setResponse("Please provide pandit userId");
											return response;
										}

									}
								} else {
									response.setStatus(ResponseStatus.BAD_REQUEST);
									response.setResponse(
											"please provide detail that is user is new one or already has an account as normal user");
								}

							} else {
								response.setStatus(ResponseStatus.BAD_REQUEST);
								response.setResponse("Request param required.");
								return response;
							}
						} catch (Exception e) {
							response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
							response.setResponse("Something went wrong");
							return response;
						}
					} else {
						response.setStatus(ResponseStatus.BAD_REQUEST);
						response.setResponse("Request param cant't be blank");
					}
				} else {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("Request type not matched");
				}
			} else {
				response.setStatus(ResponseStatus.BAD_REQUEST);
				response.setResponse("Request type cant't be blank");
			}
		} else {
			response.setStatus(ResponseStatus.BAD_REQUEST);
			response.setResponse("Request can't be blank.");
		}
		return response;
	}

	private Response userSignUp(Map<String, String> details) {

		details.put("roleId", "2");
		details.put("email", "");

		Response signUpResponse = loginService.createUserDetails(details);

		if (signUpResponse.getStatus().equals(ResponseStatus.OK)) {
			UserDetailsImpl userDetails = (UserDetailsImpl) signUpResponse.getResponse();

			Integer userId = userDetails.getUserId();

			signUpResponse.setStatus(ResponseStatus.OK);
			signUpResponse.setResponse(userId);

		} else {
			logger.error("User signUp failed during adding new pandit details");
			logger.error(signUpResponse.getResponse());
			signUpResponse.setStatus(ResponseStatus.ERROR);
			signUpResponse.setResponse("User signUp failed during adding new pandit details");
		}
		return signUpResponse;
	}

	private String createTimingJsonObject(Map<String, String> dailyTiming) {
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject(dailyTiming);
		jsonArray.put(jsonObject);
		return jsonArray.toString();
	}

	private String createJsonObject(List<Map<String, String>> detailsObject) {
		try {
			if (detailsObject != null) {
				JSONArray jsonArray = new JSONArray();
				for (Map<String, String> map : detailsObject) {
					JSONObject jsonObject = new JSONObject(map);
					jsonArray.put(jsonObject);
				}
				return jsonArray.toString();
			} else {
				return "";
			}
		} catch (Exception e) {
			logger.error("Error in createJsonObject:" + e);
			return "";
		}
	}

	private Response createCmsPanditDetail(Map<String, Object> requestMap, CmsPanditDetails cmsPanditDetails) {
		Response response = new Response();
		String aboutPandit = (String) requestMap.get("aboutPandit");

		if (aboutPandit != null) {
			List<Map<String, String>> qualificationList = (List<Map<String, String>>) requestMap.get("qualification");
			// String qualification = String.join(",", qualificationList);

			if (qualificationList != null) {
				if (qualificationList.size() != 0) {
					String qualification = getQualificationObject(qualificationList);

					List<Map<String, String>> specilaizationList = (List<Map<String, String>>) requestMap
							.get("specilaization");

					String specilaization = getQualificationObject(specilaizationList);

					if (specilaizationList != null) {
						if (specilaizationList.size() != 0) {
							cmsPanditDetails.setSpecilaization(specilaization);
						}
					}

					String poojaServedList = (String) requestMap.get("poojaServedList");

					if (poojaServedList != null) {
						if (!poojaServedList.isEmpty()) {
							cmsPanditDetails.setPoojaServiceList(poojaServedList);
						}
					}

					Map<String, String> addressMap = (Map<String, String>) requestMap.get("addressDetails");

					if (addressMap != null) {
						if (!addressMap.isEmpty()) {
							Address panditAddress = saveAddressDataForPandit(addressMap);

							cmsPanditDetails.setPanditAddress(panditAddress.toString());
						} else {
							logger.warn("pandit cms address details are blank");
						}
					}

					List<String> specilaizationPoojaList = (List<String>) requestMap.get("specilaizationPooja");

					if (specilaizationPoojaList != null) {
						if (specilaizationPoojaList.size() != 0) {
							String specilaizationPooja = String.join(",", specilaizationPoojaList);
							cmsPanditDetails.setSpecilaizationPooja(specilaizationPooja);
						}
					}

					/*
					 * List<TypeOfAvailability> typeOfAvailabilityList = (List<TypeOfAvailability>)
					 * requestMap .get("typeOfAvailability");
					 */

					List<Map<String, String>> languagesList = (List<Map<String, String>>) requestMap
							.get("languagesList");

					if (languagesList != null) {
						cmsPanditDetails.setLanguages(languagesList.toString());
					}

					Boolean isFreeLancer = (Boolean) requestMap.get("isFreeLancer");

					Boolean isAssociatedWithTemple = (Boolean) requestMap.get("isAssociatedWithTemple");
					if (isFreeLancer != null) {
						if (isFreeLancer) {
							cmsPanditDetails.setIsFreeLancer("1");
						} else {

							if (isAssociatedWithTemple != null) {
								if (isAssociatedWithTemple) {
									cmsPanditDetails.setIsAssociatedWithTemple("1");
								} else {
									cmsPanditDetails.setIsAssociatedWithTemple("0");
								}

								List<String> templeIdList = (List<String>) requestMap.get("templeIdList");
								String templeId = String.join(",", templeIdList);

								if (templeIdList != null) {
									if (templeIdList.size() != 0) {
										cmsPanditDetails.setTempleIdList(templeId);
									} else {
										response.setStatus(ResponseStatus.INVALID);
										response.setResponse("List of associated temple id is blank");
										return response;
									}
								} else {
									response.setStatus(ResponseStatus.INVALID);
									response.setResponse("List of associated temple id is missing");
									return response;
								}
							} else {
								response.setStatus(ResponseStatus.INVALID);
								response.setResponse(
										"Pandit ji association with temple is compulsory because he is not a freelancer");
								return response;
							}

						}
					} else {
						if (isAssociatedWithTemple != null) {
							if (isAssociatedWithTemple) {
								cmsPanditDetails.setIsAssociatedWithTemple("1");
							} else {
								cmsPanditDetails.setIsAssociatedWithTemple("0");
							}

							List<String> templeIdList = (List<String>) requestMap.get("templeIdList");
							String templeId = String.join(",", templeIdList);

							if (templeIdList != null) {
								if (templeIdList.size() != 0) {
									cmsPanditDetails.setTempleIdList(templeId);
								} else {
									response.setStatus(ResponseStatus.INVALID);
									response.setResponse("List of associated temple id is blank");
									return response;
								}
							} else {
								response.setStatus(ResponseStatus.INVALID);
								response.setResponse("List of associated temple id is missing");
								return response;
							}
						} else {
							response.setStatus(ResponseStatus.INVALID);
							response.setResponse(
									"Pandit ji Either be a freelancer or his association with temple is compulsory");
							return response;
						}
					}

					Boolean isAvailableOnALlDays = (Boolean) requestMap.get("isAvailableOnALlDays");

					if (isAvailableOnALlDays != null) {
						if (isAvailableOnALlDays) {

							if (isAvailableOnALlDays) {
								cmsPanditDetails.setIsAvailableOnALlDays("1");
							} else {
								cmsPanditDetails.setIsAvailableOnALlDays("0");
							}

							String generalAvailablityTiming = (String) requestMap.get("generalAvailablityTiming");
							cmsPanditDetails.setGeneralAvailablityTiming(generalAvailablityTiming);
						}
					} else {
						cmsPanditDetails.setIsAvailableOnALlDays("0");
					}

					String imageId = (String) requestMap.get("imageId");

					if (imageId != null) {
						if (!imageId.isEmpty()) {
							cmsPanditDetails.setImageId(imageId);
						}
					}

					List<Map<String, String>> dailyTiming = (List<Map<String, String>>) requestMap.get("dailyTiming");

					List<Map<String, String>> awardsDetails = (List<Map<String, String>>) requestMap
							.get("awardsDetails");

					List<Map<String, String>> articlesDetails = (List<Map<String, String>>) requestMap
							.get("articlesDetails");

					cmsPanditDetails.setPanditDesc(aboutPandit);
					cmsPanditDetails.setQualification(qualification);

					// cmsPanditDetails.setTypeOfAvailbility(typeOfAvailabilityList);

					if (dailyTiming != null) {
						if (!dailyTiming.isEmpty()) {
							cmsPanditDetails
									.setPanditDailyAvailablityTiming(createTimingJsonObject(dailyTiming.get(0)));
						} else {

						}
					} else {

					}

					cmsPanditDetails.setAwardsDetails(createJsonObject(awardsDetails));

					cmsPanditDetails.setArticlesDetails(createJsonObject(articlesDetails));

					CmsPanditDetails isSaved = cmsPanditDetailsRepositry.save(cmsPanditDetails);

					if (isSaved != null) {
						response.setStatus(ResponseStatus.OK);
						response.setResponse("Pandit details saved successfully");
						return response;
					}
				} else {
					response.setStatus(ResponseStatus.INVALID);
					response.setResponse("Qualification list can'nt be blank");
					return response;
				}
			} else {
				response.setStatus(ResponseStatus.INVALID);
				response.setResponse("Please provide qualification of pandit ji");
				return response;
			}
		} else {
			response.setStatus(ResponseStatus.INVALID);
			response.setResponse("Please provide desc of pandit ji");
			return response;
		}
		return response;

	}

	private String getQualificationObject(List<Map<String, String>> qualificationList) {
		String qualification = null;
		List<String> object = new ArrayList<>(qualificationList.size());

		for (Map<String, String> qualificationObject : qualificationList) {
			object.add(qualificationObject.get("name"));
		}

		qualification = String.join(",", object);

		return qualification;
	}

	private Response createCmsPanditDetailForVerified(Map<String, Object> requestMap,
			CmsPanditDetails cmsPanditDetails) {

		Response response = new Response();
		String aboutPandit = (String) requestMap.get("aboutPandit");

		if (aboutPandit != null) {
			String panditId = (String) requestMap.get("panditId");

			if (panditId != null) {
				cmsPanditDetails = cmsPanditDetailsRepositry.findOne(panditId);
			}
			List<Map<String, String>> qualificationList = (List<Map<String, String>>) requestMap.get("qualification");

			if (qualificationList != null) {
				if (qualificationList.size() != 0) {
					String qualification = getQualificationObject(qualificationList);
					List<Map<String, String>> specilaizationList = (List<Map<String, String>>) requestMap
							.get("specilaization");
					// String specilaization = String.join(",",
					// specilaizationList);

					if (specilaizationList != null) {
						if (specilaizationList.size() != 0) {
							String specilaization = getQualificationObject(specilaizationList);

							cmsPanditDetails.setSpecilaization(specilaization);

						}
					}

					List<String> specilaizationPoojaList = (List<String>) requestMap.get("specilaizationPooja");
					String specilaizationPooja = String.join(",", specilaizationPoojaList);

					if (specilaizationPoojaList != null) {
						if (specilaizationPoojaList.size() != 0) {
							cmsPanditDetails.setSpecilaizationPooja(specilaizationPooja);
						}
					}

					String poojaServedList = (String) requestMap.get("poojaServedList");

					if (poojaServedList != null) {
						if (!poojaServedList.isEmpty()) {
							cmsPanditDetails.setPoojaServiceList(poojaServedList);
						}
					}

					Map<String, String> addressMap = (Map<String, String>) requestMap.get("addressDetails");

					if (addressMap != null) {
						if (!addressMap.isEmpty()) {
							Address panditAddress = saveAddressDataForPandit(addressMap);

							Address isAddressSaved = addressRepo.save(panditAddress);

							if (isAddressSaved != null) {
								cmsPanditDetails.setPanditAddress(isAddressSaved.getId() + "");
							} else {
								logger.warn("Pandit address not saved");
							}
						} else {
							logger.warn("pandit cms address details are blank");
						}
					}

					/*
					 * List<TypeOfAvailability> typeOfAvailabilityList = (List<TypeOfAvailability>)
					 * requestMap .get("typeOfAvailability");
					 */
					Boolean isFreeLancer = (Boolean) requestMap.get("isFreeLancer");
					Boolean isAssociatedWithTemple = (Boolean) requestMap.get("isAssociatedWithTemple");
					if (isFreeLancer != null) {
						if (isFreeLancer) {
							cmsPanditDetails.setIsFreeLancer("1");
						} else {

							if (isAssociatedWithTemple != null) {
								if (isAssociatedWithTemple) {
									cmsPanditDetails.setIsAssociatedWithTemple("1");
								} else {
									cmsPanditDetails.setIsAssociatedWithTemple("0");
								}

								List<String> templeIdList = (List<String>) requestMap.get("templeIdList");
								String templeId = String.join(",", templeIdList);

								if (templeIdList != null) {
									if (templeIdList.size() != 0) {
										cmsPanditDetails.setTempleIdList(templeId);
									} else {
										response.setStatus(ResponseStatus.INVALID);
										response.setResponse("List of associated temple id is blank");
										return response;
									}
								} else {
									response.setStatus(ResponseStatus.INVALID);
									response.setResponse("List of associated temple id is missing");
									return response;
								}
							} else {
								response.setStatus(ResponseStatus.INVALID);
								response.setResponse(
										"Pandit ji association with temple is compulsory because he is not a freelancer");
								return response;
							}

						}
					} else {
						if (isAssociatedWithTemple != null) {
							if (isAssociatedWithTemple) {
								cmsPanditDetails.setIsAssociatedWithTemple("1");
							} else {
								cmsPanditDetails.setIsAssociatedWithTemple("0");
							}

							List<String> templeIdList = (List<String>) requestMap.get("templeIdList");
							String templeId = String.join(",", templeIdList);

							if (templeIdList != null) {
								if (templeIdList.size() != 0) {
									cmsPanditDetails.setTempleIdList(templeId);
								} else {
									response.setStatus(ResponseStatus.INVALID);
									response.setResponse("List of associated temple id is blank");
									return response;
								}
							} else {
								response.setStatus(ResponseStatus.INVALID);
								response.setResponse("List of associated temple id is missing");
								return response;
							}
						} else {
							response.setStatus(ResponseStatus.INVALID);
							response.setResponse(
									"Pandit ji Either be a freelancer or his association with temple is compulsory");
							return response;
						}
					}

					Boolean isAvailableOnALlDays = (Boolean) requestMap.get("isAvailableOnALlDays");

					if (isAvailableOnALlDays != null) {
						if (isAvailableOnALlDays) {
							cmsPanditDetails.setIsAvailableOnALlDays(isAvailableOnALlDays ? "1" : "0");

							String generalAvailablityTiming = (String) requestMap.get("generalAvailablityTiming");
							cmsPanditDetails.setGeneralAvailablityTiming(generalAvailablityTiming);
						}
					} else {
						cmsPanditDetails.setIsAvailableOnALlDays("0");
					}

					String imageId = (String) requestMap.get("imageId");

					if (imageId != null) {
						if (!imageId.isEmpty()) {
							boolean isImagePath = imageId.matches("Rel(.*)");

							if (!isImagePath) {
								String[] split = imageId.split("/");

								if (split.length > 1) {
									imageId = split[1];
								} else {
									imageId = split[0];
								}
								String imageIdFromPath = imageService.getImageIdFromPath(imageId);

								if (imageIdFromPath != null) {
									cmsPanditDetails.setImageId(imageIdFromPath);
								} else {
									cmsPanditDetails.setImageId("40");
								}
							} else {
								cmsPanditDetails.setImageId(imageId);
							}

						}
					}

					List<Map<String, String>> dailyTiming = (List<Map<String, String>>) requestMap.get("dailyTiming");

					List<Map<String, String>> awardsDetails = (List<Map<String, String>>) requestMap
							.get("awardsDetails");

					List<Map<String, String>> articlesDetails = (List<Map<String, String>>) requestMap
							.get("articlesDetails");

					cmsPanditDetails.setPanditDesc(aboutPandit);
					cmsPanditDetails.setQualification(qualification);

					// cmsPanditDetails.setTypeOfAvailbility(typeOfAvailabilityList);

					if (dailyTiming != null) {
						if (!dailyTiming.isEmpty()) {
							cmsPanditDetails
									.setPanditDailyAvailablityTiming(createTimingJsonObject(dailyTiming.get(0)));
						} else {

						}
					}

					cmsPanditDetails.setAwardsDetails(createJsonObject(awardsDetails));

					cmsPanditDetails.setArticlesDetails(createJsonObject(articlesDetails));

					CmsPanditDetails isSaved = cmsPanditDetailsRepositry.save(cmsPanditDetails);

					if (isSaved != null) {
						logger.info("Pandit Details Updated SuccessFully");
						response.setStatus(ResponseStatus.OK);
						response.setResponse(isSaved.getPanditId());
						return response;
					}
				} else {
					response.setStatus(ResponseStatus.INVALID);
					response.setResponse("Qualification list can'nt be blank");
					return response;
				}
			} else {
				response.setStatus(ResponseStatus.INVALID);
				response.setResponse("Please provide qualification of pandit ji");
				return response;
			}
		} else {
			response.setStatus(ResponseStatus.INVALID);
			response.setResponse("Please provide desc of pandit ji");
			return response;
		}
		return response;

	}

	public Response getUnverifiedPanditsList() {
		Response response = new Response();
		List<CmsPanditDetails> cmsPandits = cmsPanditDetailsRepositry.getCmsPandits();

		List<Map<String, Object>> detailsList = createPanditDetails(cmsPandits);

		if (cmsPandits != null) {
			if (cmsPandits.size() != 0) {
				if (detailsList != null) {
					response.setStatus(ResponseStatus.OK);
					response.setResponse(detailsList);
					return response;
				} else {
					response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
					response.setResponse("Something went wrong.Please try later.");
					return response;
				}

			} else {
				response.setStatus(ResponseStatus.NO_DATA_FOUND);
				response.setResponse("No pandit entry found in CMS");
				return response;
			}
		} else {
			response.setStatus(ResponseStatus.NO_DATA_FOUND);
			response.setResponse("No record");
			return response;
		}
	}

	private List<Map<String, Object>> createPanditDetails(List<CmsPanditDetails> cmsPandits) {
		List<Map<String, Object>> list = new ArrayList<>();

		for (CmsPanditDetails cmsPanditDetails : cmsPandits) {
			Map<String, Object> map = new HashMap<>();
			map.put("isFreeLancer",
					(cmsPanditDetails.getIsFreeLancer() != null) ? cmsPanditDetails.getIsFreeLancer() : "");
			map.put("panditId", (cmsPanditDetails.getPanditId() != null) ? cmsPanditDetails.getPanditId() : "");
			map.put("isAssociatedWithTemple",
					(cmsPanditDetails.getIsAssociatedWithTemple() != null)
							? cmsPanditDetails.getIsAssociatedWithTemple()
							: "");
			map.put("panditDesc", (cmsPanditDetails.getPanditDesc() != null) ? cmsPanditDetails.getPanditDesc() : "");

			String specilaization = cmsPanditDetails.getSpecilaization();
			if (specilaization != null) {
				if (!specilaization.isEmpty()) {
					map.put("specilaization", cmsPanditDetails.getSpecilaization().split(","));
				} else {
					map.put("specilaization", "");
				}
			} else {
				map.put("specilaization", "");
			}

			String specilaizationPooja = cmsPanditDetails.getSpecilaizationPooja();

			if (specilaizationPooja != null) {
				if (!specilaizationPooja.isEmpty()) {
					map.put("specilaizationPooja", cmsPanditDetails.getSpecilaizationPooja().split(","));
				} else {
					map.put("specilaizationPooja", "");
				}
			} else {
				map.put("specilaizationPooja", "");
			}

			String templeIdList = cmsPanditDetails.getTempleIdList();

			if (templeIdList != null) {
				if (!templeIdList.isEmpty()) {
					map.put("templeIdList", cmsPanditDetails.getTempleIdList().split(","));
				} else {
					map.put("templeIdList", "");
				}
			} else {
				map.put("templeIdList", "");
			}

			String qualification = cmsPanditDetails.getQualification();

			if (qualification != null) {
				if (!qualification.isEmpty()) {
					map.put("qualification", cmsPanditDetails.getQualification().split(","));
				} else {
					map.put("qualification", "");
				}
			} else {
				map.put("qualification", "");
			}

			map.put("isAvailableOnALlDays", cmsPanditDetails.getIsAvailableOnALlDays());
			map.put("generalAvailablityTiming", cmsPanditDetails.getGeneralAvailablityTiming());
			map.put("panditDailyAvailablityTiming", cmsPanditDetails.getPanditDailyAvailablityTiming());

			String awardsDetails = cmsPanditDetails.getAwardsDetails();
			if (awardsDetails != null) {
				awardsDetails = updateAwardsObjectImageToShow(awardsDetails);

			}
			map.put("awardsDetails", awardsDetails);

			map.put("articlesDetails", cmsPanditDetails.getArticlesDetails());

			// TO_DO make change In this static content
			map.put("typeOfAvailability", "PERSONAL");

			String panditAddressData = cmsPanditDetails.getPanditAddress();

			if (panditAddressData != null) {
				Map<String, String> addressObject = getAddressDetails(panditAddressData);
				map.put("addressDetails", addressObject);
			}

			String imageId = cmsPanditDetails.getImageId();

			if (imageId != null) {
				if (!imageId.isEmpty()) {
					map.put("imageId", "images/" + imageService.getImagePath(imageId));
				}
			} else {
				// Default Image if no Image Saved
				map.put("imageId", "images/" + imageService.getImagePath("40"));
			}

			Integer userId = cmsPanditDetails.getUserId();
			UserDetailsImpl userDetails = userDetailsRepositry.findByUserId(userId);

			if (userDetails == null) {
				logger.error("No record found for userId:" + userId);
			}

			String name = userDetails.getFirstName() + " " + userDetails.getMiddleName() + " "
					+ userDetails.getLastName();

			map.put("panditName", name);

			String gender = userDetails.getGender();

			map.put("gender", gender);

			String contact = (userDetails.getPrimaryPhone() != null) ? userDetails.getPrimaryPhone() : "";

			map.put("contact", contact);

			list.add(map);
		}
		return list;
	}

	private String updateAwardsObjectImageToShow(String awardsDetails) {
		try {
			JSONArray jsonArray = new JSONArray(awardsDetails);
			JSONArray jsonArrayNew = new JSONArray();
			int length = jsonArray.length();
			if (length > 0) {
				for (int i = 0; i < length; i++) {
					JSONObject jsonObject = jsonArray.getJSONObject(i);

					String imageId = jsonObject.getString("Image_Id");

					if (imageId != null) {
						if (!imageId.isEmpty()) {
							jsonObject.put("Image_Id", "images/" + imageService.getImagePath(imageId));
						}
					}
					jsonArrayNew.put(jsonObject);
				}
				return jsonArrayNew.toString();
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}

	}

	private Map<String, String> getAddressDetails(String panditAddressData) {
		Map<String, String> addressDetailMap = new LinkedHashMap<>();
		try {
			JSONObject jsonObject = new JSONObject(panditAddressData);

			addressDetailMap.put("address", jsonObject.getString("addressDetail"));
			addressDetailMap.put("city", jsonObject.getString("city"));
			addressDetailMap.put("dist", jsonObject.getString("dist"));
			addressDetailMap.put("addressContactNo", jsonObject.getString("addressContactNo"));
			addressDetailMap.put("state", jsonObject.getString("state"));

		} catch (JSONException e) {
			logger.error("Error while creating address Object from address string");
			return addressDetailMap;
		}

		return addressDetailMap;
	}

	@Transactional
	public Response savePanditAsVerfied(String cmsPanditId) {
		Response response = new Response();
		CmsPanditDetails cmsPanditDetails = cmsPanditDetailsRepositry.findOne(cmsPanditId);

		if (cmsPanditDetails != null) {
			PanditDetails pandit = new PanditDetails();

			pandit.setIsActive("1");

			String imageId = cmsPanditDetails.getImageId();

			if (imageId != null) {
				if (!imageId.isEmpty()) {
					pandit.setImageId("40");
				} else {
					if (!imageId.equals("40")) {
						boolean imageIdIsImagePath = imageId.matches("(.*).(.*)");

						if (imageIdIsImagePath) {
							logger.info("Image Path Found instead of imageId");

						} else {
							updateImagePath(imageId);
							pandit.setImageId(imageId);
						}

					}
				}
			} else {
				pandit.setImageId("40");
			}

			pandit.setPanditDesc(cmsPanditDetails.getPanditDesc());

			pandit.setIsAssociatedWithTemple(cmsPanditDetails.getIsAssociatedWithTemple());

			pandit.setIsFreeLancer(cmsPanditDetails.getIsFreeLancer());

			pandit.setPanditRating(0.0);

			pandit.setPanditCategoryId(PanditCategoryId.NEW);

			pandit.setAwardsDetails(cmsPanditDetails.getAwardsDetails());

			pandit.setArticlesDetails(cmsPanditDetails.getArticlesDetails());

			pandit.setQualification(cmsPanditDetails.getQualification());

			pandit.setReviewers(0);

			pandit.setSpecilaization(cmsPanditDetails.getSpecilaization());

			pandit.setSpecilaizationPooja(cmsPanditDetails.getSpecilaizationPooja());

			pandit.setTempleIdList(cmsPanditDetails.getTempleIdList());

			pandit.setPanditJoinDate(new Date());

			pandit.setUserId(cmsPanditDetails.getUserId());

			UserDetailsImpl userDetails = userDetailsRepositry.findOne(cmsPanditDetails.getUserId());

			if (userDetails != null) {
				Address saveAddressDataForPandit = saveAddressDataForPandit(cmsPanditDetails.getPanditAddress());

				if (saveAddressDataForPandit == null) {
					userDetails.setAddressId(null);
				} else {
					Address isAddressSaved = addressRepo.save(saveAddressDataForPandit);
					if (isAddressSaved != null) {
						userDetails.setAddressId(isAddressSaved.getId() + "");
					} else {
						userDetails.setAddressId(null);
					}
				}

				userDetailsRepositry.save(userDetails);
			}

			PanditDailyAvailibility dailyTiming = saveDailyTiming(cmsPanditDetails.getGeneralAvailablityTiming(),
					cmsPanditDetails.getIsAvailableOnALlDays(), cmsPanditDetails.getPanditDailyAvailablityTiming());

			if (dailyTiming != null) {
				pandit.setPanditDailyAvailablityTiming(dailyTiming);
			}

			String languages = cmsPanditDetails.getLanguages();

			PanditDetails isSaved = panditDetailsRepositry.save(pandit);

			if (isSaved != null) {
				if (languages != null) {
					saveLanguageDetailsOfPandit(languages);
				}

				cmsPanditDetailsRepositry.delete(cmsPanditId);
				response.setStatus(ResponseStatus.OK);
				response.setResponse("Record verfied and saved successfully");
				return response;

			} else {
				response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
				response.setResponse("Record not verfied successfully");
				return response;
			}
		} else {
			response.setStatus(ResponseStatus.NO_DATA_FOUND);
			response.setResponse("No record found");
			return response;
		}

	}

	private void saveLanguageDetailsOfPandit(String languages) {
		String[] languagesList = languages.split(",");

	}

	private void updateImagePath(String imageId) {
		Image image = imageService.getImage(imageId);

		image.setImagePath("images/" + image.getImagePath());

		imageService.saveImageToDb(image);

	}

	private PanditDailyAvailibility saveDailyTiming(String generalAvailablityTiming, String isAvailableOnALlDays,
			String panditDailyAvailablityTiming) {
		PanditDailyAvailibility dailyTiming = new PanditDailyAvailibility();

		if (isAvailableOnALlDays != null) {
			if (isAvailableOnALlDays.equals("1")) {
				dailyTiming.setIsAvailableOnALlDays("1");

				dailyTiming.setGeneralAvailablityTiming(generalAvailablityTiming);

				PanditDailyAvailibility isSaved = panditDailyAvailibilityRepositry.save(dailyTiming);

				if (isSaved != null) {
					return isSaved;
				}
			} else {
				dailyTiming.setIsAvailableOnALlDays("0");

				Boolean isSet = setDailyTiming(panditDailyAvailablityTiming, dailyTiming);

				if (isSet) {
					PanditDailyAvailibility isSaved = panditDailyAvailibilityRepositry.save(dailyTiming);

					if (isSaved != null) {
						return isSaved;
					}

				}
			}
		} else {
			dailyTiming.setIsAvailableOnALlDays("0");

			Boolean isSet = setDailyTiming(panditDailyAvailablityTiming, dailyTiming);

			if (isSet) {
				PanditDailyAvailibility isSaved = panditDailyAvailibilityRepositry.save(dailyTiming);

				if (isSaved != null) {
					return isSaved;
				}

			}
		}
		return null;
	}

	private Boolean setDailyTiming(String panditDailyAvailablityTiming, PanditDailyAvailibility dailyTiming) {
		try {
			if (panditDailyAvailablityTiming != null) {
				JSONArray jsonArray = new JSONArray(panditDailyAvailablityTiming);

				JSONObject jsonObject = (JSONObject) jsonArray.get(0);

				dailyTiming.setFridayTiming(jsonObject.getString("FRI"));
				dailyTiming.setThursdayTiming(jsonObject.getString("THU"));
				dailyTiming.setThuesdayTiming(jsonObject.getString("TUE"));
				dailyTiming.setWednesdayTiming(jsonObject.getString("WED"));
				dailyTiming.setSaturdayTiming(jsonObject.getString("SAT"));
				dailyTiming.setMondayTiming(jsonObject.getString("MON"));
				dailyTiming.setSundayTiming(jsonObject.getString("SUN"));

				dailyTiming = panditDailyAvailibilityRepositry.save(dailyTiming);

				if (dailyTiming != null) {
					return true;
				} else {
					return false;
				}

			} else {
				return false;
			}
		} catch (Exception e) {
			logger.error("Error in setDailyTiming:" + e);
			return false;
		}

	}

	public Response getAllPoojaServicesList() {
		Response response = new Response();
		List<String> allServicesName = poojaServicesListRepositry.getAllServicesName();

		if (allServicesName != null) {
			response.setStatus(ResponseStatus.OK);
			response.setResponse(allServicesName);
			return response;
		} else {
			response.setStatus(ResponseStatus.NO_DATA_FOUND);
			response.setResponse("No record found");
			return response;
		}
	}

	private Address saveAddressDataForPandit(Map<String, String> addressObject) {
		try {
			Address address = new Address();

			String state = addressObject.get("state");
			String city = addressObject.get("city");
			String dist = addressObject.get("dist");
			String addressDetails = addressObject.get("address");
			String addressContactNo = addressObject.get("addressContactNo");

			address.setState(state);
			address.setCity(city);
			address.setDist(dist);
			address.setAddressDetail(addressDetails);
			address.setContactNo(addressContactNo);

			address.setIsActive("0");

			address.setIsTempleAddress("1");

			return address;
		} catch (Exception e) {
			logger.error("Error in saveAddressDataForTemple:" + e);
			return null;
		}
	}

	public Response getUnverifiedPandit(String panditId) {
		Response response = new Response();

		Map<String, Object> detailsMap = new HashMap<>();
		try {
			CmsPanditDetails cmsPanditDetails = cmsPanditDetailsRepositry.findOne(panditId);

			String isNewUser = cmsPanditDetails.getIsNewUser();

			Boolean isNewUserData = false;

			if (isNewUser != null) {
				if (isNewUser.equals("1")) {
					isNewUserData = true;
				}
			}

			detailsMap.put("isNewUser", isNewUserData);

			Integer userId = cmsPanditDetails.getUserId();

			UserDetailsImpl userDetails = userDetailsRepositry.findByUserId(userId);
			Map<String, String> userInfoMap = new HashMap<>();

			if (userDetails != null) {
				userInfoMap.put("fName", userDetails.getFirstName() + " " + userDetails.getMiddleName());
				userInfoMap.put("lName", userDetails.getLastName());
				userInfoMap.put("gender", userDetails.getGender());
				userInfoMap.put("contactNo", userDetails.getPrimaryPhone());

				detailsMap.put("signUpDetails", userInfoMap);

			} else {
				detailsMap.put("signUpDetails", userInfoMap);
			}

			String isFreeLancer = cmsPanditDetails.getIsFreeLancer();
			Boolean isFreeLancerData = false;

			if (isFreeLancer != null) {
				if (isFreeLancer.equals("1")) {
					isFreeLancerData = true;
				}
			}
			detailsMap.put("isFreeLancer", isFreeLancerData);

			String isAssociatedWithTemple = cmsPanditDetails.getIsAssociatedWithTemple();

			Boolean isAssociatedWithTempleData = false;

			if (isAssociatedWithTemple != null) {
				if (isAssociatedWithTemple.equals("1")) {
					isAssociatedWithTempleData = true;
				}
			}

			detailsMap.put("isAssociatedWithTemple", isAssociatedWithTempleData);

			detailsMap.put("aboutPandit", cmsPanditDetails.getPanditDesc());

			String isAvailableOnALlDays = cmsPanditDetails.getIsAvailableOnALlDays();

			Boolean isAvailableOnALlDaysData = false;

			if (isAvailableOnALlDays != null) {
				if (isAvailableOnALlDays.equals("1")) {
					isAvailableOnALlDaysData = true;
				}
			}

			detailsMap.put("isAvailableOnALlDays", isAvailableOnALlDaysData);

			detailsMap.put("generalAvailablityTiming",
					(cmsPanditDetails.getGeneralAvailablityTiming() != null)
							? cmsPanditDetails.getGeneralAvailablityTiming()
							: "");

			String templeIdList = cmsPanditDetails.getTempleIdList();

			if (templeIdList != null) {
				detailsMap.put("templeIdList", Arrays.asList(templeIdList.split(",")));
			} else {
				detailsMap.put("templeIdList", "");
			}

			String imageId = (cmsPanditDetails.getImageId() != null) ? cmsPanditDetails.getImageId() : "40";

			String imagePath = "images/" + imageService.getImagePath(imageId);

			detailsMap.put("imageId", imagePath);

			List languages = getLanguageName(cmsPanditDetails.getLanguages());

			detailsMap.put("languages", languages);

			String articlesDetails = cmsPanditDetails.getArticlesDetails();

			List<Map<String, String>> listOfArticles = convertToListOfMap(articlesDetails);

			if (listOfArticles != null) {
				detailsMap.put("articleDetails", listOfArticles);
			} else {
				detailsMap.put("articleDetails", null);
			}

			String awardsDetails = cmsPanditDetails.getAwardsDetails();

			if (awardsDetails != null) {
				awardsDetails = updateAwardsObjectImageToShow(awardsDetails);

				List<Map<String, String>> convertToListOfMap = convertToListOfMap(awardsDetails);

				if (convertToListOfMap != null) {
					detailsMap.put("awardsDetails", convertToListOfMap);
				} else {
					detailsMap.put("awardsDetails", null);
				}
			} else {
				detailsMap.put("awardsDetails", null);
			}

			String specilaizationPooja = cmsPanditDetails.getSpecilaizationPooja();

			if (specilaizationPooja != null) {
				detailsMap.put("specilaizationPooja", Arrays.asList(specilaizationPooja.split(",")));
			} else {
				detailsMap.put("specilaizationPooja", null);
			}

			String qualification = cmsPanditDetails.getQualification();

			if (qualification != null) {

				List<Map<String, String>> qualificationObj = createMapObject(qualification);
				detailsMap.put("qualification", qualificationObj);
			} else {
				detailsMap.put("qualification", "");
			}

			String specilaization = (cmsPanditDetails.getSpecilaization() != null)
					? cmsPanditDetails.getSpecilaization()
					: "";

			List<Map<String, String>> specilaizationObj = createMapObject(specilaization);

			detailsMap.put("specilaization", specilaizationObj);

			detailsMap.put("typeOfAvailability", "PERSONAL");

			String panditDailyAvailablityTiming = cmsPanditDetails.getPanditDailyAvailablityTiming();

			if (panditDailyAvailablityTiming != null) {
				List<Map<String, String>> convertToListOfMap = convertToListOfMap(panditDailyAvailablityTiming);

				detailsMap.put("dailyTiming", convertToListOfMap);
			} else {
				detailsMap.put("dailyTiming", null);

			}

			response.setStatus(ResponseStatus.OK);
			response.setResponse(detailsMap);
			return response;
		} catch (Exception e) {
			logger.error("Error in getUnverifiedPandit for panditId:" + panditId);
			response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
			response.setResponse("Something went wrong while fetching record.Please try later");

			return response;
		}

	}

	private List<Map<String, String>> convertToListOfMap(String articlesDetails) {

		List<Map<String, String>> list = new ArrayList<>();
		try {
			JSONArray jsonArray = new JSONArray(articlesDetails);

			int length = jsonArray.length();

			for (int i = 0; i < length; i++) {
				Map<String, String> map = new HashMap<>(5);

				JSONObject jsonObject = jsonArray.getJSONObject(i);

				Iterator keys = jsonObject.keys();

				while (keys.hasNext()) {
					Object object = (Object) keys.next();

					map.put(object.toString(), jsonObject.getString(object.toString()));
				}

				list.add(map);
			}
			return list;
		} catch (Exception e) {
			logger.error("Error while converting articles details to map to send :" + e);
			return list;
		}

	}

	private List<String> getLanguageName(String languages) {
		if (languages != null) {
			try {
				JSONArray jsonArray = new JSONArray(languages);

				int length = jsonArray.length();

				List<String> list = new ArrayList<String>(length);

				if (length > 0) {
					for (int i = 0; i < length; i++) {
						Map<String, String> object = (Map<String, String>) jsonArray.get(i);

						list.add(object.get("name"));
					}
					return list;
				} else {
					return null;
				}
			} catch (Exception e) {
				return null;
			}
		} else {
			return null;
		}

	}

	/*
	 * private String createJsonObject(String qualification) {
	 * 
	 * String[] qualificationList = qualification.split(",");
	 * 
	 * try { JSONArray jsonArray = new JSONArray();
	 * 
	 * for (int i = 0; i < qualificationList.length; i++) {
	 * 
	 * JSONObject jsonObject = new JSONObject();
	 * 
	 * jsonObject.put("name", qualificationList[i]);
	 * 
	 * jsonArray.put(jsonObject);
	 * 
	 * }
	 * 
	 * return jsonArray.toString(); } catch (Exception e) {
	 * logger.error("Error in createJsonObject:" + e); return ""; }
	 * 
	 * }
	 */

	private List<Map<String, String>> createMapObject(String qualification) {

		String[] qualificationList = qualification.split(",");

		List<Map<String, String>> list = new ArrayList();

		try {
			Map<String, String> map = new HashMap<>(1);

			for (int i = 0; i < qualificationList.length; i++) {
				map.put("name", qualificationList[i]);
				list.add(map);
			}

			return list;

		} catch (Exception e) {
			logger.error("Error in createJsonObject:" + e);
			return list;
		}

	}

	private Address saveAddressDataForPandit(String addressObject) {
		try {
			if (addressObject == null) {
				return null;
			} else {
				JSONObject addressJsonObject = new JSONObject(addressObject);
				Address address = new Address();

				address.setState((String) addressJsonObject.get("state"));

				address.setCity((String) addressJsonObject.get("city"));

				address.setDist(((String) addressJsonObject.get("dist")));

				address.setAddressDetail((String) addressJsonObject.get("addressDetail"));

				address.setIsActive("0");

				address.setIsTempleAddress("1");

				address.setContactNo((String) addressJsonObject.get("addressContactNo"));

				return address;
			}

		} catch (JSONException e) {
			logger.error("Error in saveAddressDataForTemple:" + e);
			return null;
		}
	}

	public String getTemplesIdOfUser(String userId) {

		// String templeIdListByUserId =
		// panditDetailsRepositry.getTempleIdListByUserId(userId);

		return panditDetailsRepositry.getTempleIdListByUserId(userId);

	}
}
