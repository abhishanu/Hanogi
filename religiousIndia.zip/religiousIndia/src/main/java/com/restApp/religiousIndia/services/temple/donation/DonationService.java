package com.restApp.religiousIndia.services.temple.donation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.restApp.religiousIndia.data.entities.temple.donation.ClothesDonation;
import com.restApp.religiousIndia.data.entities.temple.donation.EducationDonation;
import com.restApp.religiousIndia.data.entities.temple.donation.FoodDonation;
import com.restApp.religiousIndia.data.entities.temple.donation.GirlChildMarriageDonation;
import com.restApp.religiousIndia.data.entities.temple.donation.MedicineDonation;
import com.restApp.religiousIndia.data.entities.temple.donation.TempleDonationCategory;
import com.restApp.religiousIndia.data.entities.temple.donation.TempleNeedsDonation;
import com.restApp.religiousIndia.data.repositry.temple.donation.ClothDonationRepositry;
import com.restApp.religiousIndia.data.repositry.temple.donation.DonationCategoryRepositry;
import com.restApp.religiousIndia.data.repositry.temple.donation.EducationDonationRepositry;
import com.restApp.religiousIndia.data.repositry.temple.donation.FoodDonationRepositry;
import com.restApp.religiousIndia.data.repositry.temple.donation.GirlChildMarriageDonationRepositry;
import com.restApp.religiousIndia.data.repositry.temple.donation.MedicineDonationRepositry;
import com.restApp.religiousIndia.data.repositry.temple.donation.TempleNeedsDonationRepositry;
import com.restApp.religiousIndia.request.filter.PostRequest;
import com.restApp.religiousIndia.request.filter.PostRequestWithObject;
import com.restApp.religiousIndia.response.Response;
import com.restApp.religiousIndia.response.status.ResponseStatus;
import com.restApp.religiousIndia.security.UserPrincipal;
import com.restApp.religiousIndia.services.cart.CartServices;
import com.restApp.religiousIndia.services.imageServices.RetriveImageService;

@Service
public class DonationService {

	private static Logger logger = Logger.getLogger(DonationService.class);

	@Autowired
	ClothDonationRepositry clothDonationRepositry;

	@Autowired
	TempleNeedsDonationRepositry templeNeedsDonationRepositry;

	@Autowired
	GirlChildMarriageDonationRepositry girlChildMarriageDonationRepositry;

	@Autowired
	EducationDonationRepositry educationDonationRepositry;

	@Autowired
	FoodDonationRepositry foodDonationRepositry;

	@Autowired
	MedicineDonationRepositry medicineDonationRepositry;

	@Autowired
	DonationCategoryRepositry donationCategoryRepositry;

	@Autowired
	RetriveImageService retriveImageService;

	@Autowired
	CartServices cartServices;

	@Value("${defaultDonationImageId}")
	private String defaultDonationImageId;

	public Iterable<ClothesDonation> getAllClothDonation() {
		Iterable<ClothesDonation> findAll = clothDonationRepositry.findAll();
		return findAll;
	}

	public Iterable<TempleDonationCategory> getAllDonationCategory() {
		return donationCategoryRepositry.findByisActive("1");
	}

	public Map<String, Object> getAllDonationDetails(String templeId) {
		Iterable<TempleDonationCategory> allDonationCategory = getAllDonationCategory();
		Map<String, Object> donationSubCategoryDetails = new HashMap<>();
		for (TempleDonationCategory templeDonationCategory : allDonationCategory) {

			if (templeDonationCategory.getDonationCategoryId().equals("1")) {
				ArrayList<TempleNeedsDonation> templeNeedsDonationList = templeNeedsDonationRepositry
						.findByTempleId(templeId);
				for (TempleNeedsDonation templeNeedsDonation : templeNeedsDonationList) {
					templeNeedsDonation.setImageId(retriveImageService.getImagePath(templeNeedsDonation.getImageId()));
				}

				donationSubCategoryDetails.put(templeDonationCategory.getDonationCategoryName(),
						templeNeedsDonationList);
			}

			if (templeDonationCategory.getDonationCategoryId().equals("2")) {
				ArrayList<MedicineDonation> medicineDonationList = medicineDonationRepositry.findByTempleId(templeId);
				for (MedicineDonation medicineDonation : medicineDonationList) {
					medicineDonation.setImageId(retriveImageService.getImagePath(medicineDonation.getImageId()));
				}
				donationSubCategoryDetails.put(templeDonationCategory.getDonationCategoryName(), medicineDonationList);
			}

			if (templeDonationCategory.getDonationCategoryId().equals("3")) {
				ArrayList<FoodDonation> foodDonationList = foodDonationRepositry.findByTempleId(templeId);
				for (FoodDonation foodDonation : foodDonationList) {
					foodDonation.setImageId(retriveImageService.getImagePath(foodDonation.getImageId()));
				}
				donationSubCategoryDetails.put(templeDonationCategory.getDonationCategoryName(), foodDonationList);
			}

			if (templeDonationCategory.getDonationCategoryId().equals("4")) {
				ArrayList<EducationDonation> educationDonationList = educationDonationRepositry
						.findByTempleId(templeId);
				for (EducationDonation educationDonation : educationDonationList) {
					educationDonation.setImageId(retriveImageService.getImagePath(educationDonation.getImageId()));
				}
				donationSubCategoryDetails.put(templeDonationCategory.getDonationCategoryName(), educationDonationList);
			}

			if (templeDonationCategory.getDonationCategoryId().equals("5")) {
				ArrayList<ClothesDonation> clothesDonationList = clothDonationRepositry.findByTempleId(templeId);
				for (ClothesDonation clothesDonation : clothesDonationList) {
					clothesDonation.setImageId(retriveImageService.getImagePath(clothesDonation.getImageId()));
				}
				donationSubCategoryDetails.put(templeDonationCategory.getDonationCategoryName(), clothesDonationList);
			}

			if (templeDonationCategory.getDonationCategoryId().equals("6")) {
				ArrayList<GirlChildMarriageDonation> girlChildMarriageDonationList = girlChildMarriageDonationRepositry
						.findByTempleId(templeId);
				for (GirlChildMarriageDonation girlChildMarriageDonation : girlChildMarriageDonationList) {
					girlChildMarriageDonation
							.setImageId(retriveImageService.getImagePath(girlChildMarriageDonation.getImageId()));
				}
				donationSubCategoryDetails.put(templeDonationCategory.getDonationCategoryName(),
						girlChildMarriageDonationList);
			}
		}
		return donationSubCategoryDetails;
	}

	public Response addTempleDonationToCart(PostRequest donateRequest, UserPrincipal currentUser) {
		Response response = null;
		if (donateRequest.getRequestType().equals("addToCart")) {
			Map<String, List<String>> requestParam = donateRequest.getRequestParam();

			Double ammount = new Double(requestParam.get("ammount").get(0));
			String donationSubCategoryId = requestParam.get("donationSubCategoryId").get(0);
			String templeDonationCategoryId = requestParam.get("templeDonationCategoryId").get(0);
			Integer userId = currentUser.getId();

			response = cartServices.addItemInUserCart(userId, ammount, donationSubCategoryId, templeDonationCategoryId);
		}
		return response;
	}

	public Map<String, Object> donateMoney(String templeDonationCategoryId, String donationSubCategoryId,
			Double ammount) {
		Map<String, Object> map = new HashMap<>();
		if (templeDonationCategoryId.equals("1")) {
			synchronized (this) {
				TempleNeedsDonation donation = templeNeedsDonationRepositry.findOne(new Integer(donationSubCategoryId));
				if (donation != null) {
					try {
						Date endDate = donation.getEndDate();
						// Check validity of this donation
						if (endDate.after(new Date())) {
							map.put("Error", "Sorry donation for this category is closed");
						} else {
							// Check Collection is completed or not
							double requiredMoney = donation.getRequiredMoney();
							double collectedMoney = donation.getCollectedMoney();
							if (requiredMoney - collectedMoney >= ammount) {
								synchronized (templeNeedsDonationRepositry) {
									donation.setCollectedMoney(collectedMoney + ammount);
									donation.setNoOfContribuitors(donation.getNoOfContribuitors() + 1);
									map.put("Success", "Your request for donation has been placed");
								}
							} else {
								map.put("Error", "Sorry,The required ammount is completed or less than your ammount");
							}
						}
						templeNeedsDonationRepositry.save(donation);

					} catch (Exception e) {
						logger.info("Exception occured:" + e);
						map.put("Error", "Something went wrong");
					}
				}

			}
		}

		if (templeDonationCategoryId.equals("2")) {
			synchronized (this) {
				MedicineDonation donation = medicineDonationRepositry.findOne(new Integer(donationSubCategoryId));
				Date endDate = donation.getEndDate();
				// Check validity of this donation
				if (endDate.after(new Date())) {
					map.put("Error", "Sorry donation for this category is closed");
				} else {
					// Check Collection is completed or not
					double requiredMoney = donation.getRequiredMoney();
					double collectedMoney = donation.getCollectedMoney();
					if (requiredMoney - collectedMoney >= ammount) {
						synchronized (medicineDonationRepositry) {
							donation.setCollectedMoney(collectedMoney + ammount);
							donation.setNoOfContribuitors(donation.getNoOfContribuitors() + 1);
							map.put("Success", "Your request for donation has been placed");
						}
					} else {
						map.put("Error", "Sorry,The required ammount is completed or less than your ammount");
					}
				}
				medicineDonationRepositry.save(donation);

			}
		}

		if (templeDonationCategoryId.equals("3")) {
			synchronized (this) {
				FoodDonation donation = foodDonationRepositry.findOne(new Integer(donationSubCategoryId));
				Date endDate = donation.getEndDate();
				// Check validity of this donation
				if (endDate.after(new Date())) {
					map.put("Error", "Sorry donation for this category is closed");
				} else {
					// Check Collection is completed or not
					double requiredMoney = donation.getRequiredMoney();
					double collectedMoney = donation.getCollectedMoney();
					if (requiredMoney - collectedMoney >= ammount) {
						synchronized (foodDonationRepositry) {
							donation.setCollectedMoney(collectedMoney + ammount);
							donation.setNoOfContribuitors(donation.getNoOfContribuitors() + 1);
							map.put("Success", "Your request for donation has been placed");
						}
					} else {
						map.put("Error", "Sorry,The required ammount is completed or less than your ammount");
					}
				}
				foodDonationRepositry.save(donation);

			}
		}

		if (templeDonationCategoryId.equals("4")) {
			synchronized (this) {
				EducationDonation donation = educationDonationRepositry.findOne(new Integer(donationSubCategoryId));
				Date endDate = donation.getEndDate();
				if (endDate == null) {
					map.put("Error", "Sorry ");
				}
				// Check validity of this donation
				if (endDate.after(new Date())) {
					map.put("Error", "Sorry donation for this category is closed");
				} else {
					// Check Collection is completed or not
					double requiredMoney = donation.getRequiredMoney();
					double collectedMoney = donation.getCollectedMoney();
					if (requiredMoney - collectedMoney >= ammount) {
						synchronized (educationDonationRepositry) {
							donation.setCollectedMoney(collectedMoney + ammount);
							donation.setNoOfContribuitors(donation.getNoOfContribuitors() + 1);
							map.put("Success", "Your request for donation has been placed");
						}
					} else {
						map.put("Error", "Sorry,The required ammount is completed or less than your ammount");
					}
				}
				educationDonationRepositry.save(donation);

			}
		}

		if (templeDonationCategoryId.equals("5")) {
			synchronized (this) {
				ClothesDonation donation = clothDonationRepositry.findOne(new Integer(donationSubCategoryId));
				Date endDate = donation.getEndDate();
				// Check validity of this donation
				if (endDate.after(new Date())) {
					map.put("Error", "Sorry donation for this category is closed");
				} else {
					// Check Collection is completed or not
					double requiredMoney = donation.getRequiredMoney();
					double collectedMoney = donation.getCollectedMoney();
					if (requiredMoney - collectedMoney >= ammount) {
						synchronized (clothDonationRepositry) {
							donation.setCollectedMoney(collectedMoney + ammount);
							donation.setNoOfContribuitors(donation.getNoOfContribuitors() + 1);
							map.put("Success", "Your request for donation has been placed");
						}
					} else {
						map.put("Error", "Sorry,The required ammount is completed or less than your ammount");
					}
				}
				clothDonationRepositry.save(donation);

			}
		}

		if (templeDonationCategoryId.equals("6")) {
			synchronized (this) {
				GirlChildMarriageDonation donation = girlChildMarriageDonationRepositry
						.findOne(new Integer(donationSubCategoryId));
				Date endDate = donation.getEndDate();
				// Check validity of this donation
				if (endDate.after(new Date())) {
					map.put("Error", "Sorry donation for this category is closed");
				} else {
					// Check Collection is completed or not
					double requiredMoney = donation.getRequiredMoney();
					double collectedMoney = donation.getCollectedMoney();
					if (requiredMoney - collectedMoney >= ammount) {
						synchronized (girlChildMarriageDonationRepositry) {
							donation.setCollectedMoney(collectedMoney + ammount);
							donation.setNoOfContribuitors(donation.getNoOfContribuitors() + 1);
							map.put("Success", "Your request for donation has been placed");
						}
					} else {
						map.put("Error", "Sorry,The required ammount is completed or less than your ammount");
					}
				}
				girlChildMarriageDonationRepositry.save(donation);
			}
		}
		return map;
	}

	public Map<String, String> getTempleIdByDonationSubCategory(String donationCat, String donationSubCat) {
		String templeID = "";
		String donationSubCateName = "";
		Map<String, String> donationDetails = new HashMap<>();
		if (donationCat.equals("1")) {
			templeID = templeNeedsDonationRepositry.findOne(new Integer(donationSubCat)).getTempleId();
			donationSubCateName = "Temple Needs";
		} else if (donationCat.equals("2")) {
			templeID = medicineDonationRepositry.findOne(new Integer(donationSubCat)).getTempleId();
			donationSubCateName = "Medicine Donation";
		} else if (donationCat.equals("3")) {
			templeID = foodDonationRepositry.findOne(new Integer(donationSubCat)).getTempleId();
			donationSubCateName = "Food Donation";
		} else if (donationCat.equals("4")) {
			templeID = educationDonationRepositry.findOne(new Integer(donationSubCat)).getTempleId();
			donationSubCateName = "Education";
		} else if (donationCat.equals("5")) {
			templeID = clothDonationRepositry.findOne(new Integer(donationSubCat)).getTempleId();
			donationSubCateName = "Clothes Donation";
		} else if (donationCat.equals("6")) {
			templeID = girlChildMarriageDonationRepositry.findOne(new Integer(donationSubCat)).getTempleId();
			donationSubCateName = "Girl Child Marriage";
		}
		donationDetails.put("Temple_Id", templeID);
		donationDetails.put("Donation_Sub_Cat_Name", donationSubCateName);
		return donationDetails;
	}

	public Response saveNewDonationData(PostRequestWithObject request) {
		logger.info("saveNewDonationData method ");

		Response response = new Response();

		try {
			if (request != null) {
				String requestType = request.getRequestType();
				if (requestType != null) {
					if (requestType.equals("saveNewDonationData")) {
						if (request.getRequestParam() != null) {
							Map<String, Object> requestParam = request.getRequestParam();
							if (!requestParam.isEmpty()) {
								List<String> templeIdList = (List<String>) requestParam.get("templeIdList");

								if (templeIdList != null) {
									if (!templeIdList.isEmpty()) {
										List donationDetailsList = (List) requestParam.get("donationDetailsList");

										response = saveDonationDetailsOfList(donationDetailsList, templeIdList);
									} else {
										response.setStatus(ResponseStatus.BAD_REQUEST);
										response.setResponse(
												"Please provide atleast one temple Id for which you want to attach this donation details.");
										return response;
									}
								} else {
									response.setStatus(ResponseStatus.BAD_REQUEST);
									response.setResponse(
											"Please provide the temple(s) Id for which you want to attach this donation details.");
									return response;
								}
							} else {
								response.setStatus(ResponseStatus.BAD_REQUEST);
								response.setResponse("request parameter is blank.");
								return response;
							}
						} else {
							response.setStatus(ResponseStatus.BAD_REQUEST);
							response.setResponse("request parameter is missing.");
							return response;
						}
					} else {
						response.setStatus(ResponseStatus.BAD_REQUEST);
						response.setResponse("request type is not matched");
						return response;
					}
				} else {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("request type is missing");
					return response;
				}
			} else {
				response.setStatus(ResponseStatus.BAD_REQUEST);
				response.setResponse("request is Blank");
				return response;
			}

			return response;
		} catch (Exception e) {
			logger.error("saveNewDonationData method Error:" + e.getMessage());
			response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
			response.setResponse(e.getMessage());
			return response;
		}

	}

	private Response saveDonationDetailsOfList(List<Map<String, Object>> donationDetailsList,
			List<String> templeIdList) {
		Response response = new Response();

		if (donationDetailsList != null) {
			if (!donationDetailsList.isEmpty()) {
				try {
					for (Map<String, Object> donationDetails : donationDetailsList) {
						String categoryId = (String) donationDetails.get("categoryId");

						if (categoryId != null) {
							response = saveDonationForCategory(donationDetails, templeIdList);
							return response;
						} else {
							response.setStatus(ResponseStatus.BAD_REQUEST);
							response.setResponse("categoryId is missing.");
							return response;
						}

					}
				} catch (Exception e) {
					logger.error("Error in saveDonationDetailsOfList:" + e.getMessage());
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("donationDetails are not complete");
					return response;
				}
			} else {
				response.setStatus(ResponseStatus.BAD_REQUEST);
				response.setResponse("Please provide atlease one donation detail to add");
				return response;
			}
		} else {
			response.setStatus(ResponseStatus.BAD_REQUEST);
			response.setResponse("No Donation details found.");
			return response;
		}
		return null;
	}

	private Response saveDonationForCategory(Map<String, Object> donationDetails, List<String> templeIdList) {
		Response response = new Response();
		String categoryId = (String) donationDetails.get("categoryId");
		try {
			Date endDate = null;

			Date startDate = null;

			String description = "";

			String donationTitle = "";

			String imageId = (defaultDonationImageId != null) ? defaultDonationImageId : "";

			Double requiredMoney = 0.0;

			List donationsList = new ArrayList<>(templeIdList.size());
			try {
				String endDateValue = (String) donationDetails.get("endDate");
				endDate = new SimpleDateFormat("dd-MM-yyyy").parse(endDateValue);

				String startDateValue = (String) donationDetails.get("startDate");
				startDate = new SimpleDateFormat("dd-MM-yyyy").parse(startDateValue);

				description = (String) donationDetails.get("description");

				if (description.isEmpty()) {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("donation description is missing.");
					return response;
				}

				donationTitle = (String) donationDetails.get("donationTitle");
				if (donationTitle.isEmpty()) {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("donation title is missing.");
					return response;
				}

				imageId = (String) donationDetails.get("imageId");

				if (imageId.equalsIgnoreCase(defaultDonationImageId)) {
					logger.warn("Image is missing correspond to this donation.categoryId:" + categoryId);
				}

				Integer money = (Integer) donationDetails.get("requiredMoney");

				requiredMoney = new Double(money + "");

				if (requiredMoney == 0.0) {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("required Money is not as expected.");
					return response;
				}

			} catch (Exception e) {
				logger.error("Date format convertion went wrong");
				response.setStatus(ResponseStatus.ERROR);
				response.setResponse("Date format is not as expected");
				return response;
			}

			switch (categoryId) {
			case "1":
				for (String templeId : templeIdList) {
					TempleNeedsDonation needsDonation = new TempleNeedsDonation();

					needsDonation.setStartDate(startDate);
					needsDonation.setEndDate(endDate);
					needsDonation.setDescription(description);
					needsDonation.setDonationSubCategoryName(donationTitle);
					needsDonation.setIsActive("1");
					needsDonation.setImageId(imageId);
					needsDonation.setNoOfContribuitors(0);
					needsDonation.setRequiredMoney(requiredMoney);
					needsDonation.setTempleDonationCategoryId("1");
					needsDonation.setTempleId(templeId);

					donationsList.add(needsDonation);
				}

				templeNeedsDonationRepositry.save(donationsList);

				response.setStatus(ResponseStatus.OK);
				response.setResponse("");

				break;
			case "2":

				for (String templeId : templeIdList) {
					MedicineDonation medicineDonation = new MedicineDonation();

					medicineDonation.setEndDate(endDate);
					medicineDonation.setStartDate(startDate);
					medicineDonation.setDescription(description);
					medicineDonation.setDonationSubCategoryName(donationTitle);
					medicineDonation.setIsActive("1");
					medicineDonation.setImageId(imageId);
					medicineDonation.setNoOfContribuitors(0);
					medicineDonation.setRequiredMoney(requiredMoney);
					medicineDonation.setTempleDonationCategoryId("2");
					medicineDonation.setTempleId(templeId);

					donationsList.add(medicineDonation);
				}

				medicineDonationRepositry.save(donationsList);

				response.setStatus(ResponseStatus.OK);
				response.setResponse("");
				break;
			case "3":
				for (String templeId : templeIdList) {
					FoodDonation foodDonation = new FoodDonation();

					foodDonation.setEndDate(endDate);
					foodDonation.setStartDate(startDate);
					foodDonation.setDescription(description);
					foodDonation.setDonationSubCategoryName(donationTitle);
					foodDonation.setIsActive("1");
					foodDonation.setImageId(imageId);
					foodDonation.setNoOfContribuitors(0);
					foodDonation.setRequiredMoney(requiredMoney);
					foodDonation.setTempleDonationCategoryId("3");
					foodDonation.setTempleId(templeId);

					donationsList.add(foodDonation);
				}

				foodDonationRepositry.save(donationsList);

				response.setStatus(ResponseStatus.OK);
				response.setResponse("");
				break;
			case "4":
				for (String templeId : templeIdList) {
					EducationDonation educationDonation = new EducationDonation();

					educationDonation.setEndDate(endDate);
					educationDonation.setStartDate(startDate);
					educationDonation.setDescription(description);
					educationDonation.setDonationSubCategoryName(donationTitle);
					educationDonation.setIsActive("1");
					educationDonation.setImageId(imageId);
					educationDonation.setNoOfContribuitors(0);
					educationDonation.setRequiredMoney(requiredMoney);
					educationDonation.setTempleDonationCategoryId("4");
					educationDonation.setTempleId(templeId);

					donationsList.add(educationDonation);
				}

				educationDonationRepositry.save(donationsList);

				response.setStatus(ResponseStatus.OK);
				response.setResponse("");
				break;
			case "5":
				for (String templeId : templeIdList) {
					ClothesDonation clothesDonation = new ClothesDonation();

					clothesDonation.setEndDate(endDate);
					clothesDonation.setStartDate(startDate);
					clothesDonation.setDescription(description);
					clothesDonation.setDonationSubCategoryName(donationTitle);
					clothesDonation.setIsActive("1");
					clothesDonation.setImageId(imageId);
					clothesDonation.setNoOfContribuitors(0);
					clothesDonation.setRequiredMoney(requiredMoney);
					clothesDonation.setTempleDonationCategoryId("5");
					clothesDonation.setTempleId(templeId);

					donationsList.add(clothesDonation);
				}

				clothDonationRepositry.save(donationsList);

				response.setStatus(ResponseStatus.OK);
				response.setResponse("");
				break;
			case "6":
				for (String templeId : templeIdList) {
					GirlChildMarriageDonation childMarriageDonation = new GirlChildMarriageDonation();

					childMarriageDonation.setEndDate(endDate);
					childMarriageDonation.setStartDate(startDate);
					childMarriageDonation.setDescription(description);
					childMarriageDonation.setDonationSubCategoryName(donationTitle);
					childMarriageDonation.setIsActive("1");
					childMarriageDonation.setImageId(imageId);
					childMarriageDonation.setNoOfContribuitors(0);
					childMarriageDonation.setRequiredMoney(requiredMoney);
					childMarriageDonation.setTempleDonationCategoryId("6");
					childMarriageDonation.setTempleId(templeId);

					donationsList.add(childMarriageDonation);
				}

				girlChildMarriageDonationRepositry.save(donationsList);

				response.setStatus(ResponseStatus.OK);
				response.setResponse("");
				break;

			default:
				logger.error("No such donation category found.");
				response.setStatus(ResponseStatus.BAD_REQUEST);
				response.setResponse("No such donation category found");
				break;
			}
		} catch (Exception e) {
			response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
			response.setResponse("Error while saving donation.");

		} finally {
			return response;
		}
	}

	public Response searchDonation(PostRequestWithObject request) {
		Response response = new Response();
		try {
			if (request != null) {
				String requestType = request.getRequestType();

				if (requestType != null) {
					if (requestType.equalsIgnoreCase("searchDonation")) {
						Map<String, Object> requestParam = request.getRequestParam();

						if (requestParam != null) {
							List<Map<String, String>> searchResultList = new ArrayList<Map<String, String>>();

							List<String> categoryIdList = (List<String>) requestParam.get("categoryId");
							List<String> dateRange = (List<String>) requestParam.get("dateRange");
							List<String> templeIdList = (List<String>) requestParam.get("templeIdList");
							String donationName = (String) requestParam.get("donationName");
							Boolean isExpired = ((Boolean) requestParam.get("isExpired") != null)
									? (Boolean) requestParam.get("isExpired")
									: true;

							if (categoryIdList != null) {
								if (!categoryIdList.isEmpty()) {
									for (String categoryId : categoryIdList) {
										List<Map<String, String>> searchResultForCategory = getSearchDonationByCategoryId(
												categoryId, dateRange, templeIdList, donationName, isExpired);

										if (searchResultForCategory != null) {
											searchResultList.addAll(searchResultForCategory);
										} else {
											logger.warn("No search Result for donation of categoryId:" + categoryId);
										}
									}

									response.setStatus(ResponseStatus.OK);
									response.setResponse(searchResultList);
									return response;
								} else {
									response.setStatus(ResponseStatus.BAD_REQUEST);
									response.setResponse("categoryIdList cann't be blank.");
									return response;
								}
							} else {
								response.setStatus(ResponseStatus.BAD_REQUEST);
								response.setResponse("categoryIdList required.");
								return response;
							}

						} else {
							response.setStatus(ResponseStatus.BAD_REQUEST);
							response.setResponse("requestParam not found");
							return response;
						}
					} else {
						response.setStatus(ResponseStatus.BAD_REQUEST);
						response.setResponse("requestType not found");
						return response;
					}
				} else {
					response.setStatus(ResponseStatus.BAD_REQUEST);
					response.setResponse("requestType cann't be blank.");
					return response;
				}
			} else {
				response.setStatus(ResponseStatus.BAD_REQUEST);
				response.setResponse("Request cann't be blank.");
				return response;
			}
		} catch (Exception e) {
			response.setStatus(ResponseStatus.INTERNAL_SERVER_ERROR);
			response.setResponse("Something went wrong.Please try later.");
			return response;
		}

	}

	private List<Map<String, String>> getSearchDonationByCategoryId(String categoryId, List<String> dateRange,
			List<String> templeIdList, String donationName, Boolean isExpired) {

		List<Map<String, String>> searchResultList = new ArrayList<>();

		Date startDate = null;
		Date endDate = null;
		String templeId = "";
		if (dateRange != null) {
			if (dateRange.size() == 2) {
				try {
					startDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").parse(dateRange.get(0));
					endDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").parse(dateRange.get(1));
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		}

		if (templeIdList != null) {
			templeId = String.join(",", templeIdList);
		}

		if (donationName == null) {
			donationName = "";
		}

		if (isExpired) {

		} else {

		}

		switch (categoryId) {
		case "1":
			List<TempleNeedsDonation> searchDonationResultFromNeeds = templeNeedsDonationRepositry
					.findByDonationSubCategoryNameLikeOrEndDateOrTempleId(donationName, endDate, templeId);
			if (searchDonationResultFromNeeds != null) {
				for (TempleNeedsDonation donation : searchDonationResultFromNeeds) {
					Map<String, String> resultMap = new HashMap<>();

					resultMap.put("donationSubCategoryId", donation.getDonationSubCategoryId() + "");
					resultMap.put("subCategoryName", donation.getDonationSubCategoryName());
					resultMap.put("startDate", donation.getStartDate().toString());
					resultMap.put("endDate", donation.getEndDate().toString());
					resultMap.put("requiredMoney", donation.getRequiredMoney() + "");
					resultMap.put("description", donation.getDescription());

					resultMap.put("imageId", "images/" + retriveImageService.getImagePath(donation.getImageId()));
					searchResultList.add(resultMap);
				}
			}
			break;
		case "2":
			List<MedicineDonation> searchDonationResultFromMedicine = medicineDonationRepositry
					.findByDonationSubCategoryNameLikeOrEndDateOrTempleId(donationName, endDate, templeId);
			if (searchDonationResultFromMedicine != null) {
				for (MedicineDonation donation : searchDonationResultFromMedicine) {
					Map<String, String> resultMap = new HashMap<>();

					resultMap.put("donationSubCategoryId", donation.getDonationSubCategoryId() + "");
					resultMap.put("subCategoryName", donation.getDonationSubCategoryName());
					resultMap.put("startDate", donation.getStartDate().toString());
					resultMap.put("endDate", donation.getEndDate().toString());
					resultMap.put("requiredMoney", donation.getRequiredMoney() + "");
					resultMap.put("description", donation.getDescription());

					resultMap.put("imageId", "images/" + retriveImageService.getImagePath(donation.getImageId()));
					searchResultList.add(resultMap);
				}
			}
			break;
		case "3":
			List<FoodDonation> searchDonationResultFromFood = foodDonationRepositry
					.findByDonationSubCategoryNameLikeOrEndDateOrTempleId(donationName, endDate, templeId);
			if (searchDonationResultFromFood != null) {
				for (FoodDonation donation : searchDonationResultFromFood) {
					Map<String, String> resultMap = new HashMap<>();

					resultMap.put("donationSubCategoryId", donation.getDonationSubCategoryId() + "");
					resultMap.put("subCategoryName", donation.getDonationSubCategoryName());
					resultMap.put("startDate", donation.getStartDate().toString());
					resultMap.put("endDate", donation.getEndDate().toString());
					resultMap.put("requiredMoney", donation.getRequiredMoney() + "");
					resultMap.put("description", donation.getDescription());

					resultMap.put("imageId", "images/" + retriveImageService.getImagePath(donation.getImageId()));
					searchResultList.add(resultMap);
				}
			}
			break;
		case "4":
			List<EducationDonation> searchDonationResultFromEducation = educationDonationRepositry
					.findByDonationSubCategoryNameLikeOrEndDateOrTempleId(donationName, endDate, templeId);
			if (searchDonationResultFromEducation != null) {
				for (EducationDonation donation : searchDonationResultFromEducation) {
					Map<String, String> resultMap = new HashMap<>();

					resultMap.put("donationSubCategoryId", donation.getDonationSubCategoryId() + "");
					resultMap.put("subCategoryName", donation.getDonationSubCategoryName());
					resultMap.put("startDate", donation.getStartDate().toString());
					resultMap.put("endDate", donation.getEndDate().toString());
					resultMap.put("requiredMoney", donation.getRequiredMoney() + "");
					resultMap.put("description", donation.getDescription());

					resultMap.put("imageId", "images/" + retriveImageService.getImagePath(donation.getImageId()));
					searchResultList.add(resultMap);
				}
			}
			break;
		case "5":
			List<ClothesDonation> searchDonationResultFromClothes = clothDonationRepositry
					.findByDonationSubCategoryNameLikeOrEndDateOrTempleId(donationName, endDate, templeId);
			if (searchDonationResultFromClothes != null) {
				for (ClothesDonation donation : searchDonationResultFromClothes) {
					Map<String, String> resultMap = new HashMap<>();

					resultMap.put("donationSubCategoryId", donation.getDonationSubCategoryId() + "");
					resultMap.put("subCategoryName", donation.getDonationSubCategoryName());
					resultMap.put("startDate", donation.getStartDate().toString());
					resultMap.put("endDate", donation.getEndDate().toString());
					resultMap.put("requiredMoney", donation.getRequiredMoney() + "");
					resultMap.put("description", donation.getDescription());

					resultMap.put("imageId", "images/" + retriveImageService.getImagePath(donation.getImageId()));
					searchResultList.add(resultMap);
				}
			}
			break;
		case "6":
			List<GirlChildMarriageDonation> searchDonationResultFromMarriage = girlChildMarriageDonationRepositry
					.findByDonationSubCategoryNameLikeOrEndDateOrTempleId(donationName, endDate, templeId);
			if (searchDonationResultFromMarriage != null) {
				for (GirlChildMarriageDonation donation : searchDonationResultFromMarriage) {
					Map<String, String> resultMap = new HashMap<>();

					resultMap.put("donationSubCategoryId", donation.getDonationSubCategoryId() + "");
					resultMap.put("subCategoryName", donation.getDonationSubCategoryName());
					resultMap.put("startDate", donation.getStartDate().toString());
					resultMap.put("endDate", donation.getEndDate().toString());
					resultMap.put("requiredMoney", donation.getRequiredMoney() + "");
					resultMap.put("description", donation.getDescription());

					resultMap.put("imageId", "images/" + retriveImageService.getImagePath(donation.getImageId()));
					searchResultList.add(resultMap);
				}
			}
			break;

		default:
			logger.warn("UnMatched category id");
			break;
		}
		return searchResultList;
	}

	public void updateDonationStatus() {
		logger.info("updating donation status for cloth");
		clothDonationRepositry.updateDonationState();

		logger.info("updating donation status for templeNeeds");
		templeNeedsDonationRepositry.updateDonationState();

		logger.info("updating donation status for ChildMarriage");
		girlChildMarriageDonationRepositry.updateDonationState();

		logger.info("updating donation status for education");
		educationDonationRepositry.updateDonationState();

		logger.info("updating donation status for food");
		foodDonationRepositry.updateDonationState();

		logger.info("updating donation status for medicine");
		medicineDonationRepositry.updateDonationState();

	}
}
