package com.restApp.religiousIndia.utilities;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class CmsPanditIdGenrator implements IdentifierGenerator {
	private static Logger logger = Logger.getLogger(CmsPanditIdGenrator.class);

	@Override
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		Connection connection = session.connection();

		String prefix = "Pandit";

		try {

			Statement statement = connection.createStatement();

			String generatedId = null;

			ResultSet rs = statement.executeQuery(
					"select count(Pandit_Id) as Id,Max(Pandit_Id) as lastId from religious_india.ri_pandit_details_temp");

			if (rs.next()) {

				int id = rs.getInt("Id") + 101;

				String lastId = rs.getString("lastId");

				if (lastId == null) {
					generatedId = prefix + new Integer(id).toString();
					
					return generatedId;
				} else {
					String lastIdCount = lastId.substring(6);

					generatedId = prefix + (new Integer(lastIdCount) + 1);

					return generatedId;
				}
			}
		} catch (Exception e) {
			logger.error("Error in pandit Id generation");
		}

		return null;
	}
}
