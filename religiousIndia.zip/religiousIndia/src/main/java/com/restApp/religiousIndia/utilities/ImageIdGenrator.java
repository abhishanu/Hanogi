package com.restApp.religiousIndia.utilities;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class ImageIdGenrator implements IdentifierGenerator {

	private static Logger logger = Logger.getLogger(ImageIdGenrator.class);

	@Override
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		Connection connection = session.connection();
		String prefix = "Rel";
		String generatedId = null;
		try {
			Statement statement = connection.createStatement();

			ResultSet rs = statement
					.executeQuery("select count(Image_Id) as Id,Max(Image_Id) as lastId from religious_india.ri_image");

			if (rs.next()) {
				int id = rs.getInt("Id") + 101;

				String lastId = rs.getString("lastId");

				if (lastId == null) {
					generatedId = prefix + new Integer(id).toString();

					return generatedId;
				} else {
					String lastIdCount = lastId.substring(3);

					generatedId = prefix + (new Integer(lastIdCount) + 1);

					return generatedId;
				}
			}
		} catch (SQLException e) {
			logger.error("Error in Image Id genration:");
		}

		return null;
	}

}
