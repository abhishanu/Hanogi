package com.restApp.religiousIndia.utilities;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class PoojaPackageIdGenrator implements IdentifierGenerator {
	private static Logger logger = Logger.getLogger(PoojaPackageIdGenrator.class);

	@Override
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		Connection connection = session.connection();

		String prefix = "PoojaPackage";

		String generatedId = null;

		try {

			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery(
					"select count(POOJA_PACKAGE_CATEGORY_ID) as IdMax(POOJA_PACKAGE_CATEGORY_ID) as lastId from religious_india.ri_pooja_package_types");

			if (rs.next()) {
				int id = rs.getInt("Id") + 101;

				String lastId = rs.getString("lastId");

				if (lastId == null) {
					generatedId = prefix + new Integer(id).toString();

					return generatedId;
				} else {
					String lastIdCount = lastId.substring(12);

					generatedId = prefix + (new Integer(lastIdCount) + 1);

					return generatedId;
				}
			}
		} catch (Exception e) {
			logger.error("Error in POOJA_PACKAGE_CATEGORY_ID generation");
		}

		return null;
	}
}
