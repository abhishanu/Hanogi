package com.restApp.religiousIndia.utilities;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

public class TempleIdGenrator implements IdentifierGenerator {
	private static Logger logger = Logger.getLogger(TempleIdGenrator.class);

	@Override
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		Connection connection = session.connection();

		String prefix = "Temple";

		String generatedId = null;

		try {

			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery(
					"select count(Temple_Id) as Id,Max(Temple_Id) as lastId from religious_india.ri_temple");

			if (rs.next()) {
				int id = rs.getInt("Id") + 101;

				String lastId = rs.getString("lastId");

				if (lastId == null) {
					generatedId = prefix + new Integer(id).toString();

					return generatedId;
				} else {
					String lastIdCount = lastId.substring(6);

					generatedId = prefix + (new Integer(lastIdCount) + 1);

					return generatedId;
				}
			}
		} catch (Exception e) {
			logger.error("Error in temple Id generation");
		}

		return null;
	}
}
