package com.restApp.religiousIndia.utilities.languages;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restApp.religiousIndia.data.entities.language.Languages;
import com.restApp.religiousIndia.data.repositry.language.LanguageRepositry;
import com.restApp.religiousIndia.response.Response;
import com.restApp.religiousIndia.response.status.ResponseStatus;

@Service
public class LanguageService {
	private static Logger logger = Logger.getLogger(LanguageService.class);

	@Autowired
	private LanguageRepositry languageRepositry;

	public Response getAllLanguages() {
		Response response = new Response();

		try {
			List<Languages> allLanguages = languageRepositry.findAll();

			if (allLanguages != null) {
				response.setStatus(ResponseStatus.OK);
				response.setResponse(allLanguages);
				return response;
			} else {
				response.setStatus(ResponseStatus.NO_DATA_FOUND);
				response.setResponse("No records in DB");
				return response;
			}

		} catch (Exception e) {
			logger.error("Error while fetching languages from DB:" + e.getMessage());
			response.setStatus(ResponseStatus.ERROR);
			response.setResponse("DataBase is busy please try later.");
			return response;
		}
	}
}
