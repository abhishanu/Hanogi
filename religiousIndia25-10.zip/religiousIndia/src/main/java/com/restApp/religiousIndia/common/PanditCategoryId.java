package com.restApp.religiousIndia.common;

public enum PanditCategoryId {
	VIP, RENOWED, POPULAR, NEW, SPECIAL;
}
