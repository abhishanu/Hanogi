package com.restApp.religiousIndia.model.roleName;

public enum RoleName {
	ROLE_USER, ROLE_ADMIN,ROLE_PANDIT,ROLE_TEMPLE,ROLE_SUPER_ADMIN
}
