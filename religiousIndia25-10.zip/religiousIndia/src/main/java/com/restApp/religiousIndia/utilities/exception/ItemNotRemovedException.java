package com.restApp.religiousIndia.utilities.exception;

public class ItemNotRemovedException extends Exception {
	public ItemNotRemovedException(String msg) {
		super(msg);
	}

}
