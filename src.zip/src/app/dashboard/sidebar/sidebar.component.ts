import { Component, OnInit } from '@angular/core';
import { Router, Route, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {
  activeLink:any='';
  constructor(public router:Router, public route: ActivatedRoute ){
  }

  ngOnInit(){

  }
  navigate($event,newValue){
  let path = $event.target.id;
  this.activeLink = newValue;
  this.router.navigate(['/dashboard/'+path+''],{skipLocationChange: true});
  }
}
