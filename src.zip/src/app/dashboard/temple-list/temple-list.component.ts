import { Component, OnInit } from '@angular/core';
import { Router, Route, ActivatedRoute } from '@angular/router';
import { DataService } from '../../services/data.service';
//import { TempleComponent } from '../temple/temple.component'


@Component({
  selector: 'temple-list',
  templateUrl: './temple-list.component.html'
})
export class TempleListComponent implements OnInit {
  unVerifiedTemples:Array<any>;
  isEditedList: boolean = false;

constructor(private dataService: DataService,public router:Router ){
}
ngOnInit(){
    this.dataService.fetchData("getUnVerifiedTemplesList").subscribe(data =>{
        this.unVerifiedTemples = data.json().response;
    })
}

verifyTemple(templeId){
  this.dataService.fetchData("saveTempleAsVerified/"+templeId).subscribe(response=>{
    if(response.status===200){
      var index= this.unVerifiedTemples.lastIndexOf(templeId);
      this.unVerifiedTemples.splice(index,1);
    }
  },error =>{
    console.log(error);
  })
}

editTempleDetails(templeId){
  this.dataService.isTempleListEdit = templeId;
  this.isEditedList = true;
  //this.router.navigate(['/dashboard/addtemple'],{skipLocationChange: true});
}
}
