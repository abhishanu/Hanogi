import { Component, OnInit } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit  {
    params: any;
    model: any = {};
    constructor(private router: Router, private _DataService: DataService) {

    }
  ngOnInit() {}

  onSubmit() {
    this.userSignIn();
  }
  userSignIn() {
    this.params = {
      'requestType': 'login',
      'requestParam': this.model
    };
      this._DataService.postAuthData('login', this.params).subscribe(
        data => {
          if ( data ) {
            this._DataService.login(data);
            this.router.navigate(['dashboard']);
          } else {
            console.log('Error');
          }
        },
        err =>  {
          console.log(err);
        }
      );
  }

  forgetPwd() {
  }
}
