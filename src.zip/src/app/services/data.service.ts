//Application level services 
import { Injectable } from '@angular/core';
import {Http, Headers, RequestOptions} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import {JwtHelper} from 'angular2-jwt';
import {AuthHttp} from 'angular2-jwt';
import { HttpClient } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';

@Injectable()
export class DataService {
  headers: any;
  requestOptions: any;
  jwtHelper: JwtHelper = new JwtHelper();
  accessToken: string;
  baseServiceUrl: any = 'http://172.16.15.33:8081/';
  isTempleListEdit: any;
  allUserRoles: any;
  currentUserRole: any = 'admin';

  constructor(private _http: Http, private http: AuthHttp, private _httpclient: HttpClient) {
    this.headers = new Headers({
      'Content-Type': 'application/json'
    });
    this.requestOptions = new RequestOptions({headers: this.headers});
  }

  fetchData(serviceName) {
    return this._http.get(this.baseServiceUrl + serviceName);
  }

  postData(serviceName, params) {
    return this._http.post(this.baseServiceUrl + serviceName, params, this.requestOptions);
  }
   postclientData(serviceName, params) {
          return this._httpclient.post(this.baseServiceUrl + serviceName, params);
            //   let req = new HttpRequest('POST', 'http://172.16.16.40:8081/saveImage', file, {
  //     reportProgress: true
  //   });
  //  return this._httpclient.request(req);
  }

  postAuthData(serviceName, params) {
    return this.http.post(this.baseServiceUrl + serviceName, params, this.requestOptions);
  }

  authData(serviceName, params) {
    const headers = new Headers();
  }

  login(accessToken) {
    this.accessToken = accessToken;
    localStorage.setItem('access_token', accessToken);
  }

  fetchAuthData(serviceName) {
    return this.http.get(this.baseServiceUrl + serviceName);
  }
}
