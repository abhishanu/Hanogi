import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'account-detail',
  templateUrl: './account-detail.component.html'
})
export class AccountDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
