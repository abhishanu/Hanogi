import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'wish-list',
  templateUrl: './wish-list.component.html'
})
export class WishListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
