import { Component, OnInit, Renderer } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { RequestService } from '../../services/request.service';

@Component({
    selector: 'home-temple-donations',
    templateUrl: './temple-donations.component.html'
})
export class TempleDonationsComponent implements OnInit {
    private temples: any = [];
    private trending:any;
    private activeTemple:any;
    private templeNeeds:any=[];
    constructor(private renderer: Renderer,private _commonService: CommonService, private _requestService: RequestService) { }

    ngOnInit() {
        this._requestService.fetchData("getPopularTemples").subscribe(
            data=>{
                this.temples=data.json().response; 
                this.activeTemple=this.temples[0];
                this.getNeeds(this.activeTemple.Temple_Id);
            },
            err=>{
                this._commonService.showHttpErrorMsg();
            }
        );
        this.trending = ["Shri Krishn Janambhumi","Dwarkadeesh Temple","Prem Mandir","Ramaswamy Temple","Sri Ranganathaswamy Temple","Mahabaleshwar Temple","Jagannath Temple"]
    }

    private showDetails(event,index){
        let siblings = event.currentTarget.parentElement.children;
        for(let i = 0; i < siblings.length; i++){
            siblings[i].className= "";
        }
        event.currentTarget.className = "active";
        this.activeTemple=this.temples[index];
        this.getNeeds(this.activeTemple.Temple_Id);
    }

    private getNeeds(templeId){
        this.templeNeeds=[];
        this._requestService.fetchData("getAllDonationDetails/"+templeId).subscribe(
            data=>{
                const dataItem:any=data.json();
                if(dataItem["Medicine"].length!==0){
                 let needs=dataItem["Medicine"];
                 this.templeNeeds.push(needs[0]["description"]);
                }
                if(dataItem["Food Donation"].length!==0){
                 let needs=dataItem["Food Donation"];
                 this.templeNeeds.push(needs[0]["description"]);
                }
                if(dataItem["Education"].length!==0){
                 let needs=dataItem["Education"];
                 this.templeNeeds.push(needs[0]["description"]);
                }
                if(dataItem["Clothes"].length!==0){
                 let needs=dataItem["Clothes"];
                 this.templeNeeds.push(needs[0]["description"]);
                }
                if(dataItem["Girl Child Marriage"].length!==0){
                 let needs=dataItem["Girl Child Marriage"];
                 this.templeNeeds.push(needs[0]["description"]);
                }
                if(dataItem["Temple Needs"].length!==0){
                 let needs=dataItem["Temple Needs"];
                 this.templeNeeds.push(needs[0]["description"]);
                }
            }
        );
    }
}
