import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { RequestService } from '../services/request.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  isPopup: any = false;
  signUp: any = {};
  signIn: any = {};
  params: any;
  //fbLogInUrl:any='https://www.udemy.com/';
  fbLogInUrl:any='/';
  
  constructor(private _CommonService: CommonService, private _requestService: RequestService) { this.fbLogin();}

  ngOnInit() {
    this._CommonService.loginHandler.subscribe(options => {
      this.isPopup = true;
      document.querySelector("body").classList.add("body-overflow-hide");
    });
    if(localStorage.getItem('UserName')!=null){
      this.signIn.id=localStorage.getItem('UserName');
    }
  }
  closePopup() {
    document.querySelector("body").classList.remove("body-overflow-hide");
    this.isPopup = false;
  }
  userSignUp() {
    this.params = {
      "requestType": "signUp",
      "requestParam": this.signUp
    };
    this._requestService.postData("userSignUp", this.params).subscribe(data => {
      this._CommonService.hideLoader();
      if (data.json().status == "ERROR") {
        this._CommonService.showAlert({
          type: "danger", msg: data.json().response
        });

        this.closePopup();
        this.signUp = {};
      }
      else {
        this._CommonService.showAlert({
          type: "success", msg: 'User successfully sign up, please verify your email id / mobile number to login.'
        });
        this.closePopup();
        this.signUp = {};
      }
    }, err => {
      this._CommonService.showHttpErrorMsg();
    });
  }
  userSignIn() {
    this.params = {
      "requestType": "login",
      "requestParam": this.signIn
    };
    
    if (this._CommonService.checkAlreadyLoggedIn()) {
      this.closePopup();
      this._CommonService.showAlert({
        type: "success", msg: 'Already logged in'
    });
    }
    else {
      this._requestService.authData("login", this.params).subscribe(
        data => {
          if(data){
            this._requestService.login(data);
            this.userProfile();
            this.closePopup();
          }
          else{
              this._CommonService.showAlert({
                   type: "danger", msg: 'Username or password is incorrect'
              });
          }
        },
        err =>  {
          this.closePopup();
          this._CommonService.showHttpErrorMsg();
        }
      );
    }
  }

  userProfile(){
    console.log('userProfile');
    this._requestService.fetchAuthData('myProfile').subscribe(data => {
      const result = data.json().response;
      console.log(result);
      this._CommonService.userName=result.firstName;
    }, err => {
      this._CommonService.showHttpErrorMsg();
    });
  }

  forgetPwd(){
    const reqParam='forgetPasswordOTP?user='+this.signIn.id;
  
    if(this.signIn.id!=null || this.signIn.id!=''){
      this._requestService.fetchData(reqParam).subscribe(
        data=>{
          const dataItem=data.json();
          this.closePopup();
          if(dataItem.status == "ERROR"){this._CommonService.showAlert({
            type: "danger", msg: dataItem.response});
          }
          else{
            this._CommonService.showAlert({
              type: "success", msg: dataItem.response});
          }
        },err=>{
          this.closePopup();
          this._CommonService.showHttpErrorMsg();
        });
    }else{
      this._CommonService.showAlert({
        type: "danger", msg: 'Please enter id'});
    }
  }

  fbLogin(){
    this._requestService.fetchData('createFacebookAuthorization').subscribe(
      data=>{
        const dataItem=data.json();

        //validation FB url is dataItem.response;
        this.fbLogInUrl=dataItem.response;
      },
      err=>{
        this._CommonService.showHttpErrorMsg();
      });
  }
}
