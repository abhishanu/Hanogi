package com.restApp.religiousIndia.data.repositry;

import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.TempleConnectivity;

public interface TempleConnectivityRepositry extends CrudRepository<TempleConnectivity,String> {

}
