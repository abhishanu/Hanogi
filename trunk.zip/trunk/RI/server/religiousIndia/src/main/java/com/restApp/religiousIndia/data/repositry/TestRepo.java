package com.restApp.religiousIndia.data.repositry;

import org.springframework.data.repository.CrudRepository;

import com.restApp.religiousIndia.data.entities.Test;

public interface TestRepo extends CrudRepository<Test, String> {

}
