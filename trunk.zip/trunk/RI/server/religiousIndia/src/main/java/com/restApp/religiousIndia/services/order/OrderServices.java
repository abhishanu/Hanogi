package com.restApp.religiousIndia.services.order;

public interface OrderServices {

	public String getOrderStatus(String statusId);
}
