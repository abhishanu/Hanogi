package com.restApp.religiousIndia.utilities.exception;

public class UserNotSavedException extends Exception {
	public UserNotSavedException(String msg) {
		super(msg);
	}

}
